﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Repository;

namespace PraticDepo.Tests
{
    [TestClass]
    public class CleanUpTestData
    {
        IBaseRepository<Location> locationsRepo = null;
        IBaseRepository<Item> itemsRepo = null;

        [TestInitialize]
        public void SetUp()
        {
            locationsRepo = new BaseRepository<Location>();
            itemsRepo = new BaseRepository<Item>();
        }

        [TestCleanup]
        public void CleanUp()
        {
            locationsRepo.Dispose();
            locationsRepo = null;

            itemsRepo.Dispose();
            itemsRepo = null;
        }

        [TestMethod]
        public void Clean()
        {
            var testRoomParts = locationsRepo.GetBy(l => l.Name == "Test room part");
            foreach (var part in testRoomParts)
                locationsRepo.Delete(part);

            var testRooms = locationsRepo.GetBy(l => l.Name == "Test room");
            foreach (var room in testRooms)
                locationsRepo.Delete(room);

            var testHomes = locationsRepo.GetBy(l => l.Name == "Test home");
            foreach (var home in testHomes)
                locationsRepo.Delete(home);
        }
    }
}
