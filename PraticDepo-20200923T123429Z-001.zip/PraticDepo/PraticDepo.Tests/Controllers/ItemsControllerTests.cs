﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PraticDepo.Tests.Controllers
{
    [TestClass]
    public class ItemsControllerTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
