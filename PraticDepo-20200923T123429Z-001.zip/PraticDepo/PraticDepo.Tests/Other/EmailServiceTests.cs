﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using PraticDepo.Web.Providers;
using System.Threading.Tasks;

namespace PraticDepo.Tests.Other
{
    [TestClass]
    public class EmailServiceTests
    {
        [TestMethod]
        public void SendEmailTest()
        {
            new EmailService().Send(new Microsoft.AspNet.Identity.IdentityMessage
                {
                    Body = "This is a test message from PraticDepo project(unit tests).",
                    Destination = /*"pratic.depo@gmail.com"*/"dmitry.kovalchuk2010@gmail.com",
                    Subject = "Test message"
                });
        }
    }
}
