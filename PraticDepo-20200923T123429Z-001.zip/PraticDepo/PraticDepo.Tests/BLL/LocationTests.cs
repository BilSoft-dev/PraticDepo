﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PraticDepo.BusinessLayer.Item;

namespace PraticDepo.Tests.BLL
{
    [TestClass]
    public class LocationTests
    {
        LocationService locationService = new LocationService();
        Guid homeId, roomId, roomPartId, addedHomeId, addedRoomId, addedRoomPartId;

        [TestInitialize]
        public void SetUp()
        {
            homeId = locationService.AddNewHome(
                new System.Device.Location.GeoCoordinate(49, 33), 
                "Test home", 
                "test user", 
                "test city");

            roomId = locationService.AddRoom(homeId, "Test room");
            roomPartId = locationService.AddRoomPart(roomId, "Test room part");
        }

        [TestMethod]
        public void AddHomeWithSameName()
        {
            try
            {
                addedHomeId = locationService.AddNewHome(
                    new System.Device.Location.GeoCoordinate(49, 33),
                    "Test home",
                    "test user",
                    "test city");

                Assert.Fail("It's able to add home with same name");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(
                    "You already has home with same name. Please type another home name.",
                    ex.Message);
            }
        }

        [TestMethod]
        public void AddRoomWithSameName()
        {
            try
            {
                addedRoomId = locationService.AddRoom(homeId, "Test room");

                Assert.Fail("It's able to add room with same name");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(
                    "Room with same name already exist at this home. Please type another name",
                    ex.Message);
            }
        }

        [TestMethod]
        public void AddRoomPartWithSameName()
        {
            try
            {
                addedRoomPartId = locationService.AddRoomPart(roomId, "Test room part");

                Assert.Fail("It's able to add room part with same name");
            }
            catch (Exception ex)
            {
                Assert.AreEqual(
                    "Room part with same name already exist at this room. Please type another name",
                    ex.Message);
            }
        }

        [TestCleanup]
        public void CleanUp()
        {
            if(homeId != Guid.Empty)
                locationService.DeleteHome(homeId);
            if(addedHomeId != Guid.Empty)
                locationService.DeleteHome(addedHomeId);
        }
    }
}
