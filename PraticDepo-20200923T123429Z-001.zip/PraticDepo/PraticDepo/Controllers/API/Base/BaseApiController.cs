﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Security.Claims;

namespace PraticDepo.Web.Controllers.API
{
    public class BaseApiController : ApiController
    {
        protected IEnumerable<string> UserRoles => ((ClaimsIdentity)User.Identity).Claims.Where(c => c.Type == ClaimTypes.Role).Select(c => c.Value);

        /// <summary>
        ///  User Role not including Admin Role !!!
        /// </summary>
        protected string UserRole
        {
            get
            {
                var claim = ((ClaimsIdentity)User.Identity).Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role && c.Value != "Admin");
                if (claim != null)
                {
                    return claim.Value;
                }

                return string.Empty;
            }
        }
    }
}