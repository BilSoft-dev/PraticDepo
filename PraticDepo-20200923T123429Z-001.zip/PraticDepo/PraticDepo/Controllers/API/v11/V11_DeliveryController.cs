﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Microsoft.AspNet.Identity;
using PraticDepo.Web.Common.Helpers;
using PraticDepo.Attributes;
using PraticDepo.BusinessLayer.V2.Services;
using PraticDepo.Models.DeliveryManagement;
using System.Configuration;
using PraticDepo.BusinessLayer.V2.Models.Configs;
using PraticDepo.BusinessLayer.V2.Utils.Providers.Emails;
using System.Net.Configuration;

namespace PraticDepo.Web.Controllers.API.v11
{
    [ApiAuthorizeV11]
    [RoutePrefix("api/v1.1/Delivery")]
    public class V11_DeliveryController : BaseApiController
    {
        private DeliveryService _deliveryService;
        private string _adminApiDeliveryRequestUrlPattern;
        private SmtpSection _smtpSection;

        private EmailService _emailService;

        private readonly ICollectionService _collectionService;

        public V11_DeliveryController()
        {
            _deliveryService = new DeliveryService();
            _adminApiDeliveryRequestUrlPattern = ConfigurationManager.AppSettings["AdminApiDeliveryRequestUrlPattern"];
            _smtpSection = (SmtpSection)ConfigurationManager.GetSection("system.net/mailSettings/smtp");

            _emailService = new EmailService(new EmailProvider(new SmtpClientConfig()
            {
                EnableSSL = _smtpSection.Network.EnableSsl,
                From = _smtpSection.From,
                Host = _smtpSection.Network.Host,
                Password = _smtpSection.Network.Password,
                Port = _smtpSection.Network.Port,
                UserName = _smtpSection.Network.UserName,
                DisplayName = string.Empty
            }));
            _collectionService = new CollectionService();
        }


        // POST /Request
        [Route("Request")]
        public IHttpActionResult PostRequest(AddRequestViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Add Delivery Request' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'Add Delivery Request' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var userId = User.Identity.GetUserId();

                if (!_collectionService.CanUserPerformCollectionOperation(userId, model.CollectionId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This item has been moved to another collection" } });
                }

                var request = _deliveryService.AddDeliveryRequest(userId, model.CollectionId, model.ItemId, model.ChapterId);
                var result = new RequestViewModel
                {
                    RequestId = request.RequestId,
                    RequestNumber = request.RequestNumber,
                    CollectionId = request.CollectionId,
                    ItemId = request.ItemId,
                    ChapterId = request.ChapterId
                };

                return Json(new { Status = "Success", Request = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Add Delivery Request' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Add Delivery Request' method finished");
                #endif
            }
        }

        // POST /RequestDetail
        [Route("DeleteRequestDetail")]
        public IHttpActionResult PostDeleteRequestDetail(DeleteRequestDetailViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Remove Delivery Request Detail' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'Remove Delivery Request Detail' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var userId = User.Identity.GetUserId();

                if (!_collectionService.CanUserPerformCollectionOperation(userId, model.CollectionId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This item has been moved to another collection" } });
                }

                _deliveryService.RemoveDeliveryRequestDetail(User.Identity.GetUserId(), model.CollectionId, model.ItemId, model.ChapterId);
                
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Remove Delivery Request Detail' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Remove Delivery Request Detail' method finished");
                #endif
            }
        }

        // DELETE /Request/{id}
        [Route("Request")]
        public IHttpActionResult DeleteRequest(Guid id)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Remove Delivery Request' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'Remove Delivery Request' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                _deliveryService.RemoveDeliveryRequest(id);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Remove Delivery Request' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Remove Delivery Request' method finished");
                #endif
            }
        }

        // POST /SubmitRequest/{id}
        [Route("SubmitRequest/{id:guid}")]
        public IHttpActionResult PostSubmitRequest(Guid id)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Submit Delivery Request' method started");
            #endif

            try
            {
                _deliveryService.SetStatusToDeliveryRequest(id, BusinessLayer.V2.Enums.DeliveryRequestStatus.Submitted, _emailService, shouldSendEmail: true, linkToAdminPanel: string.Format(_adminApiDeliveryRequestUrlPattern, id));
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Submit Delivery Request' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Submit Delivery Request' method finished");
                #endif
            }
        }

        // POST /CancelRequest/{id}
        [Route("CancelRequest/{id:guid}")]
        public IHttpActionResult PostCancelRequest(Guid id)//create model with guid and flag
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Cancel Delivery Request' method started");
            #endif

            try
            {
                _deliveryService.SetStatusToDeliveryRequest(id, BusinessLayer.V2.Enums.DeliveryRequestStatus.Cancelled, _emailService, shouldSendEmail: true, linkToAdminPanel: string.Format(_adminApiDeliveryRequestUrlPattern, id));
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Cancel Delivery Request' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Cancel Delivery Request' method finished");
                #endif
            }
        }

        // GET /UserRequests
        [Route("UserRequests")]
        public IHttpActionResult GetUserRequests()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Get User Requests' method started");
            #endif

            try
            {
                var result = new List<DeliveryRequestViewModel>();
                var requests = _deliveryService.GetDeliveryRequests(User.Identity.GetUserId());
                requests.ForEach(x => result.Add(new DeliveryRequestViewModel
                {
                    RequestId = x.RequestId,
                    RequestNumber = x.RequestNumber,
                    DateCreated = x.DateCreated.ToString("yyyy-MM-dd HH:mm:ss"),
                    DateDelivered = x.DateDelivered.HasValue ? x.DateDelivered.Value.ToString("yyyy-MM-dd HH:mm:ss") : "",
                    Status = x.Status,
                    ItemCounter = x.ItemCounter
                }));

                return Json(new { Status = "Success", Requests = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Get User Requests' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Get User Requests' method finished");
                #endif
            }
        }

        // GET /RequestDetails
        [Route("RequestDetails")]
        public IHttpActionResult GetRequestDetails(Guid id)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Get Request Details' method started");
            #endif

            try
            {
                var requestCollectionsResult = new List<DeliveryRequestCollectionViewModel>();
                var requestNotesResult = new List<DeliveryRequestNoteVilewModel>();
                var s3Helper = new AmazonS3Helper();

                var requestCollections = _deliveryService.GetDeliveryRequestDetails(id);
                requestCollections.ForEach(x => requestCollectionsResult.Add(new DeliveryRequestCollectionViewModel
                {
                    Id = x.CollectionId,
                    Name = x.CollectionName,
                    Status = x.Status,
                    Barcode = x.Barcode,
                    ItemCounter = x.ItemsTotal,
                    Photo = GetCollectionPhoto(x.PhotoFileName, s3Helper),
                    Items = x.Items.Select(item => new DeliveryRequestItemViewModel
                    {
                        Id = item.ItemId,
                        ChapterId = item.ChapterId,
                        Name = item.ItemName,
                        Status = (x.Status == (int) BusinessLayer.V2.Enums.DeliveryRequestCollectionStatus.Cancelled) 
                                ? (int) BusinessLayer.V2.Enums.DeliveryRequestItemStatus.Cancelled
                                : item.Status,
                        Barcode = item.Barcode,
                        PreviewUrl = s3Helper.GetPreviewUrl(item.FileName)
                    }).ToList()
                }));

                var requestNotes = _deliveryService.GetDeliveryRequestNotes(id);
                requestNotes.ForEach(x => requestNotesResult.Add(new DeliveryRequestNoteVilewModel
                {
                    NoteId = x.Id,
                    NoteValue = x.Note
                }));

                return Json(new { Status = "Success", Collections = requestCollectionsResult, Notes = requestNotesResult });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Get Request Details' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Get Request Details' method finished");
                #endif
            }
        }

        // POST /RequestNote
        [Route("RequestNote")]
        public IHttpActionResult PostRequestNote(AddRequestNoteViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Add Delivery Request Note' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'Add Delivery Request Note' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var deliveryRequestNoteId = _deliveryService.AddDeliveryRequestNote(model.RequestId, model.Note, _emailService, linkToAdminPanel: string.Format(_adminApiDeliveryRequestUrlPattern, model.RequestId));
                var result = new RequestNoteViewModel { NoteId = deliveryRequestNoteId };
                return Json(new { Status = "Success", Note = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Add Delivery Request Note' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Add Delivery Request Note' method finished");
                #endif
            }
        }

        // PUT /RequestNote
        [Route("RequestNote")]
        public IHttpActionResult PutRequestNote(EditRequestNoteViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Edit Delivery Request Note' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'Edit Delivery Request Note' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                _deliveryService.UpdateDeliveryRequestNote(model.NoteId, model.Note);
                var result = new RequestNoteViewModel { NoteId = model.NoteId };
                return Json(new { Status = "Success", Note = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Edit Delivery Request Note' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Edit Delivery Request Note' method finished");
                #endif
            }
        }

        // DELETE /RequestNote
        [Route("RequestNote/{noteId:guid}")]
        public IHttpActionResult DeleteRequestNote(Guid noteId)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Delete Delivery Request Note' method started");
            #endif

            try
            {
                _deliveryService.DeleteDeliveryRequestNote(noteId);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Delete Delivery Request Note' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Delete Delivery Request Note' method finished");
                #endif
            }
        }

        private PraticDepo.Models.CollectionPhotos.GetCollectionPhotoViewModel GetCollectionPhoto(string fileName, AmazonS3Helper s3Helper)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return new PraticDepo.Models.CollectionPhotos.GetCollectionPhotoViewModel();
            }

            return new PraticDepo.Models.CollectionPhotos.GetCollectionPhotoViewModel
            {
                ImagePath = s3Helper.getUrl(fileName),
                PreviewImagePath = s3Helper.GetPreviewUrl(fileName)
            };
        }
    }
}