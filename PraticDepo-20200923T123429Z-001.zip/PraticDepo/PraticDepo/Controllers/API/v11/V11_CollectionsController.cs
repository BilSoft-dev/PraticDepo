﻿using System;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.IO;
using PraticDepo.Web.Common.Helpers;
using PraticDepo.Attributes;
using PraticDepo.Models.CollectionPhotos;
using PraticDepo.Web.Controllers.API;
using PraticDepo.BusinessLayer.V2.Services;
using Microsoft.AspNet.Identity;
using PraticDepo.Models.Collections;

namespace PraticDepo.Controllers.API.v11
{
    [ApiAuthorizeV11]
    [RoutePrefix("api/v1.1/Collection")]
    public class V11_CollectionsController : BaseApiController
    {
        private CollectionPhotosService _collectionPhotosService;
        private CollectionService _collectionService;
        private DeliveryService _deliveryService;
        private ItemService _itemService;
        private JobService _jobService;

        public V11_CollectionsController()
        {
            _collectionPhotosService = new CollectionPhotosService(ConfigurationManager.AppSettings["S3BucketName"]);
            _collectionService = new CollectionService();
            _deliveryService = new DeliveryService();
            _itemService = new ItemService();
            _jobService = new JobService();
        }

        // POST api/Collection/AddPhoto
        [Route("AddPhoto")]
        public async Task<IHttpActionResult> Add(AddCollectionPhotoViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Add' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'AddItem' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var collection = _collectionService.GetCollection(User.Identity.GetUserId(), UserRole, model.CollectionId);

                if (!_collectionPhotosService.CanAddChangeRemoveCollectionPhoto(UserRole, collection.UserId != User.Identity.GetUserId(), collection.IsShedCollection))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This user doesn't have enough permissions to work with collection photo" } });
                }

                string filePath = string.Empty;

                if (model.Upload != null && model.Upload.FileContent != null && model.Upload.FileContent.Length > 0)
                {
                    filePath = await _collectionPhotosService.UploadPhotoToCloud(model.Upload.FileContent, Path.GetExtension(model.Upload.FileName));

                    if (string.IsNullOrWhiteSpace(filePath))
                    {
                        throw new Exception("Failed to add collection photo");
                    }
                }

                var collectionPhotoId = _collectionPhotosService.AddCollectionPhoto(model.CollectionId, filePath);

                return Json(new { Status = "Success", CollectionPhotoId = collectionPhotoId });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Add' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Add' method finished");
                #endif
            }
        }

        // POST api/Collection/UpdatePhoto
        [Route("UpdatePhoto")]
        public async Task<IHttpActionResult> Update(UpdateCollectionPhotoViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Update' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'Update' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var collection = _collectionService.GetCollection(User.Identity.GetUserId(), UserRole, model.CollectionId);

                if (!_collectionPhotosService.CanAddChangeRemoveCollectionPhoto(UserRole, collection.UserId != User.Identity.GetUserId(), collection.IsShedCollection))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This user doesn't have enough permissions to work with collection photo" } });
                }

                var collectionPhotos = _collectionPhotosService.GetCollectionPhotos(model.CollectionId);

                string filePath = string.Empty;

                foreach (var photo in collectionPhotos)
                {
                    _collectionPhotosService.RemovePhotoFromCloud(photo.FileName);
                    _collectionPhotosService.RemoveCollectionPhoto(photo.Id);
                }

                if (model.Upload != null && model.Upload.FileContent != null && model.Upload.FileContent.Length > 0)
                {
                    filePath = await _collectionPhotosService.UploadPhotoToCloud(model.Upload.FileContent, Path.GetExtension(model.Upload.FileName));

                    if (string.IsNullOrWhiteSpace(filePath))
                    {
                        throw new Exception("Failed to add collection photo");
                    }
                }

                var collectionPhotoId = _collectionPhotosService.AddCollectionPhoto(model.CollectionId, filePath);

                return Json(new { Status = "Success", CollectionPhotoId = collectionPhotoId });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Update' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Update' method finished");
                #endif
            }
        }

        // POST api/Collection/RemovePhoto
        [Route("RemovePhoto")]
        public async Task<IHttpActionResult> Remove(DeleteCollectionPhotoViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Remove' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'Remove' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var collection = _collectionService.GetCollection(User.Identity.GetUserId(), UserRole, model.CollectionId);

                if (!_collectionPhotosService.CanAddChangeRemoveCollectionPhoto(UserRole, collection.UserId != User.Identity.GetUserId(), collection.IsShedCollection))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This user doesn't have enough permissions to work with collection photo" } });
                }

                var collectionPhotos = _collectionPhotosService.GetCollectionPhotos(model.CollectionId);

                foreach (var photo in collectionPhotos)
                {
                    _collectionPhotosService.RemovePhotoFromCloud(photo.FileName);
                    _collectionPhotosService.RemoveCollectionPhoto(photo.Id);
                }

                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Remove' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Remove' method finished");
                #endif
            }
        }

        // POST api/Collection/MoveItems
        [Route("MoveItems")]
        public async Task<IHttpActionResult> MoveItems(MoveCollectionItemsViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'MoveItems' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'MoveItems' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var toastMessage = "Items have been successfully moved";

                foreach (var itemId in model.ItemIds.ToList())
                {
                    if (!_jobService.IsActionEnabledForItem(itemId))
                    {
                        return Json(new { Status = "Error", Errors = new string[] { "This action cannot be performed for completed jobs." } });
                    }
                }

                var itemIdsWhichBelongToDeliveryAndNotMovableRequests = _itemService.GetItemIdsWhichBelongToDeliveryRequestsAndNotMovable(model.ItemIds.ToList());
                if (itemIdsWhichBelongToDeliveryAndNotMovableRequests.Any())
                {
                    toastMessage = "Some of items you have selected are added to a delivery request and couldn’t be moved.";
                }

                var itemIdsToMove = model.ItemIds.Except(itemIdsWhichBelongToDeliveryAndNotMovableRequests);

                if (itemIdsToMove.Any())
                {
                    _itemService.MoveItemsToOtherCollection(itemIdsToMove.ToList(), model.TargetCollectionId, User.Identity.GetUserId());
                }
                else
                {
                    if (itemIdsWhichBelongToDeliveryAndNotMovableRequests.Any())
                    {
                        return Json(new { Status = "Error", Errors = new string[] { "Items you have selected are added to a delivery request and couldn’t be moved." } });
                    }
                }
                
                return Json(new { Status = "Success", Message = toastMessage });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'MoveItems' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'MoveItems' method finished");
                #endif
            }
        }
    }
}