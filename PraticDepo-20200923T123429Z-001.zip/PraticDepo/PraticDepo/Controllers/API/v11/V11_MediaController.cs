﻿using PraticDepo.BusinessLayer.Item;
using PraticDepo.Web.Models;
using PraticDepo.Web.Common.Helpers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using PraticDepo.Attributes;
using Microsoft.AspNet.Identity;

namespace PraticDepo.Web.Controllers.API.v11
{
    [ApiAuthorizeV11]
    [RoutePrefix("api/v1.1/Media")]
    public class V11_MediaController : BaseApiController
    {
        private const int STATUS_IS_NOT_ADDED_TO_REQUEST = 0;
        private const int STATUS_DELIVERED = 2;

        MediaService mediaService = new MediaService();

        // POST api/Media/UploadVideo
        [Route("UploadVideo")]
        public async Task<IHttpActionResult> UploadVideo()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'UploadVideo' method started");
            #endif
            try
            {
                if (HttpContext.Current.Request.InputStream != null && HttpContext.Current.Request.InputStream.Length > 0)
                {
                    var duration = Math.Round(double.Parse(HttpContext.Current.Request.Headers["Duration"], System.Globalization.NumberStyles.AllowDecimalPoint), 2);

                    string fileExtension;
                    string filePath;
                    if (HttpContext.Current.Request.Files.Count > 0)
                    {
                        fileExtension = Path.GetExtension(HttpContext.Current.Request.Files[0].FileName);
                        filePath = await new AmazonS3Helper().UploadVideo(HttpContext.Current.Request.Files[0].InputStream, fileExtension);
                    } else // This is needed for compatibility
                    {
                        fileExtension = ".mp4";
                        filePath = await new AmazonS3Helper().UploadVideo(HttpContext.Current.Request.InputStream, fileExtension);
                    }
                    
                    var result = mediaService.AddVideo(filePath, duration);
                    return Json(new { Status = "Success", MediaId = result });
                }
                else
                    return Json(new { Status = "Invalid", Errors = new string[] { "Must be a file." } });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'UploadVideo' method", ex);
                return Json(new { Status = "Error", Errors = ex.Message });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'UploadVideo' method finished");
                #endif
            }
        }

        // POST api/Media/UploadPhoto
        /*[Route("UploadPhoto")]
        public async Task<IHttpActionResult> UploadPhoto()
        {
            try
            {
                if (HttpContext.Current.Request.InputStream != null && HttpContext.Current.Request.InputStream.Length > 0)
                {
                    string path = UploadHelper.GetPhotoFolder();
                    var filePath = System.IO.Path.Combine(path, string.Format("{0}.{1}", Guid.NewGuid(), HttpContext.Current.Request.ContentType.Replace("image/", string.Empty)));
                    
                    var inputStream = HttpContext.Current.Request.InputStream;
                    using(var fStream = System.IO.File.OpenWrite(filePath))
                    {
                        var buf = new byte[inputStream.Length];
                        if (inputStream.Read(buf, 0, buf.Length) > 0)
                            fStream.Write(buf, 0, buf.Length);
                    }

                    filePath = filePath.Replace(HttpContext.Current.Request.ServerVariables["APPL_PHYSICAL_PATH"], "/");
                    var result = mediaService.AddPhoto(filePath);
                    return Json(new { Status = "Success", MediaId = result });
                }
                else
                    return Json(new { Status = "Invalid", Errors = new string[] { "Must be a file." } });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'UploadPhoto' method", ex);
                return Json(new { Status = "Error", Errors = ex.Message });
            }
        }*/

        // POST api/Media/GetItemMedia
        [Route("ItemMedia")]
        [Obsolete]
        public async Task<IHttpActionResult> GetItemMedia(Guid itemId)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetItemMedia' method started");
            #endif
            if (itemId == null || itemId == Guid.Empty)
                return Json(new { Status = "Invalid", Errors = new string[] { "ItemId can't be null or empty" } });

            try
            {
                var model = mediaService.GetItemMedia(itemId).Select(f => new { FilePath = f.FilePath, PreviewFilePath = f.PreviewFilePath, Type = f.Type == MediaService.MediaType.PHOTO ? "Photo" : "Video" });

                return Json(new { Status = "Success", Items = model });
            }
            catch(Exception ex)
            {
                Logger.Instance.Error("Error in 'GetItemMedia' method", ex);
                return Json(new { Status = "Error", Errors = new string[] {ex.Message} });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetItemMedia' method finished");
                #endif
            }
        }

        // POST api/Media/AddChapter
        [Route("AddChapter")]
        public async Task<IHttpActionResult> AddChapter(IEnumerable<AddVideoChapterViewModel> model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'AddChapter' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                    {
                        string message;
                        if (string.IsNullOrEmpty(error.ErrorMessage) && error.Exception != null)
                            message = error.Exception.Message;
                        else
                            message = error.ErrorMessage;
                        invalidateList.Add(message);
                    }
                }
                Logger.Instance.Error("Validation error in 'AddChapter' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var chaptersIds = new List<Guid>();
                foreach (var item in model)
                {
                    if(item.ChapterId != null && item.ChapterId != Guid.Empty)
                    {
                        mediaService.ChangeChapterTime(item.ChapterId, item.Time);
                        return Json(new { Status = "Success" });
                    }

                    if (!mediaService.IsMediaItemExsist(item.VideoId))
                        return Json(new { Status = "Error", Errors = new string[] { "Video is not found" } });
                    /*if (!mediaService.IsMediaItemExsist(item.CoverId))
                        return Json(new { Status = "Error", Errors = new string[] { "Cover is not found" } });*/
                    if(item.Cover == null || string.IsNullOrEmpty(item.Cover.FileContent))
                        return Json(new { Status = "Error", Errors = new string[] { "Cover is not found" } });
                    
                    string filePath = await new AmazonS3Helper().UploadPhoto(item.Cover.FileContent, Path.GetExtension(item.Cover.FileName));
                    var coverId = mediaService.AddPhoto(filePath);

                    if (coverId == Guid.Empty)
                        throw new Exception("Cover couldn't save");
                    
                    var chapterId = mediaService.AddChapter(item.VideoId, coverId, item.Name, item.Time, item.Barcode, item.Volume);
                    chaptersIds.Add(chapterId);
                }
                return Json(new { Status = "Success", ChapterIds = chaptersIds });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AddChapter' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'AddChapter' method finished");
                #endif
            }
        }

        //GET api/Media/VideoChapters
        [Route("VideoChapters")]
        [Obsolete]
        public async Task<IHttpActionResult> GetVideoChapters(Guid videoId)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetVideoChapters' method started");
            #endif
            if (videoId == Guid.Empty)
                return Json(new { Status = "Invalid", Errors = new string[] { "Param 'VideoId' can't be null or empty" } });

            try
            {
                if(!mediaService.IsMediaItemExsist(videoId))
                    return Json(new { Status = "Error", Errors = new string[] { "Video not found" } });

                var media = mediaService.GetMedia(videoId);
                if(media.Type != MediaService.MediaType.VIDEO)
                    return Json(new { Status = "Error", Errors = new string[] { "This media is not video" } });

                AmazonS3Helper s3Helper = new AmazonS3Helper();

                var chapters = mediaService.GetVideoChapters(videoId).Select(x => new VideoChapterViewModel
                    {
                        Id = x.Id,
                        Name = x.Name, 
                        Time = x.Time,
                        Cover = s3Helper.ReplaceChapterLink(x).Cover,
                        CoverPreview = s3Helper.ReplaceChapterLink(x).CoverPreview,
                        Barcode = x.Barcode,
                        Volume = x.Volume
                });
                return Json(new { Status = "Success", Chapters = chapters });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetVideoChapters' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetVideoChapters' method finished");
                #endif
            }
        }

        //POST api/Media/RemoveItem
        [Route("RemoveItem")]
        [Obsolete]
        public async Task<IHttpActionResult> RemoveItem(DeleteMediaViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RemoveItem' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'RemoveItem' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var media = mediaService.GetMedia(model.MediaId);
                AmazonS3Helper s3Helper = new AmazonS3Helper();
                s3Helper.DeleteMedia(media);
                mediaService.DeleteItem(model.MediaId);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveItem' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RemoveItem' method finished");
                #endif
            }
        }

        // POST api/Media/RenameChapter
        [Route("RenameChapter")]
        public async Task<IHttpActionResult> RenameChapter(RenameChapterViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RenameChapter' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                mediaService.RenameChapter(model.ChapterId, model.Name, User.Identity.GetUserId(), UserRole);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RenameChapter' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RenameChapter' method finished");
                #endif
            }
        }

        // POST api/Media/ChangeChapterTime
        [Route("ChangeChapterTime")]
        public async Task<IHttpActionResult> ChangeChapterTime(ChangeChapterTimeViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'ChangeChapterTime' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                mediaService.ChangeChapterTime(model.ChapterId, model.Time);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'ChangeChapterTime' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'ChangeChapterTime' method finished");
                #endif
            }
        }

        //POST api/Media/EditChapter
        [Route("EditChapter")]
        public async Task<IHttpActionResult> EditChapter(EditChapterViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'EditChapter' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                mediaService.EditChapter(model.ChapterId, model.Name, model.Time, model.Barcode, model.Volume, User.Identity.GetUserId(), UserRole);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'EditChapter' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'EditChapter' method finished");
                #endif
            }
        }

        // POST api/Media/RemoveChapter
        [Route("RemoveChapter")]
        public async Task<IHttpActionResult> RemoveChapter(RemoveChapterViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RemoveChapter' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var chapter = mediaService.GetChapter(model.ChapterId);

                if (chapter != null && chapter.Status != STATUS_IS_NOT_ADDED_TO_REQUEST)
                {
                    if (chapter.Status == STATUS_DELIVERED) throw new Exception("This item is delivered, therefore can't be removed.");
                    throw new Exception("Cannot delete item. The item is added to a delivery request");
                }

                var s3Helper = new AmazonS3Helper();
                s3Helper.DeleteChapter(chapter);
                mediaService.RemoveChapter(model.ChapterId, User.Identity.GetUserId(), UserRole);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveChapter' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RemoveChapter' method finished");
                #endif
            }
        }
    }
}
