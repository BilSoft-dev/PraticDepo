﻿using PraticDepo.BusinessLayer.Item;
using PraticDepo.Helpers;
using PraticDepo.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using System.IO;
using System.Web;
using PraticDepo.BusinessLayer.Users;
using PraticDepo.BusinessLayer.Permissions;
using PraticDepo.Web.Common.Helpers;
using PraticDepo.Web.Common.Configs;
using System.Net.Http;
using System.Web.Http.Description;
using PraticDepo.Attributes;
using PraticDepo.Models.CollectionPhotos;

namespace PraticDepo.Web.Controllers.API.v11
{
    [ApiAuthorizeV11]
    [RoutePrefix("api/v1.1/Items")]
    public class V11_ItemsController : BaseApiController
    {
        private const int STATUS_IS_NOT_ADDED_TO_REQUEST = 0;
        private const int STATUS_DELIVERED = 2;

        private BusinessLayer.V2.Services.DeliveryService _deliveryService;
        private readonly BusinessLayer.V2.Services.ICollectionService _collectionService;

        private readonly ItemsService _itemsService;
        private readonly MediaService _mediaService;
        private readonly BusinessLayer.V2.Services.JobService _jobService;

        public V11_ItemsController()
        {
            _itemsService = new ItemsService();
            _mediaService = new MediaService();
            _collectionService = new BusinessLayer.V2.Services.CollectionService();
            _deliveryService = new BusinessLayer.V2.Services.DeliveryService();
            _jobService = new BusinessLayer.V2.Services.JobService();
        }

        // POST api/Items/AddItem
        [Route("AddItem")]
        public async Task<IHttpActionResult> AddItem(AddItemViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'AddItem' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'AddItem' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var itemsIds = new List<Guid>();
                var userId = User.Identity.GetUserId();

                if (model.CollectionId != Guid.Empty && !_collectionService.CanUserPerformCollectionOperation(userId, model.CollectionId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This item has been moved to another collection" } });
                }

                if (!_jobService.IsActionEnabledForCollection(model.CollectionId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This action cannot be performed for completed jobs." } });
                }

                Guid mediaId = Guid.Empty;
                if (model.Upload != null && model.Upload.FileContent != null && model.Upload.FileContent.Length > 0)
                {
                    //string path = UploadHelper.GetPhotoFolder();
                    //filePath = System.IO.Path.Combine(path, string.Format("{0}{1}", Guid.NewGuid(), Path.GetExtension(item.Upload.FileName)));

                    //using (var fStream = System.IO.File.OpenWrite(filePath))
                    //{
                    //    var buf = Convert.FromBase64String(item.Upload.FileContent);
                    //    fStream.Write(buf, 0, buf.Length);
                    //    fStream.Flush();

                    //    #if DEBUG
                    //    Logger.Instance.Info("Image saved to: " + filePath);
                    //    #endif
                    //}

                    //filePath = filePath.Replace(HttpContext.Current.Server.MapPath("/"), "/");
                    
                    string filePath;
                    AmazonS3Helper helper = new AmazonS3Helper();
                    switch (model.Upload.Type)
                    {
                        case "Video":
                            filePath = await helper.UploadVideo(model.Upload.FileContent, Path.GetExtension(model.Upload.FileName));
                            mediaId = _mediaService.AddVideo(filePath, Math.Round(model.Upload.Duration, 2));
                            break;
                        case "Photo":
                            filePath = await helper.UploadPhoto(model.Upload.FileContent, Path.GetExtension(model.Upload.FileName));
                            mediaId = _mediaService.AddPhoto(filePath);
                            break;
                        default:
                            throw new Exception("Unknown file type");
                    }

                    if (mediaId == Guid.Empty)
                        throw new Exception("Media file could not save");
                }

                var result = _itemsService.AddItem(mediaId, model.CollectionId, model.Name, userId, model.Barcode, model.Volume, UserRole);
                itemsIds.Add(result);

                
                //var collection = itemsService.GetCollection(model.CollectionId);
                //var notificationsService = new NotificationsService();
                //var author = new UsersService().GetUserById(User.Identity.GetUserId());
                //foreach (var collaborator in collaborators.Where(x => x.UserId != userId))
                //    notificationsService.AddNotification(
                //        collaborator.UserId,
                //        string.Format("<b>{0}</b> added item '{1}' to collection <b>{2}</b>", author.DisplayName, model.Name, collection.Name),
                //        model.CollectionId, NotificationsService.ACTION);
                return Json(new { Status = "Success", ItemId = result });
            }
            catch(Exception ex)
            {
                Logger.Instance.Error("Error in 'AddItem' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } }); 
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'AddItem' method finished");
                #endif
            }
        }
        
        // GET api/Items/UserItems
        [Route("UserItems")]
        [Obsolete]
        public async Task<IHttpActionResult> GetUserItems()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetUserItems' method started");
            #endif
            try
            {
                var userId = User.Identity.GetUserId();
                var result = _itemsService.GetItemsByUser(userId);

                return Json(new { Status = "Success", Items = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetUserItems' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetUserItems' method finished");
                #endif
            }
        }

        // GET api/Items/Collection
        [Route("Collection")]
        [ResponseType(typeof(CollectionViewModel))]
        public async Task<IHttpActionResult> GetCollection(Guid CollectionId)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetCollection' method started");
            #endif
            if (CollectionId == Guid.Empty)
            {
                Logger.Instance.Error("Validation error in 'GetCollection' method");
                return Json(new { Status = "Invalid", Errors = new string[] { "'CollectionId' can't be null or empty" } });
            }

            try
            {
                var s3Helper = new AmazonS3Helper();
                var collection = _itemsService.GetCollection(User.Identity.GetUserId(), UserRole, CollectionId);

                if (!CollectionLevel.CanSeeCollection(UserRole, collection.UserId != User.Identity.GetUserId(), collection.IsShedCollection))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "A user doesn't have permissions to see this collection" } });
                }

                var drCollection = _deliveryService.GetDeliveryRequestCollectionForWebAPI(User.Identity.GetUserId(), collection.Id);

                CollectionViewModel collectionViewModel = new CollectionViewModel
                {
                    Id = collection.Id,
                    Items = collection.Items.Where(x => x.Status != STATUS_DELIVERED).Select(item => new CollectionItemViewModel()
                    {
                        CollectionId = item.CollectionId,
                        CreateDate = item.CreateDate.ToString("yyyy-MM-dd HH:mm:ss"),
                        Id = item.Id,
                        Media = s3Helper.ReplaceMediaLinks(FilterVideoChapter(item.Media.ToList(), drCollection != null)),
                        Name = item.Name,
                        Barcode = item.Barcode,
                        Volume = item.Volume,
                        Status = drCollection != null ? item.Status : 0,
                        IsLoaded = item.IsLoaded
                    }).ToList(),
                    Name = collection.Name,
                    OwnerFirstName = collection.OwnerFirstName,
                    OwnerLastName = collection.OwnerLastName,
                    Notes = collection.Notes,
                    CreateAt = collection.CreateAt.ToString("yyyy-MM-dd HH:mm:ss"),
                    City = collection.City,
                    HomeId = collection.HomeId,
                    HomeLatitude = collection.HomeLatitude,
                    HomeLongitude = collection.HomeLongitude,
                    HomeName = collection.HomeName,
                    RoomId = collection.RoomId,
                    RoomName = collection.RoomName,
                    RoomPartId = collection.RoomPartId,
                    RoomPartName = collection.RoomPartName,
                    Address = collection.Address,
                    Barcode = collection.Barcode,
                    Volume = collection.Volume,
                    CollectionLevelPermissions = CollectionLevel.GetCollectionLevelMask(UserRole, User.Identity.GetUserId() != collection.UserId, collection.IsShedCollection),
                    LocationLevelPermissions = collection.LocationLevelPermissions,
                    Status = drCollection != null ? drCollection.Status : 0,
                    RequestId = drCollection?.DeliveryRequestId,
                    BinNumber = collection.BinNumber,
                    StorageLocation = collection.StorageLocation,
                    Photo = GetCollectionPhoto(collection.PhotoFileName, s3Helper),
                    IsLoaded = collection.IsLoaded
                };
                return Json(new { Status = "Success", Collection = collectionViewModel });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetCollection' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetCollection' method finished");
                #endif
            }
        }

        // PUT api/Items/Collection
        [Route("Collection")]
        [ResponseType(typeof(CollectionViewModel))]
        public async Task<IHttpActionResult> PutCollection(AddCollectionViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'PutCollection' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'PutCollection' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var userId = User.Identity.GetUserId();
                new UsersService().EnsureCanManageCollaborators(User.Identity.GetUserId(), UserRole);

                if (model.Collaborators != null)
                {
                    foreach (var collaborator in model.Collaborators)
                    {
                        if (collaborator.CollaboratorId == null || collaborator.CollaboratorId == Guid.Empty)
                        {
                            if (string.IsNullOrEmpty(collaborator.UserId) && (string.IsNullOrEmpty(collaborator.Email) || string.IsNullOrEmpty(collaborator.Name)))
                            { 
                                return Json(new { Status = "Invalid", Errors = new string[] { "Need to specify collaborator's UserId or user name and email" } });
                            }
                            if(collaborator.UserId == userId)
                            {
                                return Json(new { Status = "Invalid", Errors = new string[] { "You cannot add self as collaborator" } });
                            }
                        }
                    }
                }
                
                var collection = _itemsService.AddCollection(model.Name, userId, model.HomeId, model.RoomId, model.RoomPartId, model.Notes, model.Barcode, model.Volume, UserRole, model.StorageLocation, model.BinNumber);
                if (collection != null)
                {
                    if(model.Collaborators != null)
                    {
                        foreach(var collaborator in model.Collaborators)
                        {
                            try
                            {
                                var collaboratorId = await new CollaboratorsHelper().AddCollaborator(
                                    Request.GetOwinContext().GetUserManager<ApplicationUserManager>(),
                                    userId,
                                    new AddUserCollaboratorViewModel()
                                    {
                                        CollaboratorId = collaborator.CollaboratorId,
                                        CollectionId = collection.Id,
                                        Email = collaborator.Email,
                                        Name = collaborator.Name,
                                        UserId = collaborator.UserId
                                    });
                            }
                            catch (Exception e)
                            {
                                Logger.Instance.Error("Failed to add collaborator to collection with Id " + collection.Id + " due to exception " + e.Message);
                                continue;
                            }
                        }
                    }

                    var s3Helper = new AmazonS3Helper();
                    CollectionViewModel collectionViewModel = new CollectionViewModel
                    {
                        Id = collection.Id,
                        Items = collection.Items.Select(item => new CollectionItemViewModel()
                        {
                            CollectionId = item.CollectionId,
                            CreateDate = item.CreateDate.ToString("yyyy-MM-dd HH:mm:ss"),
                            Id = item.Id,
                            Media = s3Helper.ReplaceMediaLinks(item.Media.ToList()),
                            Name = item.Name,
                            Barcode = item.Barcode,
                            Volume = item.Volume
                        }).ToList(),
                        Name = collection.Name,
                        Notes = collection.Notes,
                        CreateAt = collection.CreateAt.ToString("yyyy-MM-dd HH:mm:ss"),
                        City = collection.City,
                        HomeId = collection.HomeId,
                        HomeLatitude = collection.HomeLatitude,
                        HomeLongitude = collection.HomeLongitude,
                        HomeName = collection.HomeName,
                        RoomId = collection.RoomId,
                        RoomName = collection.RoomName,
                        RoomPartId = collection.RoomPartId,
                        RoomPartName = collection.RoomPartName,
                        Address = collection.Address,
                        Barcode = collection.Barcode,
                        Volume = collection.Volume,
                        CollectionLevelPermissions = CollectionLevel.GetCollectionLevelMask(UserRole, User.Identity.GetUserId() != collection.UserId, collection.IsShedCollection),
                        LocationLevelPermissions = collection.LocationLevelPermissions,
                        BinNumber = collection.BinNumber,
                        StorageLocation = collection.StorageLocation
                    };
                    return Json(new { Status = "Success", Collection = collectionViewModel });
                }
                else
                {
                    return Json(new { Status = "Error", Errors = new string[] { "Failed to create collection" } });
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AddCollection' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'PutCollection' method finished");
                #endif
            }
        }

        //POST api/Items/Collection
        [Route("Collection")]
        [ResponseType(typeof(CollectionViewModel))]
        public async Task<IHttpActionResult> PostCollection(UpdateCollectionViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'PostCollection' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'PostCollection' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var dbCollection = _itemsService.GetCollection(User.Identity.GetUserId(), UserRole, model.Id);
                if (dbCollection != null && dbCollection.Status == STATUS_DELIVERED) throw new Exception("This collection is delivered, therefore can't be changed.");

                var s3Helper = new AmazonS3Helper();
                var collection = _itemsService.UpdateCollection(User.Identity.GetUserId(), model.Id, model.Name, model.HomeId, model.RoomId, model.RoomPartId, model.Notes, model.Barcode, model.Volume, UserRole, model.StorageLocation, model.BinNumber);
                if (collection != null)
                {
                    CollectionViewModel collectionViewModel = new CollectionViewModel
                    {
                        Id = collection.Id,
                        Items = collection.Items.Select(item => new CollectionItemViewModel()
                        {
                            CollectionId = item.CollectionId,
                            CreateDate = item.CreateDate.ToString("yyyy-MM-dd HH:mm:ss"),
                            Id = item.Id,
                            Media = s3Helper.ReplaceMediaLinks(item.Media.ToList()),
                            Name = item.Name,
                            Barcode = item.Barcode,
                            Volume = item.Volume
                        }).ToList(),
                        Name = collection.Name,
                        Notes = collection.Notes,
                        CreateAt = collection.CreateAt.ToString("yyyy-MM-dd HH:mm:ss"),
                        City = collection.City,
                        HomeId = collection.HomeId,
                        HomeLatitude = collection.HomeLatitude,
                        HomeLongitude = collection.HomeLongitude,
                        HomeName = collection.HomeName,
                        RoomId = collection.RoomId,
                        RoomName = collection.RoomName,
                        RoomPartId = collection.RoomPartId,
                        RoomPartName = collection.RoomPartName,
                        Address = collection.Address,
                        Barcode = collection.Barcode,
                        Volume = collection.Volume,
                        CollectionLevelPermissions = CollectionLevel.GetCollectionLevelMask(UserRole, User.Identity.GetUserId() != collection.UserId, collection.IsShedCollection),
                        LocationLevelPermissions = collection.LocationLevelPermissions,
                        BinNumber = collection.BinNumber,
                        StorageLocation = collection.StorageLocation
                    };
                    return Json(new { Status = "Success", Collection = collectionViewModel });
                }
                else
                {
                    return Json(new { Status = "Error", Errors = new string[] { "Failed to create collection" } });
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AddCollection' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'PostCollection' method finished");
                #endif
            }
        }
        
        // GET api/Items/UserCollections
        [Route("UserCollections")]
        [ResponseType(typeof(List<CollectionViewModel>))]
        public async Task<IHttpActionResult> GetUserCollections(int count, int offset)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetUserCollections' method started");
            #endif
            try
            {
                if (count <= 0)
                    count = 10;

                ICollection<ItemsService.Collection> result = null;
                var userId = User.Identity.GetUserId();

                if (_jobService.HasJobStarted(userId))
                {
                    result = _itemsService.GetUserJobCollections(userId, UserRole).Where(x => x.Status != STATUS_DELIVERED).ToList();
                }
                else
                {
                    result = _itemsService.GetUserCollections(userId, UserRole).Where(x => x.Status != STATUS_DELIVERED).ToList();
                }

                var collections = MapToCollectionViewModels(userId, result);
                return Json(new { Status = "Success", Collections = collections.Skip(offset).Take(count) });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetUserCollections' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetUserCollections' method finished");
                #endif
            }
        }

        // GET api/Items/JobCollections
        [Route("JobCollections")]
        [ResponseType(typeof(List<CollectionViewModel>))]
        public async Task<IHttpActionResult> GetJobCollections(Guid jobId)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetJobCollections' method started");
            #endif

            try
            {
                var userId = User.Identity.GetUserId();
                ICollection<ItemsService.Collection> result = _itemsService.GetJobCollections(userId, UserRole, jobId);

                var collections = MapToCollectionViewModels(userId, result);
                return Json(new { Status = "Success", Collections = collections.OrderBy(x => x.IsLoaded) });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetJobCollections' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetJobCollections' method finished");
                #endif
            }
        }
        
        //POST api/Item/UpdateItems
        [Route("UpdateItems")]
        public async Task<IHttpActionResult> UpdateItems(UpdateItemsViewModel items)
        {
            #if DEBUG
                Logger.Instance.Info("Call 'UpdateItems' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'UpdateItems' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }
            try
            {
                //var userId = User.Identity.GetUserId();
                //if (!_collectionService.CanUserPerformCollectionOperation(userId, items.CollectionId))
                //{
                //    return Json(new { Status = "Error", Errors = new string[] { "These items have been moved to another collection" } });
                //}
                var dbCollection = _itemsService.GetCollection(User.Identity.GetUserId(), UserRole, items.CollectionId);
                if (dbCollection != null && dbCollection.Status == STATUS_DELIVERED) throw new Exception("This collection is delivered, therefore can't be changed.");

                _itemsService.UpdateItemsCollection(User.Identity.GetUserId(), UserRole, items.ItemsId, items.CollectionId);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'UpdateItems' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                    Logger.Instance.Info("Call 'UpdateItems' method finished");
                #endif
            }
        }

        // POST api/Items/RemoveItem
        [Route("RemoveItem")]
        public async Task<IHttpActionResult> RemoveItem(DeleteItemViewMode model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RemoveItem' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'RemoveItem' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                if (!_jobService.IsActionEnabledForItem(model.ItemId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This action cannot be performed for completed jobs." } });
                }

                var item = _itemsService.GetItem(model.ItemId);

                if (item != null && item.CollectionId.HasValue)
                {
                    var userId = User.Identity.GetUserId();
                    if (!_collectionService.CanUserPerformCollectionOperation(userId, item.CollectionId.Value))
                    {
                        return Json(new { Status = "Error", Errors = new string[] { "This item has been moved to another collection" } });
                    }

                    _itemsService.EnsureCanDeleteItem(User.Identity.GetUserId(), UserRole, item.CollectionId.Value);

                    if (item.Status != STATUS_IS_NOT_ADDED_TO_REQUEST)
                    {
                        if (item.Status == STATUS_DELIVERED) throw new Exception("This item is delivered, therefore can't be removed.");
                        throw new Exception("Cannot delete item. The item is added to a delivery request");
                    }
                }

                AmazonS3Helper s3Helper = new AmazonS3Helper();
                foreach (var media in item.Media)
                {
                    s3Helper.DeleteMedia(media);
                }

                _itemsService.DeleteItem(User.Identity.GetUserId(), UserRole, model.ItemId);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveItem' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RemoveItem' method finished");
                #endif
            }
        }

        //POST api/Items/AttachMediaToItem
        [Route("AttachMediaToItem")]
        public async Task<IHttpActionResult> AttachMediaToItem(AttachMediaToItemViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'AttachMediaToItem' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'AttachMediaToItem' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                _itemsService.AttachMediaToItem(model.MediaId, model.ItemId);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AttachMediaToItem' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'AttachMediaToItem' method finished");
                #endif
            }
        }

        // DELETE api/Items/Collection
        [Route("Collection")]
        public async Task<IHttpActionResult> DeleteCollection(Guid id)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'DeleteCollection' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'DeleteCollection' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var collection = _itemsService.GetCollection(User.Identity.GetUserId(), UserRole, id);
                if (collection != null)
                {
                    if (collection.Status != STATUS_IS_NOT_ADDED_TO_REQUEST || collection.Items.Any(x => x.Status != STATUS_IS_NOT_ADDED_TO_REQUEST))
                    {
                        if (collection.Status == STATUS_DELIVERED) throw new Exception("This collection is delivered, therefore can't be removed.");
                        throw new Exception("Cannot delete collection. The collection is added to a delivery request");
                    }
                }

                if (!_jobService.IsActionEnabledForCollection(id))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "This action cannot be performed for completed jobs." } });
                }

                _itemsService.EnsureCanRemoveCollection(UserRole, collection.UserId != User.Identity.GetUserId(), collection.IsShedCollection);

                AmazonS3Helper s3Helper = new AmazonS3Helper();

                foreach(var item in collection.Items)
                {
                    foreach (var media in item.Media)
                    {
                        s3Helper.DeleteMedia(media);
                    }
                }
                _itemsService.RemoveCollection(User.Identity.GetUserId(), UserRole, id);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveCollection' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'DeleteCollection' method finished");
                #endif
            }
        }

        //POST api/Items/RenameCollectionItem
        [Route("RenameCollectionItem")]
        public async Task<IHttpActionResult> RenameCollectionItem(RenameCollectionItemViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RenameCollectionItem' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'RenameCollectionItem' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var item = _itemsService.GetItem(model.ItemId);
                if (item != null && item.Status == STATUS_DELIVERED) throw new Exception("This item is delivered, therefore can't be changed.");

                _itemsService.RenameCollectionItem(User.Identity.GetUserId(), UserRole, model.ItemId, model.Name);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RenameCollectionItem' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
        }

        //POST api/Items/UpdateCollectionItemInfo
        [Route("UpdateCollectionItemInfo")]
        public async Task<IHttpActionResult> UpdateCollectionItemInfo(UpdateCollectionItemInfo model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'UpdateCollectionItemInfo' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = (from item in ModelState.Values from error in item.Errors select error.ErrorMessage).ToList();
                Logger.Instance.Error("Validation error in 'UpdateCollectionItemInfo' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var item = _itemsService.GetItem(model.ItemId);
                if (item != null && item.Status == STATUS_DELIVERED) throw new Exception("This item is delivered, therefore can't be changed.");

                _itemsService.UpdateCollectionItemInfo(User.Identity.GetUserId(), UserRole, model.ItemId, model.Name, model.Barcode, model.Volume);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'UpdateCollectionItemInfo' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
        }

        // GET api/Items/Search
        [Route("Search")]
        [ResponseType(typeof(List<CollectionViewModel>))]
        public async Task<IHttpActionResult> GetSearch(string query)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetSearch' method started");
            #endif
            try
            {
                var userId = User.Identity.GetUserId();
                var result = _itemsService.Search(userId, query, UserRole).Where(x => x.Status != STATUS_DELIVERED).ToList();
                var collections = new List<CollectionViewModel>();
                var usersService = new UsersService();
                var s3Helper = new AmazonS3Helper();
                foreach (var collection in result)
                {
                    foreach (var collaborator in collection.Collaborators.Where(x => x.UserId != userId))
                    {
                        if (string.IsNullOrEmpty(collaborator.Email) || string.IsNullOrEmpty(collaborator.Name))
                        {
                            var user = usersService.GetUserById(collaborator.UserId);
                            collaborator.Email = user.Email;
                            collaborator.Name = user.Name;
                        }
                    }

                    var drCollection = _deliveryService.GetDeliveryRequestCollectionForWebAPI(User.Identity.GetUserId(), collection.Id);
                    collections.Add(new CollectionViewModel
                    {
                        Id = collection.Id,
                        Name = collection.Name,
                        Notes = collection.Notes,
                        CreateAt = collection.CreateAt.ToString("yyyy-MM-dd HH:mm:ss"),
                        City = collection.City,
                        HomeId = collection.HomeId,
                        HomeLatitude = collection.HomeLatitude,
                        HomeLongitude = collection.HomeLongitude,
                        HomeName = collection.HomeName,
                        RoomId = collection.RoomId,
                        RoomName = collection.RoomName,
                        RoomPartId = collection.RoomPartId,
                        RoomPartName = collection.RoomPartName,
                        Items = collection.Items.Where(x => x.Status != STATUS_DELIVERED).Select(item => new CollectionItemViewModel()
                        {
                            CollectionId = item.CollectionId,
                            CreateDate = item.CreateDate.ToString("yyyy-MM-dd HH:mm:ss"),
                            Id = item.Id,
                            Media = s3Helper.ReplaceMediaLinks(FilterVideoChapter(item.Media.ToList(), drCollection != null)),
                            Name = item.Name,
                            Barcode = item.Barcode,
                            Volume = item.Volume,
                            Status = drCollection != null ? item.Status : 0,
                        }).ToList(),
                        Address = collection.Address,
                        Barcode = collection.Barcode,
                        Volume = collection.Volume,
                        CollectionLevelPermissions = CollectionLevel.GetCollectionLevelMask(UserRole, User.Identity.GetUserId() != collection.UserId, collection.IsShedCollection),
                        LocationLevelPermissions = collection.LocationLevelPermissions,
                        Status = drCollection != null ? drCollection.Status : 0,
                        RequestId = drCollection?.DeliveryRequestId,
                        StorageLocation = collection.StorageLocation,
                        BinNumber = collection.BinNumber,
                        Photo = GetCollectionPhoto(collection.PhotoFileName, s3Helper)
                    });
                }

                return Json(new { Status = "Success", Collections = collections });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetSearch' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetSearch' method finished");
                #endif
            }
        }

        // GET api/Items/HomesWithCounts
        [Route("HomesWithCounts")]
        public async Task<IHttpActionResult> GetHomesWithCounts()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetHomesWithCounts' method started");
            #endif
            try
            {
                var userId = User.Identity.GetUserId();
                var result = _itemsService.GetUserHomesWithItemsCount(userId, UserRole).Select(x => new HomeWithCountsViewModel
                {
                    Id = x.Id,
                    ItemsCount = x.ItemsCount,
                    Latitude = x.Latitude,
                    Longitude = x.Longitude,
                    Name = x.Name
                });
                return Json(new { Status = "Success", Homes = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetHomesWithCounts' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetHomesWithCounts' method finished");
                #endif
            }
        }

        // GET api/Items/HomeCollections
        [Route("HomeCollections")]
        public async Task<IHttpActionResult> GetHomeCollections(Guid homeId)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetHomeCollections' method started");
            #endif
            try
            {
                var result = new List<CollectionViewModel>();
                var s3Helper = new AmazonS3Helper();
                var userId = User.Identity.GetUserId();
                var collections = _itemsService.GetUserCollections(userId, UserRole).Where(x => x.HomeId == homeId && x.Status != STATUS_DELIVERED).ToList();

                foreach (var collection in collections)
                {
                    var drCollection = _deliveryService.GetDeliveryRequestCollectionForWebAPI(User.Identity.GetUserId(), collection.Id);
                    result.Add(new CollectionViewModel
                    {
                        Id = collection.Id,
                        Name = collection.Name,
                        Notes = collection.Notes,
                        CreateAt = collection.CreateAt.ToString("yyyy-MM-dd HH:mm:ss"),
                        City = collection.City,
                        HomeId = collection.HomeId,
                        HomeLatitude = collection.HomeLatitude,
                        HomeLongitude = collection.HomeLongitude,
                        HomeName = collection.HomeName,
                        RoomId = collection.RoomId,
                        RoomName = collection.RoomName,
                        RoomPartId = collection.RoomPartId,
                        RoomPartName = collection.RoomPartName,
                        Items = collection.Items.Where(x => x.Status != STATUS_DELIVERED).Select(item => new CollectionItemViewModel()
                        {
                            CollectionId = item.CollectionId,
                            CreateDate = item.CreateDate.ToString("yyyy-MM-dd HH:mm:ss"),
                            Id = item.Id,
                            Media = s3Helper.ReplaceMediaLinks(FilterVideoChapter(item.Media.ToList(), drCollection != null)),
                            Name = item.Name,
                            Barcode = item.Barcode,
                            Volume = item.Volume,
                            Status = drCollection != null ? item.Status : 0,
                        }).ToList(),
                        Address = collection.Address,
                        Barcode = collection.Barcode,
                        Volume = collection.Volume,
                        CollectionLevelPermissions = CollectionLevel.GetCollectionLevelMask(UserRole, User.Identity.GetUserId() != collection.UserId, collection.IsShedCollection),
                        LocationLevelPermissions = collection.LocationLevelPermissions,
                        Status = drCollection != null ? drCollection.Status : 0,
                        RequestId = drCollection?.DeliveryRequestId,
                        StorageLocation = collection.StorageLocation,
                        BinNumber = collection.BinNumber,
                        Photo = GetCollectionPhoto(collection.PhotoFileName, s3Helper)
                    });
                }
                
                return Json(new { Status = "Success", Collections = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetHomeCollections' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetHomeCollections' method finished");
                #endif
            }
        }

        // POST api/Items/ValidateBarcode
        [Route("ValidateBarcode")]
        public async Task<IHttpActionResult> ValidateBarcode(ValidateBarcodeViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'ValidateBarcode' method started");
            #endif

            try
            {
                var isDuplicated = _itemsService.ExistBarcode(model.Barcode);
                return Json(new { Status = "Success", IsDuplicated = isDuplicated });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'ValidateBarcode' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'ValidateBarcode' method finished");
                #endif
            }
        }

        // POST api/Items/Load
        [Route("Load")]
        public async Task<IHttpActionResult> Load(LoadViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'LoadItems' method started");
            #endif

            try
            {
                _itemsService.Load(User.Identity.GetUserId(), model.CollectionIds, model.ItemIds);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'LoadItems' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'LoadItems' method finished");
                #endif
            }
        }

        private List<CollectionViewModel> MapToCollectionViewModels(string userId, ICollection<ItemsService.Collection> itemsServiceCollections)
        {
            var collections = new List<CollectionViewModel>();
            var usersService = new UsersService();
            var s3Helper = new AmazonS3Helper();
            foreach (var collection in itemsServiceCollections)
            {
                foreach (var collaborator in collection.Collaborators.Where(x => x.UserId != userId))
                {
                    if (string.IsNullOrEmpty(collaborator.Email) || string.IsNullOrEmpty(collaborator.Name))
                    {
                        var user = usersService.GetUserById(collaborator.UserId);
                        collaborator.Email = user.Email;
                        collaborator.Name = user.Name;
                    }
                }

                var drCollection = _deliveryService.GetDeliveryRequestCollectionForWebAPI(User.Identity.GetUserId(), collection.Id);
                collections.Add(new CollectionViewModel
                {
                    Id = collection.Id,
                    Name = collection.Name,
                    OwnerFirstName = collection.OwnerFirstName,
                    OwnerLastName = collection.OwnerLastName,
                    Notes = collection.Notes,
                    CreateAt = collection.CreateAt.ToString("yyyy-MM-dd HH:mm:ss"),
                    City = collection.City,
                    HomeId = collection.HomeId,
                    HomeLatitude = collection.HomeLatitude,
                    HomeLongitude = collection.HomeLongitude,
                    HomeName = collection.HomeName,
                    RoomId = collection.RoomId,
                    RoomName = collection.RoomName,
                    RoomPartId = collection.RoomPartId,
                    RoomPartName = collection.RoomPartName,
                    Items = collection.Items.Where(x => x.Status != STATUS_DELIVERED).Select(item => new CollectionItemViewModel()
                    {
                        CollectionId = item.CollectionId,
                        CreateDate = item.CreateDate.ToString("yyyy-MM-dd HH:mm:ss"),
                        Id = item.Id,
                        Media = s3Helper.ReplaceMediaLinks(FilterVideoChapter(item.Media.ToList(), drCollection != null)),
                        Name = item.Name,
                        Barcode = item.Barcode,
                        Volume = item.Volume,
                        Status = drCollection != null ? item.Status : 0,
                        IsLoaded = item.IsLoaded
                    }).ToList(),
                    Address = collection.Address,
                    Barcode = collection.Barcode,
                    Volume = collection.Volume,
                    CollectionLevelPermissions = CollectionLevel.GetCollectionLevelMask(UserRole, User.Identity.GetUserId() != collection.UserId, collection.IsShedCollection),
                    LocationLevelPermissions = collection.LocationLevelPermissions,
                    Status = drCollection != null ? drCollection.Status : 0,
                    RequestId = drCollection?.DeliveryRequestId,
                    StorageLocation = collection.StorageLocation,
                    BinNumber = collection.BinNumber,
                    Photo = GetCollectionPhoto(collection.PhotoFileName, s3Helper),
                    IsLoaded = collection.IsLoaded
                });
            }

            return collections;
        }

        private List<MediaService.MediaModel> FilterVideoChapter(List<MediaService.MediaModel> mediaModels, bool addedToDeliveryRequest)
        {
            foreach (var media in mediaModels.Where(x => x.Chapters != null && x.Chapters.Any()))
            {
                media.Chapters = media.Chapters.Where(c => c.Status != STATUS_DELIVERED).ToList();
                media.Chapters.ForEach(x => x.Status = addedToDeliveryRequest ? x.Status : 0);
            }

            return mediaModels;
        }

        private GetCollectionPhotoViewModel GetCollectionPhoto(string fileName, AmazonS3Helper s3Helper)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return new GetCollectionPhotoViewModel();
            }

            return new GetCollectionPhotoViewModel
            {
                ImagePath = s3Helper.getUrl(fileName),
                PreviewImagePath = s3Helper.GetPreviewUrl(fileName)
            };
        }
    }
}