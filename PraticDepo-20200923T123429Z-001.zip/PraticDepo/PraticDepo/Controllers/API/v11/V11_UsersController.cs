﻿using PraticDepo.BusinessLayer.Users;
using PraticDepo.Helpers;
using PraticDepo.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Security;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using System.Text;
using System.Text.RegularExpressions;
using PraticDepo.BusinessLayer.Item;
using PraticDepo.Web.Common.Helpers;
using PraticDepo.Web.Common.Configs;
using PraticDepo.Attributes;
using PraticDepo.DAL.Models;

namespace PraticDepo.Web.Controllers.API.v11
{
    [ApiAuthorizeV11]
    [RoutePrefix("api/v1.1/Users")]
    public class V11_UsersController : BaseApiController
    {
        UsersService usersService = new UsersService();
        ItemsService itemService = new ItemsService();

        public ApplicationUserManager UserManager
        {
            get
            {
                return Request.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
        }

        // PUT api/Users/Collaborator
        [Route("Collaborator")]
        public async Task<IHttpActionResult> PutCollaborator(PutCollaboratorViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'PutCollaborator' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(!string.IsNullOrEmpty(error.ErrorMessage) ? error.ErrorMessage : error.Exception.Message);
                }
                Logger.Instance.Error("Validation error in 'PutCollaborator' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }
            try
            {
                if (string.IsNullOrEmpty(model.Name) && string.IsNullOrEmpty(model.Email) || string.IsNullOrWhiteSpace(model.Name) && string.IsNullOrWhiteSpace(model.Email))
                {
                    throw new Exception("Name and email required");
                }
                if (string.IsNullOrEmpty(model.Name) || string.IsNullOrWhiteSpace(model.Name))
                {
                    throw new Exception("Name required");
                }
                if (string.IsNullOrEmpty(model.Email) || string.IsNullOrWhiteSpace(model.Email))
                {
                    throw new Exception("Email required");
                }

                usersService.EnsureCanManageCollaborators(User.Identity.GetUserId(), UserRole);

                var collaboratorId = await new CollaboratorsHelper().AddCollaborator(
                    UserManager,
                    User.Identity.GetUserId(),
                    new AddUserCollaboratorViewModel() { Email = model.Email, Name = model.Name, CollectionId = Guid.Empty });
                return Json(new { Status = "Success", CollaboratorId = collaboratorId });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'PutCollaborator' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'PutCollaborator' method finished");
                #endif
            }
        }

        // POST api/Users/AddCollaborator
        [Route("AddCollaborator")]
        public async Task<IHttpActionResult> AddCollaborator(AddUserCollaboratorViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'AddCollaborator' method started");
            #endif

            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(!string.IsNullOrEmpty(error.ErrorMessage) ? error.ErrorMessage : error.Exception.Message);
                }
                Logger.Instance.Error("Validation error in 'AddCollaborator' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                if (model.CollaboratorId == null || model.CollaboratorId == Guid.Empty)
                {
                    if (string.IsNullOrEmpty(model.UserId) && (string.IsNullOrEmpty(model.Email) || string.IsNullOrEmpty(model.Name)))
                        return Json(new { Status = "Invalid", Errors = new string[] { "Need to specify UserId or user name and email" } });
                }

                var collection = itemService.GetCollection(User.Identity.GetUserId(), UserRole, model.CollectionId);
                usersService.EnsureCanManageCollaborators(User.Identity.GetUserId(), UserRole, collection);
                usersService.EnsureCanAddCollaborator(User.Identity.GetUserId(), UserRole, collection, model.UserId);

                var collaboratorId = await new CollaboratorsHelper().AddCollaborator(UserManager, User.Identity.GetUserId(), model);
                
                #if DEBUG
                Logger.Instance.Info(string.Format("User '{0}' added as collaborator for collection '{1}'", User.Identity.GetUserId(), model.CollectionId));
                #endif

                return Json(new { Status = "Success", CollaboratorId = collaboratorId });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AddCollaborator' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'AddCollaborator' method finished");
                #endif
            }
        }

        // DELETE api/Users/DeleteCollaborator
        [Route("Collaborator")]
        public async Task<IHttpActionResult> DeleteCollaborator(Guid collaboratorId, Guid? collectionId = null)
        {
            try
            {
                if (collaboratorId == Guid.Empty)
                {
                    throw new Exception("CollaboratorId cannot be empty");
                }

                List<Guid> collectionIds = new List<Guid>();

                if (collectionId.HasValue)
                {
                    collectionIds.Add(collectionId.Value);
                }
                else
                {
                    collectionIds.AddRange(usersService.GetCollectionsByCollaboratorIdAndUserId(User.Identity.GetUserId(), collaboratorId));
                }

                if (collectionIds.Count > 0)
                {
                    foreach (var id in collectionIds)
                    {
                        usersService.DeleteCollaborator(User.Identity.GetUserId(), UserRole, collaboratorId, id);
                        var collaborator = usersService.GetCollaboratorInfo(collaboratorId);
                        var collection = itemService.GetCollectionById(id);
                        /*
                        await UserManager.SendEmailAsync(collaborator.Id, "You were removed from the collection",
                                                         string.Format("Hi, {0},<br /> {1} has removed you from the collection <strong>{2}</strong>.", User.Identity.Name, collaborator.Name, collection.Name));
                        */
                    }
                }

                usersService.DeleteCollaboratorUser(User.Identity.GetUserId(), collaboratorId);

                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'DeleteCollaborator' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'DeleteCollaborator' method finished");
                #endif
            }
        }
        
        private async Task<string> CreateCollaboratorUser(string email, string name)
        {
            var names = name.Split(" ".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            var firstName = names[0];
            var lastName = names.Length > 1 ? names[1] : string.Empty;

            var password = Membership.GeneratePassword(8, 0);
            password = Regex.Replace(password, @"[^a-zA-Z0-9]", m => "9");

            var user = new ApplicationUser
            {
                FirstName = firstName,
                LastName = lastName,
                Email = email,
                UserName = email
            };

            var result = await UserManager.CreateAsync(user, password);
            if (!result.Succeeded)
                throw new CreateCollaboratorException("Can't create collaborator user", result.Errors.ToArray());

            await UserManager.SendEmailAsync(
                user.Id,
                "Your registration in PraticDepo",
                string.Format("Hi, <br />You have been invited to PratikDepo app. <br/>Your login: {0} , your password: {1}<br/><a href=\"#\">Click here</a> to download the app.", user.Email, password));

            return user.Id;
        }

        private async Task<ApplicationUser> CheckUserExist(string email)
        {
            if (string.IsNullOrEmpty(email))
                return null;
            return await UserManager.FindByEmailAsync(email);
        }

        private async Task SendMessage(string userId)
        {
            var inviter = UserManager.FindByName(User.Identity.Name);
            var inviterName = string.Format("{0} {1}", inviter.FirstName, inviter.LastName);
            var inviterEmail = inviter.Email;

            var invited = UserManager.FindById(userId);
            var invitedName = string.Format("{0} {1}", invited.FirstName, invited.LastName);

            var message = new StringBuilder();
            message.AppendFormat("Dear {0},{1}", invitedName, Environment.NewLine);
            message.AppendFormat("You have been invited as collection collaborator from {0}[{1}]. ", inviterName, inviterEmail, Environment.NewLine);

            await UserManager.SendEmailAsync(userId, "You have been invited as collection collaborator", "");
        }

        //GET api/Users/UsersCollectionsCollaborators
        [Route("UsersCollectionsCollaborators")]
        public async Task<IHttpActionResult> GetUsersCollectionsCollaborators()
        {
#if DEBUG
            Logger.Instance.Info("Call 'GetUsersCollectionsCollaborators' method started");
#endif
            try
            {
                var userId = User.Identity.GetUserId();
                var collaborators = usersService.GetUserCollectionsCollaborators(userId, UserRole);

                foreach (var user in collaborators.Where(x => !string.IsNullOrEmpty(x.UserId)))
                {
                    var usr = UserManager.FindById(user.UserId);
                    user.Email = UserManager.GetEmail(user.UserId);
                    user.Name = string.Format("{0} {1}", usr.FirstName, usr.LastName).Trim();
                }

                return Json(new { Status = "Success", Collaborators = collaborators.Where(x => x.UserId != userId) });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetUsersCollectionsCollaborators' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
#if DEBUG
                Logger.Instance.Info("Call 'GetUsersCollectionsCollaborators' method finished");
#endif
            }
        }

        //GET api/Users/Collaborators
        [Route("Collaborators")]
        public async Task<IHttpActionResult> GetCollaborators()
        {
#if DEBUG
            Logger.Instance.Info("Call 'GetCollaborators' method started");
#endif
            try
            {
                var userId = User.Identity.GetUserId();
                var collaborators = usersService.GetUserCollaborators(userId);

                foreach (var user in collaborators.Where(x => !string.IsNullOrEmpty(x.UserId)))
                {
                    var usr = UserManager.FindById(user.UserId);
                    user.Email = UserManager.GetEmail(user.UserId);
                    user.Name = string.Format("{0} {1}", usr.FirstName, usr.LastName).Trim();
                }

                return Json(new { Status = "Success", Collaborators = collaborators.Where(x => x.UserId != userId) });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetCollaborators' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
#if DEBUG
                Logger.Instance.Info("Call 'GetCollaborators' method finished");
#endif
            }
        }
    }

    public class CreateCollaboratorException : Exception
    {
        public string[] Errors { get; set; }

        public CreateCollaboratorException()
            : base()
        { }

        public CreateCollaboratorException(string message, Exception exception = null)
            : base(message, exception)
        {
        }

        public CreateCollaboratorException(string message, string[] errors, Exception exception = null)
            : base(message, exception)
        {
            Errors = errors;
        }

        public override string ToString()
        {
            var allErrors = string.Empty;
            foreach (var error in Errors)
                allErrors += error + Environment.NewLine;

            return string.Format("{0}. Error details: {1}. StackTrace: {2}", Message, allErrors, StackTrace);
        }
    }
}