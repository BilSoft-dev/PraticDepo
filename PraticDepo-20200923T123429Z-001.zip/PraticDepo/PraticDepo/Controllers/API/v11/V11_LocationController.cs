﻿using PraticDepo.BusinessLayer.Item;
using PraticDepo.BusinessLayer.Permissions;
using PraticDepo.Web.Models;
using PraticDepo.Web.Common.Helpers;
using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNet.Identity;
using System.Web.Http.Description;
using PraticDepo.Attributes;

namespace PraticDepo.Web.Controllers.API.v11
{
    [ApiAuthorizeV11]
    [RoutePrefix("api/v1.1/Location")]
    public class V11_LocationController : BaseApiController
    {
        LocationService locationService = new LocationService();

        // POST api/Location/AddHome
        [Route("AddHome")]
        public async Task<IHttpActionResult> AddHome(NewHomeViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'AddHome' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'AddHome' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var userId = User.Identity.GetUserId();
                var homeId = locationService.AddNewHome(new GeoCoordinate(model.Latitude, model.Longitude), model.Name, userId, model.City, UserRole);
                
                Logger.Instance.Info(string.Format("User with id '{0}' create home called '{2}'(id: '{1}').", userId, homeId, model.Name));
                return Json(new { Status = "Success", HomeId = homeId });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AddHome' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'AddHome' method finished");
                #endif
            }
        }

        // POST api/Location/AddRoom
        [Route("AddRoom")]
        public async Task<IHttpActionResult> AddRoom(NewRoomViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'AddRoom' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'AddRoom' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var roomId = locationService.AddRoom(model.HomeId, model.Name, User.Identity.GetUserId(), UserRole);

                return Json(new { Status = "Success", RoomId = roomId });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AddRoom' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'AddRoom' method finished");
                #endif
            }
        }

        // POST api/Location/AddRoomPart
        [Route("AddRoomPart")]
        public async Task<IHttpActionResult> AddRoomPart(NewRoomPartViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'AddRoomPart' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'AddRoomPart' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var roomPartId = locationService.AddRoomPart(model.RoomId, model.Name, User.Identity.GetUserId(), UserRole);

                return Json(new { Status = "Success", RoomPartId = roomPartId });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AddRoomPart' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'AddRoomPart' method finished");
                #endif
            }
        }

        // GET api/Location/UserHomes
        [Route("UserHomes")]
        [ResponseType(typeof(List<_HomeViewModel>))]
        public async Task<IHttpActionResult> GetUserHomes(double latitude, double longitude)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetUserHomes' method started");
            #endif
            try
            {
                var userId = User.Identity.GetUserId();
                if (string.IsNullOrEmpty(userId))
                    return Json(new { Status = "Error", Errors = new string[] { "Authorisation error. User ID is null or empty." } });

                var homeList = new List<_HomeViewModel>();
                var homes = locationService.GetUserHomes(userId, UserRole);

                var itemsService = new ItemsService();
                var s3Helper = new AmazonS3Helper();
                var userCollections = itemsService.GetUserCollections(userId, UserRole).Select(collection => new CollectionViewModel
                {
                    Id = collection.Id,
                    Items = collection.Items.ToList().Select(item => new CollectionItemViewModel
                    {
                        CollectionId = item.CollectionId,
                        CreateDate = item.CreateDate.ToString("yyyy-MM-dd HH:mm:ss"),
                        Id = item.Id,
                        Media = s3Helper.ReplaceMediaLinks(item.Media.ToList()),
                        Name = item.Name,
                        Barcode = item.Barcode,
                        Volume = item.Volume
                    }).ToList(),
                    Name = collection.Name,
                    Notes = collection.Notes,
                    CreateAt = collection.CreateAt.ToString("yyyy-MM-dd HH:mm:ss"),
                    HomeLatitude = collection.HomeLatitude,
                    HomeLongitude = collection.HomeLongitude,
                    City = collection.City,
                    HomeId = collection.HomeId,
                    HomeName = collection.HomeName,
                    RoomId = collection.RoomId,
                    RoomName = collection.RoomName,
                    RoomPartId = collection.RoomPartId,
                    RoomPartName = collection.RoomPartName,
                    Address = collection.Address,
                    Barcode = collection.Barcode,
                    Volume = collection.Volume,
                    CollectionLevelPermissions = CollectionLevel.GetCollectionLevelMask(UserRole, User.Identity.GetUserId() != collection.UserId, collection.IsShedCollection),
                    LocationLevelPermissions = collection.LocationLevelPermissions
                }).ToList();

                
                GeoCoordinate coord = new GeoCoordinate(latitude, longitude);
                foreach (var home in homes)
                {
                    var homeCoord = new GeoCoordinate(home.Latitude, home.Longitude);
                    try
                    {
                        homeList.Add(new _HomeViewModel
                        {
                            Id = home.Id,
                            Name = home.Name,
                            Latitude = home.Latitude,
                            Longitude = home.Longitude,
                            IsUserHere = homeCoord.GetDistanceTo(coord) <= 50,
                            City = home.City,
                            CreateAt = home.CreateAt,
                            ReadOnly = home.OwnerId != userId,
                            Permissions = home.Permissions,
                            Collections = userCollections.Where(c => c.HomeId == home.Id).ToList(),
                            Rooms = home.Rooms.Select(r => new _RoomViewModel
                            {
                                HomeId = home.Id,
                                Id = r.Id,
                                Name = r.Name,
                                CreateAt = r.CreateAt,
                                Collections = userCollections.Where(c => c.RoomId == r.Id).ToList(),
                                RoomParts = r.RoomParts.Select(rp => new RoomPartViewModel
                                {
                                    Id = rp.Id,
                                    Name = rp.Name,
                                    RoomId = r.Id,
                                    CreateAt = rp.CreateAt,
                                    Collections = userCollections.Where(c => c.RoomPartId == rp.Id).ToList()
                                }).OrderBy(x => x.Name).ToList()
                            }).OrderBy(x => x.Name).ToList()
                        });
                    }
                    catch(Exception ex)
                    {
                        var a = 0;
                    }
                }

                return Json(new { Status = "Success", Homes = homeList });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetUserHomes' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetUserHomes' method finished");
                #endif
            }
        }

        // GET api/Location/Homes
        [Route("Homes")]
        [ResponseType(typeof(List<Web.Models.Location.HomeViewModel>))]
        public async Task<IHttpActionResult> GetHomes()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetHomes' method started");
            #endif

            try
            {
                var userId = User.Identity.GetUserId();
                if (string.IsNullOrEmpty(userId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "Authorisation error. User ID is null or empty." } });
                }

                var result = new List<Web.Models.Location.HomeViewModel>();
                var homes = locationService.GetHomes(userId, UserRole);
                
                foreach (var home in homes)
                {
                    var homeCoord = new GeoCoordinate(home.Latitude, home.Longitude);

                    try
                    {
                        result.Add(new Web.Models.Location.HomeViewModel
                        {
                            Id = home.Id,
                            Name = home.Name,
                            Latitude = home.Latitude,
                            Longitude = home.Longitude,
                            City = home.City,
                            CreateAt = home.CreateAt,
                            ReadOnly = home.OwnerId != userId,
                            Permissions = home.Permissions
                        });
                    }
                    catch { }
                }

                return Json(new { Status = "Success", Homes = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetHomes' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetHomes' method finished");
                #endif
            }
        }

        // GET api/Location/Homes
        [Route("Rooms")]
        [ResponseType(typeof(List<Web.Models.Location.RoomViewModel>))]
        public async Task<IHttpActionResult> GetRooms(string homeId)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetRooms' method started");
            #endif

            try
            {
                var userId = User.Identity.GetUserId();
                if (string.IsNullOrEmpty(userId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "Authorisation error. User ID is null or empty." } });
                }

                Guid guidHomeId = Guid.Empty;
                if (!Guid.TryParse(homeId, out guidHomeId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "HomeId parameter incorrect format." } });
                }

                var result = new List<Web.Models.Location.RoomViewModel>();
                var rooms = locationService.GetRooms(guidHomeId, userId, UserRole);

                rooms.ForEach(x => result.Add(new Web.Models.Location.RoomViewModel
                {
                    Id = x.Id,
                    Name = x.Name,
                    CreateAt = x.CreateAt
                }));

                return Json(new { Status = "Success", Rooms = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetRooms' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetRooms' method finished");
                #endif
            }
        }

        // GET api/Location/Homes
        [Route("RoomParts")]
        [ResponseType(typeof(List<Web.Models.Location.RoomViewModel>))]
        public async Task<IHttpActionResult> GetRoomParts(string roomId)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetRoomParts' method started");
            #endif

            try
            {
                var userId = User.Identity.GetUserId();
                if (string.IsNullOrEmpty(userId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "Authorisation error. User ID is null or empty." } });
                }

                Guid guidRoomId = Guid.Empty;
                if (!Guid.TryParse(roomId, out guidRoomId))
                {
                    return Json(new { Status = "Error", Errors = new string[] { "RoomId parameter has incorrect format." } });
                }

                var result = new List<Web.Models.Location.RoomViewModel>();
                var rooms = locationService.GetRooms(guidRoomId, userId, UserRole);

                rooms.ForEach(x => result.Add(new Web.Models.Location.RoomViewModel
                {
                    Id = x.Id,
                    Name = x.Name,
                    CreateAt = x.CreateAt
                }));

                return Json(new { Status = "Success", RoomParts = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetRoomParts' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetRoomParts' method finished");
                #endif
            }
        }

        //POST api/Location/RenameHome
        [Route("RenameHome")]
        public async Task<IHttpActionResult> RenameHome(RenameHomeViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RenameHome' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'RenameHome' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                locationService.RenameHome(model.HomeId, model.NewName, User.Identity.GetUserId(), UserRole);

                Logger.Instance.Info(string.Format("Home with Id: {0} renamed to {1}.", model.HomeId, model.NewName));
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RenameHome' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RenameHome' method finished");
                #endif
            }
        }

        //POST api/Location/RenameRoom
        [Route("RenameRoom")]
        public async Task<IHttpActionResult> RenameRoom(RenameRoomViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RenameRoom' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'RenameRoom' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }
                        
            try
            {
                locationService.RenameRoom(model.RoomId, model.NewName, User.Identity.GetUserId(), UserRole);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RenameRoom' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RenameRoom' method finished");
                #endif
            }
        }

        //POST api/Location/RenameRoomPart
        [Route("RenameRoomPart")]
        public async Task<IHttpActionResult> RenameRoomPart(RenameRoomPartViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RenameRoomPart' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'RenameRoomPart' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                locationService.RenameRoom(model.RoomPartId, model.NewName, User.Identity.GetUserId(), UserRole);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RenameRoomPart' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RenameRoomPart' method finished");
                #endif
            }
        }

        //POST api/Location/RemoveHome
        [Route("RemoveHome")]
        public async Task<IHttpActionResult> RemoveHome(DeleteHomeViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RemoveHome' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'RemoveHome' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                locationService.DeleteHome(model.HomeId, User.Identity.GetUserId(), UserRole);

                Logger.Instance.Info(string.Format("Home {0} removed.", model.HomeId));
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveHome' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RemoveHome' method finished");
                #endif
            }
        }

        //POST api/Location/RemoveRoom
        [Route("RemoveRoom")]
        public async Task<IHttpActionResult> RemoveRoom(DeleteRoomViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RemoveRoom' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'RemoveRoom' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                locationService.DeleteRoom(model.RoomId, User.Identity.GetUserId(), UserRole);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveRoom' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RemoveRoom' method finished");
                #endif
            }
        }

        //POST api/Location/RemoveRoomPart
        [Route("RemoveRoomPart")]
        public async Task<IHttpActionResult> RemoveRoomPart(DeleteRoomPartViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RemoveRoomPart' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'RemoveRoomPart' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                locationService.DeleteRoomPart(model.RoomPartId, User.Identity.GetUserId(), UserRole);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveRoomPart' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RemoveRoomPart' method finished");
                #endif
            }
        }

        //POST api/Location/ChangeHomeLocation
        [Route("ChangeHomeLocation")]
        [Obsolete]
        public async Task<IHttpActionResult> ChangeHomeLocation(ChangeHomeLocationViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'ChangeHomeLocation' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'ChangeHomeLocation' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            if (locationService.IsShedLocation(model.HomeId))
            {
                Logger.Instance.Error("Shed Storage home validation error in 'ChangeHomeLocation' method");
                return Json(new { Status = "Invalid", Errors = new string[] { "Shed Storage home can't be changed." } });
            }

            try
            {
                locationService.ChangeHomeLocation(model.HomeId, model.Latitude, model.Longitude, model.City);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'ChangeHomeLocation' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'ChangeHomeLocation' method finished");
                #endif
            }
        }

    }
}
