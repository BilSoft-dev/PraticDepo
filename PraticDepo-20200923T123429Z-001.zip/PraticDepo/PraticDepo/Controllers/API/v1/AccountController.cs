﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OAuth;
using PraticDepo.Web.Models;
using PraticDepo.Web.Providers;
using PraticDepo.Web.Common.Helpers;
using PraticDepo.Web.Common.Configs;
using PraticDepo.Web.Common.Models;
using PraticDepo.Web.Common.Models.Account;
using Microsoft.AspNet.Identity.Owin;
using System.Text.RegularExpressions;
using Microsoft.Owin.Infrastructure;
using PraticDepo.BusinessLayer.Facebook;
using PraticDepo.BusinessLayer.Users;
using PraticDepo.Attributes;
using PraticDepo.DAL.Models;

namespace PraticDepo.Web.Controllers.API.v1
{
    [ApiAuthorize]
    [RoutePrefix("api/Account")]
    public class AccountController : BaseApiController
    {
        private const string LocalLoginProvider = "Local";
        //private static readonly ILog log = LogManager.GetLogger(typeof(AccountController));

        private ApplicationUserManager _userManager;
        private IUser users;
        private UsersService _usersService = new UsersService();
        private FacebookClient facebookClient = new FacebookClient();
        
        public AccountController()
            : this(Startup.UserManagerFactory(), Startup.OAuthOptions.AccessTokenFormat)
        {
        }

        public AccountController(UserManager<IdentityUser> userManager,
            ISecureDataFormat<AuthenticationTicket> accessTokenFormat)
        {
            //UserManager = userManager;
            AccessTokenFormat = accessTokenFormat;

            //UserManager.EmailService = new EmailService();
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return Request.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
        }
        public ISecureDataFormat<AuthenticationTicket> AccessTokenFormat { get; private set; }

        // GET api/Account/UserInfo
        [HostAuthentication(DefaultAuthenticationTypes.ExternalBearer)]
        [Route("UserInfo")]
        [Obsolete]
        public UserInfoViewModel GetUserInfo()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetUserInfo' method started");
            #endif
            try
            {
                ExternalLoginData externalLogin = ExternalLoginData.FromIdentity(User.Identity as ClaimsIdentity);

                return new UserInfoViewModel
                {
                    UserName = User.Identity.GetUserName(),
                    HasRegistered = externalLogin == null,
                    LoginProvider = externalLogin != null ? externalLogin.LoginProvider : null
                };
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetUserInfo' method", ex);
                throw ex;
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetUserInfo' method finished");
                #endif
            }
        }

        // GET api/Account/Info
        [Route("Info")]
        public async Task<IHttpActionResult> GetInfo()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Info' method started");
            #endif
            try
            {
                var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());

                var userInfo = new InfoViewModel()
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email,
                    PhoneNumber = user.PhoneNumber
                };
                return Json(new { Status = "Success", User = userInfo });

            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Info' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Info' method finished");
                #endif
            }
        }

        //POST api/Account/Info
        [Route("Info")]
        public async Task<IHttpActionResult> Info(InfoViewModel userManager)
        {
            var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
            if (user == null)
            {
                return Unauthorized();
            }
            if (!ModelState.IsValid)
            {
                //return BadRequest(ModelState);
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'Info' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }
            try
            {
                user.FirstName = userManager.FirstName;
                user.LastName = userManager.LastName;

                if (!string.IsNullOrEmpty(userManager.Email) && user.Email != userManager.Email)
                {
                    _usersService.EnsureCanEditEmail(UserRole);
                    user.Email = userManager.Email;
                }

                user.PhoneNumber = userManager.PhoneNumber;
                user.UserName = userManager.Email;
                
                IdentityResult result = UserManager.Update(user);

                if (!result.Succeeded)
                {
                    if(result.Errors.Any(x => x.Contains("is already taken")))
                    {
                        return Json(new { Status = "Error", Errors = new string[] { "This email address is already being used. Please enter another email address." } });
                    }
                    else
                    {
                        return Json(new { Status = "Error", Errors = result.Errors });
                    }
                }
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Info' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetExternalLogins' method finished");
                #endif
            }
        }

        // POST api/Account/Logout
        [Route("Logout")]
        public IHttpActionResult Logout()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Logout' method started");
            #endif
            try
            {
                Authentication.SignOut(CookieAuthenticationDefaults.AuthenticationType);
                return Ok();
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Logout' method", ex);
                throw ex;
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Logout' method finished");
                #endif
            }
        }

        // GET api/Account/ManageInfo?returnUrl=%2F&generateState=true
        [Route("ManageInfo")]
        [Obsolete]
        public async Task<ManageInfoViewModel> GetManageInfo(string returnUrl, bool generateState = false)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetManageInfo' method started");
            #endif
            try {
                IdentityUser user = await UserManager.FindByIdAsync(User.Identity.GetUserId());

                if (user == null)
                {
                    return null;
                }

                List<UserLoginInfoViewModel> logins = new List<UserLoginInfoViewModel>();

                foreach (IdentityUserLogin linkedAccount in user.Logins)
                {
                    logins.Add(new UserLoginInfoViewModel
                    {
                        LoginProvider = linkedAccount.LoginProvider,
                        ProviderKey = linkedAccount.ProviderKey
                    });
                }

                if (user.PasswordHash != null)
                {
                    logins.Add(new UserLoginInfoViewModel
                    {
                        LoginProvider = LocalLoginProvider,
                        ProviderKey = user.UserName,
                    });
                }

                return new ManageInfoViewModel
                {
                    LocalLoginProvider = LocalLoginProvider,
                    UserName = user.UserName,
                    Logins = logins,
                    ExternalLoginProviders = GetExternalLogins(returnUrl, generateState)
                };
            }
            catch(Exception ex)
            {
                Logger.Instance.Error("Error in 'GetManageInfo' method", ex);
                throw ex;
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetManageInfo' method finished");
                #endif
            }
        }

        // POST api/Account/ChangePassword
        [Route("ChangePassword")]
        public async Task<IHttpActionResult> ChangePassword(ChangePasswordBindingModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'ChangePassword' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }

                Logger.Instance.Error("Validation error in 'ChangePassword' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                _usersService.EnsureCanChangePassword(UserRole);

                IdentityResult result = await UserManager.ChangePasswordAsync(User.Identity.GetUserId(), model.OldPassword, model.NewPassword);

                if (!result.Succeeded)
                    return Json(new { Status = "Error", Errors = result.Errors });

                return Json(new { Status = "Success" });
            }
            catch(Exception ex)
            {
                Logger.Instance.Error("Error in 'ChangePassword' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'ChangePassword' method finished");
                #endif
            }
        }

        // POST api/Account/SetPassword
        [Route("SetPassword")]
        [Obsolete]
        public async Task<IHttpActionResult> SetPassword(SetPasswordBindingModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'SetPassword' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'SetPassword' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                _usersService.EnsureCanChangePassword(UserRole);

                IdentityResult result = await UserManager.AddPasswordAsync(User.Identity.GetUserId(), model.NewPassword);

                if (!result.Succeeded)
                    return Json(new { Status = "Error", Errors = result.Errors });

                return Json(new { Status = "Success" });
            }
            catch(Exception ex)
            {
                Logger.Instance.Error("Error in 'SetPassword' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'SetPassword' method finished");
                #endif
            }
        }

        [AllowAnonymous]
        [Route("ResetPassword")]
        public async Task<IHttpActionResult> ResetPassword(PasswordResetViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'ResetPassword' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'ResetPassword' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var user = await UserManager.FindByEmailAsync(model.Email);

                if (user == null) throw new Exception("Please enter the email you have used to subscribe.");

                var userWithRole = _usersService.GetUserById(user.Id);

                if (userWithRole == null) throw new Exception("Please enter the email you have used to subscribe.");

                _usersService.EnsureCanChangePassword(userWithRole.Role);
                var password = PasswordGenerator.GeneratePassword();

                var token = await UserManager.GeneratePasswordResetTokenAsync(user.Id);
                var result = await UserManager.ResetPasswordAsync(user.Id, token, password);

                if (result.Succeeded)
                    await UserManager.SendEmailAsync(user.Id, "Shed - Password Reset", "Your new password is: " + password);
                else
                    return Json(new { Status = "Error", Errors = result.Errors });

                Logger.Instance.Info(string.Format("Password for user {0} was changed to {1}", model.Email, password));
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'ResetPassword' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'ResetPassword' method finished");
                #endif
            }
        }

        // POST api/Account/AddExternalLogin
        [Route("AddExternalLogin")]
        [Obsolete]
        public async Task<IHttpActionResult> AddExternalLogin(AddExternalLoginBindingModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'ResetPassword' method started");
            #endif
            if (!ModelState.IsValid)
            {
                Logger.Instance.Error("Validation error in 'AddExternalLogin' method");
                return BadRequest(ModelState);
            }

            try {
                Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);

                AuthenticationTicket ticket = AccessTokenFormat.Unprotect(model.ExternalAccessToken);

                if (ticket == null || ticket.Identity == null || (ticket.Properties != null
                    && ticket.Properties.ExpiresUtc.HasValue
                    && ticket.Properties.ExpiresUtc.Value < DateTimeOffset.UtcNow))
                {
                    return BadRequest("External login failure.");
                }

                ExternalLoginData externalData = ExternalLoginData.FromIdentity(ticket.Identity);

                if (externalData == null)
                {
                    return BadRequest("The external login is already associated with an account.");
                }

                IdentityResult result = await UserManager.AddLoginAsync(User.Identity.GetUserId(),
                    new UserLoginInfo(externalData.LoginProvider, externalData.ProviderKey));

                IHttpActionResult errorResult = GetErrorResult(result);

                if (errorResult != null)
                {
                    return errorResult;
                }

                return Ok();
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'AddExternalLogin' method", ex);
                throw ex;
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'AddExternalLogin' method finished");
                #endif
            }
        }

        // POST api/Account/RemoveLogin
        [Route("RemoveLogin")]
        [Obsolete]
        public async Task<IHttpActionResult> RemoveLogin(RemoveLoginBindingModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RemoveLogin' method started");
            #endif
            if (!ModelState.IsValid)
            {
                Logger.Instance.Error("Validation error in 'RemoveLogin' method");
                return BadRequest(ModelState);
            }

            try {
                IdentityResult result;

                if (model.LoginProvider == LocalLoginProvider)
                {
                    result = await UserManager.RemovePasswordAsync(User.Identity.GetUserId());
                }
                else
                {
                    result = await UserManager.RemoveLoginAsync(User.Identity.GetUserId(),
                        new UserLoginInfo(model.LoginProvider, model.ProviderKey));
                }

                IHttpActionResult errorResult = GetErrorResult(result);

                if (errorResult != null)
                {
                    return errorResult;
                }

                return Ok();
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveLogin' method", ex);
                throw ex;
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RemoveLogin' method finished");
                #endif
            }
        }

        //// GET api/Account/ExternalLogin
        //[OverrideAuthentication]
        //[HostAuthentication(DefaultAuthenticationTypes.ExternalCookie)]
        //[AllowAnonymous]
        //[Route("ExternalLogin", Name = "ExternalLogin")]
        //public async Task<IHttpActionResult> GetExternalLogin(string provider, string error = null)
        //{
        //    if (error != null)
        //    {
        //        return Redirect(Url.Content("~/") + "#error=" + Uri.EscapeDataString(error));
        //    }

        //    if (!User.Identity.IsAuthenticated)
        //    {
        //        return new ChallengeResult(provider, this);
        //    }

        //    ExternalLoginData externalLogin = ExternalLoginData.FromIdentity(User.Identity as ClaimsIdentity);

        //    if (externalLogin == null)
        //    {
        //        return InternalServerError();
        //    }

        //    if (externalLogin.LoginProvider != provider)
        //    {
        //        Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
        //        return new ChallengeResult(provider, this);
        //    }

        //    ApplicationUser user = await UserManager.FindAsync(new UserLoginInfo(externalLogin.LoginProvider,
        //        externalLogin.ProviderKey));

        //    bool hasRegistered = user != null;

        //    if (hasRegistered)
        //    {
        //        Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
        //        ClaimsIdentity oAuthIdentity = await UserManager.CreateIdentityAsync(user,
        //            OAuthDefaults.AuthenticationType);
        //        ClaimsIdentity cookieIdentity = await UserManager.CreateIdentityAsync(user,
        //            CookieAuthenticationDefaults.AuthenticationType);
        //        AuthenticationProperties properties = ApplicationOAuthProvider.CreateProperties(user.UserName);
        //        Authentication.SignIn(properties, oAuthIdentity, cookieIdentity);
        //    }
        //    else
        //    {
        //        IEnumerable<Claim> claims = externalLogin.GetClaims();
        //        ClaimsIdentity identity = new ClaimsIdentity(claims, OAuthDefaults.AuthenticationType);
        //        Authentication.SignIn(identity);
        //    }

        //    return Ok();
        //}

        // GET api/Account/ExternalLogins?returnUrl=%2F&generateState=true
        [AllowAnonymous]
        [Route("ExternalLogins")]
        [Obsolete]
        public IEnumerable<ExternalLoginViewModel> GetExternalLogins(string returnUrl, bool generateState = false)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetExternalLogins' method started");
            #endif
            try {
                IEnumerable<AuthenticationDescription> descriptions = Authentication.GetExternalAuthenticationTypes();
                List<ExternalLoginViewModel> logins = new List<ExternalLoginViewModel>();

                string state;

                if (generateState)
                {
                    const int strengthInBits = 256;
                    state = RandomOAuthStateGenerator.Generate(strengthInBits);
                }
                else
                {
                    state = null;
                }

                foreach (AuthenticationDescription description in descriptions)
                {
                    ExternalLoginViewModel login = new ExternalLoginViewModel
                    {
                        Name = description.Caption,
                        Url = Url.Route("ExternalLogin", new
                        {
                            provider = description.AuthenticationType,
                            response_type = "code",
                            client_id = Startup.PublicClientId,
                            redirect_uri = new Uri(Request.RequestUri, returnUrl).AbsoluteUri,
                            state = state
                        }),
                        State = state
                    };
                    logins.Add(login);
                }

                return logins;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetExternalLogins' method", ex);
                throw ex;
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetExternalLogins' method finished");
                #endif
            }
        }

        // POST api/Account/Register
        [AllowAnonymous]
        [Route("Register")]
        public async Task<IHttpActionResult> Register(RegisterBindingModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Register' method started");
            #endif
            if (!ModelState.IsValid)
            {
                //return BadRequest(ModelState);
                var invalidateList = new List<string>();
                foreach(var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'Register' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                ApplicationUser user = new ApplicationUser
                {
                    UserName = model.Email,
                    Email = model.Email,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    PhoneNumber = model.PhoneNumber
                };

                IdentityResult result = await UserManager.CreateAsync(user, model.Password);

                if (result.Succeeded)
                {
                    /*string code = ConfirmCode.GenerateConfirmCode();
                    await UserManager.SendEmailAsync(user.Id, "Confirm your account", "Please confirm your account by code: " + code);*/

                    await UserManager.AddToRoleAsync(user.Id, "RegularUser");
                }
                else
                {
                    if (result.Errors.Any(x => x.Contains("is already taken")))
                    {
                        return Json(new { Status = "Error", Errors = new string[] { "This email address is already being used. Please enter another email address." } });
                    }
                    else
                    {
                        return Json(new { Status = "Error", Errors = result.Errors });
                    }
                }

                user = await UserManager.FindAsync(model.Email, model.Password);

                if (user != null)
                {
                    Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
                    ClaimsIdentity oAuthIdentity = await UserManager.CreateIdentityAsync(user,
                        OAuthDefaults.AuthenticationType);
                    ClaimsIdentity cookieIdentity = await UserManager.CreateIdentityAsync(user,
                        CookieAuthenticationDefaults.AuthenticationType);
                    AuthenticationProperties properties = ApplicationOAuthProvider.CreateProperties(user.UserName);
                    Authentication.SignIn(properties, oAuthIdentity, cookieIdentity);
                }

                var identity = new ClaimsIdentity(Startup.OAuthBearerOptions.AuthenticationType);
                identity.AddClaim(new Claim(ClaimTypes.Name, model.Email));
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id));

                int roleMask = 0;
                foreach (var role in UserManager.GetRoles(user.Id))
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, role));

                    if (role != "Admin")
                    {
                        roleMask = BusinessLayer.Permissions.UserLevel.GetUserLevelMask(role);
                    }
                }

                AuthenticationTicket ticket = new AuthenticationTicket(identity, new AuthenticationProperties());
                var currentUtc = new SystemClock().UtcNow;
                ticket.Properties.IssuedUtc = currentUtc;
                ticket.Properties.ExpiresUtc = currentUtc.Add(TimeSpan.FromDays(30));
                string AccessToken = Startup.OAuthBearerOptions.AccessTokenFormat.Protect(ticket);

                return Json(new { Status = "Success", Token = AccessToken, UserLevelPermissions = roleMask });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Register' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetExternalLogins' method finished");
                #endif
            }
        }

        // POST api/Account/FacebookRegister
        [AllowAnonymous]
        [Route("FacebookRegister")]
        public async Task<IHttpActionResult> FacebookRegister(FacebookRegisterBindingModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'FacebookRegister' method started");
            #endif
            if (!ModelState.IsValid)
            {
                //return BadRequest(ModelState);
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'Register' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }
            try
            {
                FacebookService facebookService = new FacebookService(facebookClient);
                var facebookAccount = await facebookService.GetFacebookAccountAsync(model.FacebookToken);
                var loginInfo = new UserLoginInfo("Facebook", facebookAccount.Id);
                var user = await UserManager.FindAsync(loginInfo);
                if (user != null)
                    return Json(new { Status = "Error", Errors = new string[] { ErrorsCode.FBIDERROR }, ErrorCode.FBIDERROR });

                user = await UserManager.FindAsync(model.Email, model.Password);
                IdentityResult result;
                if (user == null)
                {
                    user = new ApplicationUser
                    {
                        UserName = model.Email,
                        Email = model.Email,
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        PhoneNumber = model.PhoneNumber
                    };

                    result = await UserManager.CreateAsync(user, model.Password);
                }
                else
                {
                    return Json(new { Status = "Error", Errors = new string[] { ErrorsCode.USERERROR }, ErrorCode.USERERROR });
                }
                if (result.Succeeded)
                {
                    result = await UserManager.AddLoginAsync(user.Id, loginInfo);
                    await UserManager.AddToRoleAsync(user.Id, "RegularUser");
                }
                else
                {
                    if (result.Errors.Any(x => x.Contains("is already taken")))
                    {
                        return Json(new { Status = "Error", Errors = new string[] { ErrorsCode.EMAILERROR }, ErrorCode.EMAILERROR });
                    }
                    else
                    {
                        return Json(new { Status = "Error", Errors = result.Errors });
                    }
                }

                var userLogin = await UserManager.FindAsync(model.Email, model.Password);

                if (user != null)
                {
                    Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
                    ClaimsIdentity oAuthIdentity = await UserManager.CreateIdentityAsync(user,
                        OAuthDefaults.AuthenticationType);
                    ClaimsIdentity cookieIdentity = await UserManager.CreateIdentityAsync(user,
                        CookieAuthenticationDefaults.AuthenticationType);
                    AuthenticationProperties properties = ApplicationOAuthProvider.CreateProperties(user.UserName);
                    Authentication.SignIn(properties, oAuthIdentity, cookieIdentity);
                }

                var identity = new ClaimsIdentity(Startup.OAuthBearerOptions.AuthenticationType);
                identity.AddClaim(new Claim(ClaimTypes.Name, model.Email));
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id));

                int roleMask = 0;
                foreach (var role in UserManager.GetRoles(user.Id))
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, role));

                    if (role != "Admin")
                    {
                        roleMask = BusinessLayer.Permissions.UserLevel.GetUserLevelMask(role);
                    }
                }

                AuthenticationTicket ticket = new AuthenticationTicket(identity, new AuthenticationProperties());
                var currentUtc = new SystemClock().UtcNow;
                ticket.Properties.IssuedUtc = currentUtc;
                ticket.Properties.ExpiresUtc = currentUtc.Add(TimeSpan.FromDays(30));
                string AccessToken = Startup.OAuthBearerOptions.AccessTokenFormat.Protect(ticket);
                return Json(new { Status = "Success", Token = AccessToken, UserLevelPermissions = roleMask });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Register' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetExternalLogins' method finished");
                #endif
            }
        }

        // POST api/Account/FacebookLogin
        [AllowAnonymous]
        [Route("FacebookLogin")]
        public async Task<IHttpActionResult> FacebookLogin(FacebookRegisterBindingModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Login' method started");
            #endif
            if (string.IsNullOrEmpty(model.FacebookToken))
            {
                var invalidateList = new List<string>();
                invalidateList.Add("We cannot find an account with that email address or your password is wrong.");

                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'Facebook Token' field");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                FacebookService facebookService = new FacebookService(facebookClient);
                var facebookAccount = await facebookService.GetFacebookAccountAsync(model.FacebookToken);
                var loginInfo = new UserLoginInfo("Facebook", facebookAccount.Id);

                var user = await UserManager.FindAsync(loginInfo);
                if (user == null)
                {
                    return Json(new { Status = "Error", Errors = new string[] { "Your pass is incorrect. Please get in touch with Shed team or use 'Forgot Password' button" } });
                }

                if (user.IsLocked)
                {
                    return Json(new { Status = "Error", Errors = new string[] { "You are not allowed to enter the app" } });
                }

                Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
                ClaimsIdentity oAuthIdentity = await UserManager.CreateIdentityAsync(user,
                    OAuthDefaults.AuthenticationType);
                ClaimsIdentity cookieIdentity = await UserManager.CreateIdentityAsync(user,
                    CookieAuthenticationDefaults.AuthenticationType);
                AuthenticationProperties properties = ApplicationOAuthProvider.CreateProperties(user.UserName);
                Authentication.SignIn(properties, oAuthIdentity, cookieIdentity);
                
                var identity = new ClaimsIdentity(Startup.OAuthBearerOptions.AuthenticationType);
                identity.AddClaim(new Claim(ClaimTypes.Name, user.Email));
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id));

                int roleMask = 0;
                foreach (var role in UserManager.GetRoles(user.Id))
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, role));

                    if (role != "Admin")
                    {
                        roleMask = BusinessLayer.Permissions.UserLevel.GetUserLevelMask(role);
                    }
                }

                AuthenticationTicket ticket = new AuthenticationTicket(identity, new AuthenticationProperties());
                var currentUtc = new SystemClock().UtcNow;
                ticket.Properties.IssuedUtc = currentUtc;
                ticket.Properties.ExpiresUtc = currentUtc.Add(TimeSpan.FromDays(30));
                string AccessToken = Startup.OAuthBearerOptions.AccessTokenFormat.Protect(ticket);

                Logger.Instance.Info("Successful login for user " + user.Email + ". Token: " + AccessToken);
                return Json(new { Status = "Success", Token = AccessToken, UserLevelPermissions = roleMask });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Login' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Login' method finished");
                #endif
            }

        }

            // POST api/Account/ExternalRegister
        [AllowAnonymous]
        [Route("ExternalRegister")]
        [Obsolete]
        public async Task<IHttpActionResult> ExternalRegister(ExternalRegisterBindingModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'ExternalRegister' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'ExternalRegister' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                ApplicationUser user = new ApplicationUser { Email = model.Email };
                user.Logins.Add(new IdentityUserLogin
                    {
                        LoginProvider = "Facebook",
                        ProviderKey = model.ClientId
                    });

                IdentityResult result = await UserManager.CreateAsync(user);

                if (!result.Succeeded)
                    return Json(new { Status = "Error", Errors = result.Errors });

                if (user != null)
                {
                    Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
                    ClaimsIdentity oAuthIdentity = await UserManager.CreateIdentityAsync(user,
                        OAuthDefaults.AuthenticationType);
                    ClaimsIdentity cookieIdentity = await UserManager.CreateIdentityAsync(user,
                        CookieAuthenticationDefaults.AuthenticationType);
                    AuthenticationProperties properties = ApplicationOAuthProvider.CreateProperties(user.UserName);
                    Authentication.SignIn(properties, oAuthIdentity, cookieIdentity);
                }

                var identity = new ClaimsIdentity(Startup.OAuthBearerOptions.AuthenticationType);
                identity.AddClaim(new Claim(ClaimTypes.Name, model.Email));
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id));
                AuthenticationTicket ticket = new AuthenticationTicket(identity, new AuthenticationProperties());
                var currentUtc = new SystemClock().UtcNow;
                ticket.Properties.IssuedUtc = currentUtc;
                ticket.Properties.ExpiresUtc = currentUtc.Add(TimeSpan.FromDays(30));
                string AccessToken = Startup.OAuthBearerOptions.AccessTokenFormat.Protect(ticket);

                return Json(new { Status = "Success", Token = AccessToken });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'ExternalRegister' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'ExternalRegister' method finished");
                #endif
            }
        }

        // POST api/Account/RegisterExternal
        //[OverrideAuthentication]
        //[HostAuthentication(DefaultAuthenticationTypes.ExternalBearer)]
        //[Route("RegisterExternal")]
        //public async Task<IHttpActionResult> RegisterExternal(RegisterExternalBindingModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    ExternalLoginData externalLogin = ExternalLoginData.FromIdentity(User.Identity as ClaimsIdentity);

        //    if (externalLogin == null)
        //    {
        //        return InternalServerError();
        //    }

        //    ApplicationUser user = new ApplicationUser
        //    {
        //        UserName = model.UserName
        //    };
        //    user.Logins.Add(new IdentityUserLogin
        //    {
        //        LoginProvider = externalLogin.LoginProvider,
        //        ProviderKey = externalLogin.ProviderKey
        //    });
        //    IdentityResult result = await UserManager.CreateAsync(user);
        //    IHttpActionResult errorResult = GetErrorResult(result);

        //    if (errorResult != null)
        //    {
        //        return errorResult;
        //    }

        //    return Ok();
        //}

        [Route("VerifyCode")]
        [Obsolete]
        public async Task<IHttpActionResult> VerifyCode(string code)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'VerifyCode' method started");
            #endif
            try {
                if (!User.Identity.IsAuthenticated)
                    return BadRequest();

                return Ok();
            }
            catch(Exception ex)
            {
                Logger.Instance.Error("Error in 'VerifyCode' method", ex);
                throw ex;
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'VerifyCode' method finished");
                #endif
            }
        }

        // POST api/Account/Login
        [AllowAnonymous]
        [Route("Login")]
        public async Task<IHttpActionResult> Login(LoginViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'Login' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'Login' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                ApplicationUser user = await UserManager.FindByEmailAsync(model.Email);
                if (user == null)
                    return Json(new { Status = "Error", Errors = new string[] { "We cannot find an account with that email address or your password is wrong." } });

                user = await UserManager.FindAsync(model.Email, model.Password);

                if (user != null)
                {
                    if (user.IsLocked)
                    {
                        return Json(new { Status = "Error", Errors = new string[] { "You are not allowed to enter the app" } });
                    }

                    Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
                    ClaimsIdentity oAuthIdentity = await UserManager.CreateIdentityAsync(user,
                        OAuthDefaults.AuthenticationType);
                    ClaimsIdentity cookieIdentity = await UserManager.CreateIdentityAsync(user,
                        CookieAuthenticationDefaults.AuthenticationType);
                    AuthenticationProperties properties = ApplicationOAuthProvider.CreateProperties(user.UserName);
                    Authentication.SignIn(properties, oAuthIdentity, cookieIdentity);
                }
                else
                    return Json(new { Status = "Error", Errors = new string[] { "Your pass is incorrect. Please get in touch with Shed team or use 'Forgot Password' button" } });

                var identity = new ClaimsIdentity(Startup.OAuthBearerOptions.AuthenticationType);
                identity.AddClaim(new Claim(ClaimTypes.Name, model.Email));
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id));

                int roleMask = 0;
                foreach (var role in UserManager.GetRoles(user.Id))
                {
                    identity.AddClaim(new Claim(ClaimTypes.Role, role));

                    if (role != "Admin")
                    {
                        roleMask = BusinessLayer.Permissions.UserLevel.GetUserLevelMask(role);
                    }
                }

                AuthenticationTicket ticket = new AuthenticationTicket(identity, new AuthenticationProperties());
                var currentUtc = new SystemClock().UtcNow;
                ticket.Properties.IssuedUtc = currentUtc;
                ticket.Properties.ExpiresUtc = currentUtc.Add(TimeSpan.FromDays(30));
                string AccessToken = Startup.OAuthBearerOptions.AccessTokenFormat.Protect(ticket);

                Logger.Instance.Info("Successful login for user " + model.Email + ". Token: " + AccessToken);
                return Json(new { Status = "Success", Token = AccessToken, UserLevelPermissions = roleMask });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'Login' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'Login' method finished");
                #endif
            }
        }

        // GET api/Account/ExternalLogin
        [AllowAnonymous]
        [Route("LoginExternal")]
        [Obsolete]
        public async Task<IHttpActionResult> GetLoginExternal(/*ExternalLoginBindingModel model*/string ClientId, string Email, string Name)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetLoginExternal' method started");
            #endif
            var names = Name.Contains(' ') ? Name.Split(' ') : new string[2] { Name, string.Empty };
            var model = new ExternalLoginBindingModel
            {
                ClientId = ClientId,
                Email = Email,
                FirstName = names[0],
                LastName = names[1]
            };

            var invalidateList = new List<string>();
            if (string.IsNullOrEmpty(model.ClientId))
                invalidateList.Add("ClientId can't be null ot empty");
            if (string.IsNullOrEmpty(model.Email))
                invalidateList.Add("Email can't be null ot empty");
            if (!Regex.IsMatch(model.Email,
                @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$",
                RegexOptions.IgnoreCase))
                invalidateList.Add("Please use a valid e-mail address");
            
            if(invalidateList.Any())
                return Json(new { Status = "Invalid", Errors = invalidateList });

            /*if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }*/

            try
            {
                ApplicationUser user = await UserManager.FindByEmailAsync(model.Email);
                if(user == null)
                {
                    var result = await ExternalRegistrate(model);
                    if(!result.Succeeded)
                        return Json(new { Status = "Error", Errors = result.Errors });
                    #if DEBUG
                    else
                        Logger.Instance.Info(string.Format("Registrated user {0} was sign in with clientId: {1}.", model.Email, model.ClientId));
                    #endif
                    user = await UserManager.FindByEmailAsync(model.Email);
                }
                else
                {
                    if(!user.Logins.Any(l => l.ProviderKey == model.ClientId))
                    {
                        user.Logins.Add(new IdentityUserLogin
                            {
                                LoginProvider = "Facebook",
                                ProviderKey = model.ClientId,
                                UserId = user.Id
                            });
                    }
                }

                await SignIn(user);
                
                var identity = new ClaimsIdentity(Startup.OAuthBearerOptions.AuthenticationType);
                identity.AddClaim(new Claim(ClaimTypes.Name, model.Email));
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, user.Id));
                AuthenticationTicket ticket = new AuthenticationTicket(identity, new AuthenticationProperties());
                var currentUtc = new SystemClock().UtcNow;
                ticket.Properties.IssuedUtc = currentUtc;
                ticket.Properties.ExpiresUtc = currentUtc.Add(TimeSpan.FromDays(30));
                string AccessToken = Startup.OAuthBearerOptions.AccessTokenFormat.Protect(ticket);

                #if DEBUG
                Logger.Instance.Info(string.Format("User {0} was sign in with clientId: {1}. Token: {2}", user.UserName, model.ClientId, AccessToken));
                #endif

                return Json(new { Status = "Success", Token = AccessToken });
            }
            catch(Exception ex)
            {
                Logger.Instance.Error("Error in 'GetExternalLogin' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetExternalLogin' method finished");
                #endif
            }
        }

        private async Task SignIn(ApplicationUser user)
        {
            Authentication.SignOut(DefaultAuthenticationTypes.ExternalCookie);
            ClaimsIdentity oAuthIdentity = await UserManager.CreateIdentityAsync(user,
                OAuthDefaults.AuthenticationType);
            ClaimsIdentity cookieIdentity = await UserManager.CreateIdentityAsync(user,
                CookieAuthenticationDefaults.AuthenticationType);
            AuthenticationProperties properties = ApplicationOAuthProvider.CreateProperties(user.UserName);
            Authentication.SignIn(properties, oAuthIdentity, cookieIdentity);
        }

        private async Task<IdentityResult> ExternalRegistrate(ExternalLoginBindingModel model)
        {
            var userId = Guid.NewGuid();
            ApplicationUser user = new ApplicationUser { Email = model.Email, UserName = model.Email, Id = userId.ToString(), FirstName = model.FirstName, LastName = model.LastName };
            user.Logins.Add(new IdentityUserLogin
            {
                LoginProvider = "Facebook",
                ProviderKey = model.ClientId,
                UserId = userId.ToString()
            });

            return await UserManager.CreateAsync(user);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                UserManager.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Helpers

        private IAuthenticationManager Authentication
        {
            get { return Request.GetOwinContext().Authentication; }
        }

        private IHttpActionResult GetErrorResult(IdentityResult result)
        {
            if (result == null)
            {
                return InternalServerError();
            }

            if (!result.Succeeded)
            {
                if (result.Errors != null)
                {
                    foreach (string error in result.Errors)
                    {
                        ModelState.AddModelError("", error);
                    }
                }

                if (ModelState.IsValid)
                {
                    // No ModelState errors are available to send, so just return an empty BadRequest.
                    return BadRequest();
                }

                return BadRequest(ModelState);
            }

            return null;
        }

        private class ExternalLoginData
        {
            public string LoginProvider { get; set; }
            public string ProviderKey { get; set; }
            public string UserName { get; set; }

            public IList<Claim> GetClaims()
            {
                IList<Claim> claims = new List<Claim>();
                claims.Add(new Claim(ClaimTypes.NameIdentifier, ProviderKey, null, LoginProvider));

                if (UserName != null)
                {
                    claims.Add(new Claim(ClaimTypes.Name, UserName, null, LoginProvider));
                }

                return claims;
            }

            public static ExternalLoginData FromIdentity(ClaimsIdentity identity)
            {
                if (identity == null)
                {
                    return null;
                }

                Claim providerKeyClaim = identity.FindFirst(ClaimTypes.NameIdentifier);

                if (providerKeyClaim == null || String.IsNullOrEmpty(providerKeyClaim.Issuer)
                    || String.IsNullOrEmpty(providerKeyClaim.Value))
                {
                    return null;
                }

                if (providerKeyClaim.Issuer == ClaimsIdentity.DefaultIssuer)
                {
                    return null;
                }

                return new ExternalLoginData
                {
                    LoginProvider = providerKeyClaim.Issuer,
                    ProviderKey = providerKeyClaim.Value,
                    UserName = identity.FindFirstValue(ClaimTypes.Name)
                };
            }
        }

        private static class RandomOAuthStateGenerator
        {
            private static RandomNumberGenerator _random = new RNGCryptoServiceProvider();

            public static string Generate(int strengthInBits)
            {
                const int bitsPerByte = 8;

                if (strengthInBits % bitsPerByte != 0)
                {
                    throw new ArgumentException("strengthInBits must be evenly divisible by 8.", "strengthInBits");
                }

                int strengthInBytes = strengthInBits / bitsPerByte;

                byte[] data = new byte[strengthInBytes];
                _random.GetBytes(data);
                return HttpServerUtility.UrlTokenEncode(data);
            }
        }

        #endregion
    }
}