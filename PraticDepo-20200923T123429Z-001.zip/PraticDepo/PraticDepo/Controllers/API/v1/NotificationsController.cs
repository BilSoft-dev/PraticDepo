﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.AspNet.Identity;
using PraticDepo.BusinessLayer.Notifications;
using PraticDepo.Models;
using PraticDepo.BusinessLayer.Users;
using PraticDepo.Web.Common.Helpers;
using System.Web.Http.Description;
using PraticDepo.Attributes;

namespace PraticDepo.Web.Controllers.API.v1
{
    [ApiAuthorize]
    [RoutePrefix("api/Notifications")]
    public class NotificationsController : BaseApiController
    {
        NotificationsService notificationsService = new NotificationsService(); 

        // POST api/Notifications/AddNotification
        //[Route("AddNotification")]
        //public async Task<IHttpActionResult> AddNotification()
        //{

        //}

        // GET api/Notifications/NotificationsList
        [Route("NotificationsList")]
        [ResponseType(typeof(List<NotificationsService.Notification>))]
        public async Task<IHttpActionResult> GetNotificationsList()
        {
            #if DEBUG
            Logger.Instance.Info("Call 'GetNotificationsList' method started");
            #endif
            try
            {
                var userId = User.Identity.GetUserId();
                var result = notificationsService.GetUserNotifications(userId);

                return Json(new { Status = "Success", Notifications = result });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'GetNotificationsList' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'GetNotificationsList' method finished");
                #endif
            }
        }

        // POST api/Notifications/MarkAsRead
        [Route("MarkAsRead")]
        [Obsolete]
        public async Task<IHttpActionResult> MarkAsRead(MarkAsReadViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'MarkAsRead' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'MarkAsRead' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var userId = User.Identity.GetUserId();
                notificationsService.MaskAsRead(model.NotificationId, userId);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'MarkAsRead' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'MarkAsRead' method finished");
                #endif
            }
        }

        // POST api/Notifications/RemoveNotification
        [Route("RemoveNotification")]
        [Obsolete]
        public async Task<IHttpActionResult> RemoveNotification(MarkAsReadViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'RemoveNotification' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'RemoveNotification' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var userId = User.Identity.GetUserId();
                notificationsService.RemoveNotification(model.NotificationId, userId);
                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'RemoveNotification' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'RemoveNotification' method finished");
                #endif
            }
        }

        // POST api/Notifications/SendPushToken
        [Route("SendPushToken")]
        [Obsolete]
        public async Task<IHttpActionResult> SendPushToken(SendPushTokenViewModel model)
        {
            #if DEBUG
            Logger.Instance.Info("Call 'SendPushToken' method started");
            #endif
            if (!ModelState.IsValid)
            {
                var invalidateList = new List<string>();
                foreach (var item in ModelState.Values)
                {
                    foreach (var error in item.Errors)
                        invalidateList.Add(error.ErrorMessage);
                }
                Logger.Instance.Error("Validation error in 'SendPushToken' method");
                return Json(new { Status = "Invalid", Errors = invalidateList });
            }

            try
            {
                var userId = User.Identity.GetUserId();
                new UsersService().AddPushToken(userId, model.PushToken);

                return Json(new { Status = "Success" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error("Error in 'SendPushToken' method", ex);
                return Json(new { Status = "Error", Errors = new string[] { ex.Message } });
            }
            finally
            {
                #if DEBUG
                Logger.Instance.Info("Call 'SendPushToken' method finished");
                #endif
            }
        }
    }
}