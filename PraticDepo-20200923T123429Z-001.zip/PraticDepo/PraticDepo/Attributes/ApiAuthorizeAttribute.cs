﻿using PraticDepo.BusinessLayer.Users;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web.Http.Controllers;

namespace PraticDepo.Attributes
{
    public class ApiAuthorizeAttribute : System.Web.Http.AuthorizeAttribute
    {
        public override void OnAuthorization(HttpActionContext actionContext)
        {
            var identity = actionContext.RequestContext.Principal.Identity as ClaimsIdentity;

            if (identity != null && identity.Claims != null && identity.Claims.Any())
            {
                Claim providerKeyClaim = identity.FindFirst(ClaimTypes.NameIdentifier);

                if (providerKeyClaim != null
                  && !string.IsNullOrEmpty(providerKeyClaim.Issuer)
                  && !string.IsNullOrEmpty(providerKeyClaim.Value))
                {
                    var user = new UsersService().GetUserById(providerKeyClaim.Value);

                    if (user.IsLocked)
                    {
                        actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.OK,
                                                                                      new { Status = "Error", Errors = new string[] { "You are not allowed to enter the app" }, ErrorCode = 101 });
                        return;
                    }
                }
            }

            base.OnAuthorization(actionContext);
        }
    }
}