﻿using System;
using System.Collections.Generic;

namespace PraticDepo.Web.Models
{
    public class LoadViewModel
    {
        public List<Guid> CollectionIds { get; set; }
        public List<Guid> ItemIds { get; set; }
    }
}