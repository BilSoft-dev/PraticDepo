﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Models.Jobs
{
    public class JobStateViewModel
    {
        [Required]
        public Guid JobId { get; set; }

        public int ResponsibilityType { get; set; }
    }
}