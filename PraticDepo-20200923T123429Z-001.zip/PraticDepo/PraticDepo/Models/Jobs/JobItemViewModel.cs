﻿using System;
using PraticDepo.BusinessLayer.V2.Models.Jobs;

namespace PraticDepo.Models.Jobs
{
    public class JobItemViewModel
    {
        public JobItemViewModel(Job blJob, string dateFormat, IFormatProvider formatProvider)
        {
            JobId = blJob.JobId;
            Number = blJob.Number.ToString();
            JobStatus = (int)blJob.JobStatus;
            UserJobStatus = (int)blJob.UserJobStatus;

            DateCancelled = blJob.DateCancelled.HasValue ? blJob.DateCancelled.Value.ToString(dateFormat, formatProvider) : string.Empty;
            DateCreated = blJob.DateCreated.ToString(dateFormat, formatProvider);
            ClientId = blJob.ClientId;
            ClientFirstName = blJob.ClientFirstName;
            ClientLastName = blJob.ClientLastName;
            ClientEmail = blJob.ClientEmail;
            ClientAddress = blJob.ClientAddress;
            Notes = blJob.Notes;

            DateMovingEstimatedStart = blJob.DateMovingEstimatedStart.ToString(dateFormat, formatProvider);
            DateMovingEstimatedFinish = blJob.DateMovingEstimatedFinish.ToString(dateFormat, formatProvider);
            DateMovingActualStart = blJob.DateMovingActualStart.HasValue ? blJob.DateMovingActualStart.Value.ToString(dateFormat, formatProvider) : string.Empty;
            DateMovingActualFinish = blJob.DateMovingActualFinish.HasValue ? blJob.DateMovingActualFinish.Value.ToString(dateFormat, formatProvider) : string.Empty;

            DatePackingEstimatedStart = blJob.DatePackingEstimatedStart.ToString(dateFormat, formatProvider);
            DatePackingEstimatedFinish = blJob.DatePackingEstimatedFinish.ToString(dateFormat, formatProvider);
            DatePackingActualStart = blJob.DatePackingActualStart.HasValue ? blJob.DatePackingActualStart.Value.ToString(dateFormat, formatProvider) : string.Empty;
            DatePackingActualFinish = blJob.DatePackingActualFinish.HasValue ? blJob.DatePackingActualFinish.Value.ToString(dateFormat, formatProvider) : string.Empty;

            ResponsibilityType = (int)blJob.ResponsibilityType;
            CollectionsCount = blJob.CollectionsCount;
        }

        public Guid JobId { get; set; }
        public string Number { get; set; }
        public int JobStatus { get; set; }
        public int UserJobStatus { get; set; }
        public string DateCancelled { get; set; }
        public string DateCreated { get; set; }
        public string ClientId { get; set; }
        public string ClientFirstName { get; set; }
        public string ClientLastName { get; set; }
        public string ClientEmail { get; set; }
        public string ClientAddress { get; set; }
        public string Notes { get; set; }

        public string DateMovingEstimatedStart { get; set; }
        public string DateMovingEstimatedFinish { get; set; }
        public string DateMovingActualStart { get; set; }
        public string DateMovingActualFinish { get; set; }

        public string DatePackingEstimatedStart { get; set; }
        public string DatePackingEstimatedFinish { get; set; }
        public string DatePackingActualStart { get; set; }
        public string DatePackingActualFinish { get; set; }

        public int ResponsibilityType { get; set; }
        public int CollectionsCount { get; set; }
    }
}