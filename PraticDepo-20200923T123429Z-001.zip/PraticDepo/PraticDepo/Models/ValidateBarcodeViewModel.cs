﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Web.Models
{
    public class ValidateBarcodeViewModel
    {
        [Required]
        public string Barcode { get; set; }
    }
}