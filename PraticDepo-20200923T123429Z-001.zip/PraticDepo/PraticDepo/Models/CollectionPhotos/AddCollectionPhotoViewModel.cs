﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Models.CollectionPhotos
{
    public class AddCollectionPhotoViewModel
    {
        [Required]
        public Guid CollectionId { get; set; }

        public CollectionPhotoUpload Upload { get; set; }
    }
}