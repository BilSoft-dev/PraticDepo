﻿namespace PraticDepo.Models.CollectionPhotos
{
    public class GetCollectionPhotoViewModel
    {
        public string ImagePath { get; set; }
        public string PreviewImagePath { get; set; }
    }
}