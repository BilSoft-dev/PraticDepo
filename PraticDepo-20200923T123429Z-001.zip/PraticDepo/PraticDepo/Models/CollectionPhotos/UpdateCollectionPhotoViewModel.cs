﻿using PraticDepo.Web.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Models.CollectionPhotos
{
    public class UpdateCollectionPhotoViewModel
    {
        [Required]
        public Guid CollectionId { get; set; }

        public CollectionPhotoUpload Upload { get; set; }
    }
}