﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Models.CollectionPhotos
{
    public class DeleteCollectionPhotoViewModel
    {
        [Required]
        public Guid CollectionId { get; set; }
    }
}