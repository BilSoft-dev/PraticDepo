﻿using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Models.CollectionPhotos
{
    public class CollectionPhotoUpload
    {
        [Required(ErrorMessage = "FileName required")]
        public string FileName { get; set; }
        [Required(ErrorMessage = "FileContent required")]
        public string FileContent { get; set; }
    }
}