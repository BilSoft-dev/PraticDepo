﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraticDepo.Models
{
    public class MarkAsReadViewModel
    {
        [Required]
        public Guid NotificationId { get; set; }
    }
        
    public class SendPushTokenViewModel
    {
        [Required]
        public string PushToken { get; set; }
    }
}
