﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraticDepo.Web.Models
{
    public class MediaElementViewModel
    {

    }

    public class AddChaptersViewModel
    {
        public IEnumerable<AddVideoChapterViewModel> Items { get; set; }
    }

    public class AddVideoChapterViewModel
    {
        public Guid ChapterId { get; set; }
        [Required(ErrorMessage = "VideoId required")]
        public Guid VideoId { get; set; }
        //[Required]
        //public Guid CoverId { get; set; }
        public UploadFile Cover { get; set; }
        [Required(ErrorMessage = "Name required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Time required")]
        public double Time { get; set; }
        public string Barcode { get; set; }
        [Range(0, 999999.999)]
        public decimal? Volume { get; set; }
    }

    public class VideoChapterViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public double Time { get; set; }
        public string Cover { get; set; }
        public string CoverPreview { get; set; }
        public string Barcode { get; set; }
        public decimal? Volume { get; set; }
    }

    public class DeleteMediaViewModel
    {
        [Required]
        public Guid MediaId { get; set; }
    }

    public class RenameChapterViewModel
    {
        [Required]
        public Guid ChapterId { get; set; }
        [Required]
        public string Name { get; set; }
    }

    public class ChangeChapterTimeViewModel
    {
        [Required]
        public Guid ChapterId { get; set; }
        [Required]
        public double Time { get; set; }
    }

    public class EditChapterViewModel
    {
        [Required]
        public Guid ChapterId { get; set; }

        [Required]
        public string Name { get; set; }
        [Required]
        public double Time { get; set; }
        public string Barcode { get; set; }
        [Range(0, 999999.999)]
        public decimal? Volume { get; set; }
    }
        
    public class RemoveChapterViewModel
    {
        [Required]
        public Guid ChapterId { get; set; }
    }
}
