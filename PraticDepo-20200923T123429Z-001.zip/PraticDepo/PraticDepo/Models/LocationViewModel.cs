﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraticDepo.Web.Models
{
    public class NewHomeViewModel
    {
        [Required]
        public string City { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public double Latitude { get; set; }
        [Required]
        public double Longitude { get; set; }
    }

    public class NewRoomViewModel
    {
        [Required]
        public Guid HomeId { get; set; }
        [Required]
        public string Name { get; set; }
    }

    public class NewRoomPartViewModel
    {
        [Required]
        public Guid RoomId { get; set; }
        [Required]
        public string Name { get; set; }
    }

    public class _HomeViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public bool IsUserHere { get; set; }
        public string City { get; set; }
        public DateTime CreateAt { get; set; }
        public bool ReadOnly { get; set; }
        public int Permissions { get; set; }

        public List<_RoomViewModel> Rooms { get; set; }
        public List<CollectionViewModel> Collections { get; set; }
    }

    public class _RoomViewModel
    {
        public Guid Id { get; set; }
        public Guid HomeId { get; set; }
        public string Name { get; set; }
        public DateTime CreateAt { get; set; }

        public List<RoomPartViewModel> RoomParts { get; set; }
        public List<CollectionViewModel> Collections { get; set; }
    }

    public class RoomPartViewModel
    {
        public Guid Id { get; set; }
        public Guid RoomId { get; set; }
        public string Name { get; set; }
        public DateTime CreateAt { get; set; }
        public List<CollectionViewModel> Collections { get; set; }
    }

    public class CollectionInfoViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }

    public class DeleteHomeViewModel
    {
        [Required]
        public Guid HomeId { get; set; }
    }

    public class DeleteRoomViewModel
    {
        [Required]
        public Guid RoomId { get; set; }
    }

    public class DeleteRoomPartViewModel
    {
        [Required]
        public Guid RoomPartId { get; set; }
    }

    public class RenameHomeViewModel
    {
        [Required]
        public Guid HomeId { get; set; }
        [Required]
        public string NewName { get; set; }
    }

    public class RenameRoomViewModel
    {
        [Required]
        public Guid RoomId { get; set; }
        [Required]
        public string NewName { get; set; }
    }

    public class RenameRoomPartViewModel
    {
        [Required]
        public Guid RoomPartId { get; set; }
        [Required]
        public string NewName { get; set; }
    }

    public class ChangeHomeLocationViewModel
    {
        [Required]
        public Guid HomeId { get; set; }
        [Required]
        public double Latitude { get; set; }
        [Required]
        public double Longitude { get; set; }
        public string City { get; set; }
    }
}
