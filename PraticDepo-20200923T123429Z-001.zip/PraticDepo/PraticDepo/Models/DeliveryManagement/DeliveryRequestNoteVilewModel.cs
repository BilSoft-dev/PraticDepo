﻿using System;

namespace PraticDepo.Models.DeliveryManagement
{
    public class DeliveryRequestNoteVilewModel
    {
        public Guid NoteId { get; set; }
        public string NoteValue { get; set; }
    }
}