﻿using System;

namespace PraticDepo.Models.DeliveryManagement
{
    public class DeliveryRequestViewModel
    {
        public Guid RequestId { get; set; }
        public string RequestNumber { get; set; }
        public string DateCreated { get; set; }
        public string DateDelivered { get; set; }
        public int Status { get; set; }
        public int ItemCounter { get; set; }
    }
}