﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Models.DeliveryManagement
{
    public class EditRequestNoteViewModel
    {
        [Required]
        public Guid NoteId { get; set; }

        public string Note { get; set; }
    }
}