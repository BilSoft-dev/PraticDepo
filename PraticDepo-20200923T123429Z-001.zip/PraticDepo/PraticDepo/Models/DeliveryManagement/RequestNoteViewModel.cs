﻿using System;

namespace PraticDepo.Models.DeliveryManagement
{
    public class RequestNoteViewModel
    {
        public Guid NoteId { get; set; }
    }
}