﻿using System;
using System.Collections.Generic;

namespace PraticDepo.Models.DeliveryManagement
{
    public class DeliveryRequestCollectionViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Status { get; set; }
        public string Barcode { get; set; }
        public int ItemCounter { get; set; }

        public CollectionPhotos.GetCollectionPhotoViewModel Photo { get; set; }

        public List<DeliveryRequestItemViewModel> Items { get; set; }
    }
}