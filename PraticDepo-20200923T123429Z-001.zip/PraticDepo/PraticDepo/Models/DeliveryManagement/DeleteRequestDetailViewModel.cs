﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Models.DeliveryManagement
{
    public class DeleteRequestDetailViewModel
    {
        [Required]
        public Guid CollectionId { get; set; }

        public Guid? ItemId { get; set; }

        public Guid? ChapterId { get; set; }
    }
}