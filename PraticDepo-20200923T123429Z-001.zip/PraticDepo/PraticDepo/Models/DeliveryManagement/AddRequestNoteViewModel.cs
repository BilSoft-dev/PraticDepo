﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Models.DeliveryManagement
{
    public class AddRequestNoteViewModel
    {
        [Required]
        public Guid RequestId { get; set; }

        public string Note { get; set; }
    }
}