﻿using System;

namespace PraticDepo.Models.DeliveryManagement
{
    public class RequestViewModel
    {
        public Guid RequestId { get; set; }
        public string RequestNumber { get; set; }
        public Guid CollectionId { get; set; }
        public Guid? ItemId { get; set; }
        public Guid? ChapterId { get; set; }
    }
}