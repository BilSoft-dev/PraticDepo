﻿using System;

namespace PraticDepo.Models.DeliveryManagement
{
    public class DeliveryRequestItemViewModel
    {
        public Guid Id { get; set; }
        public Guid? ChapterId { get; set; }
        public string Name { get; set; }
        public int Status { get; set; }
        public string Barcode { get; set; }
        public string PreviewUrl { get; set; }
    }
}