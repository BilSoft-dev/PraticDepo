﻿using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Web.Models
{
    public class PutCollaboratorViewModel
    {
        [EmailAddress(ErrorMessage = "Wrong email")]
        public string Email { get; set; }
        public string Name { get; set; }
    }
}