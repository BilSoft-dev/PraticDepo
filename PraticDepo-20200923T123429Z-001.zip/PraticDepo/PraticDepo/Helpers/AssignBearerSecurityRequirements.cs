﻿using Swashbuckle.Swagger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;

namespace PraticDepo.Helpers
{
    public class AssignBearerSecurityRequirements : IOperationFilter
    {
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            // Determine if the operation has the Authorize attribute
            var authorizeAttributes = apiDescription.ActionDescriptor.GetCustomAttributes<AuthorizeAttribute>()
                .Union(apiDescription.ActionDescriptor.ControllerDescriptor.GetCustomAttributes<AuthorizeAttribute>());

            var anonimousAttributes = apiDescription.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>()
                .Union(apiDescription.ActionDescriptor.ControllerDescriptor.GetCustomAttributes<AllowAnonymousAttribute>());

            if (!authorizeAttributes.Any() || anonimousAttributes.Any())
                return;

            // Initialize the operation.security property
            if (operation.parameters == null)
                operation.parameters = new List<Parameter>();
            
            operation.parameters.Add(new Parameter {
                @in = "header",
                @default = "Bearer ",
                required = true,
                name = "Authorization",
                type = "string",
                description = "Authorization token obtained via api/Account/FacebookLogin or api/Account/FacebookRegister or api/Account/Register or api/Account/Login. Must be \"Bearer TOKEN\"",
            });
        }
    }
}