﻿using Microsoft.AspNet.Identity.EntityFramework;
using PraticDepo.DAL.Models;
using System.Data.Entity;
using System.Data.Entity.SqlServer;

namespace PraticDepo.DAL
{
    public class AuthContext : IdentityDbContext<IdentityUser>
    {
        public DbSet<ApplicationUser> Users { get; set; }
        public DbSet<ApplicationRole> Roles { get; set; }
        public DbSet<Location> Locations { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Media> Medias { get; set; }
        public DbSet<Collaborator> Collaborators { get; set; }
        public DbSet<VideoChapter> VideoChapters { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<CollectionPhoto> CollectionPhotos { get; set; }
        public DbSet<Collection> Collections { get; set; }
        //public DbSet<UserToken> UserTokens { get; set; }
        
        // Delivery Management functionality
        public DbSet<DeliveryRequest> DeliveryRequests { get; set; }
        public DbSet<DeliveryRequestCollection> DeliveryRequestCollections { get; set; }
        public DbSet<DeliveryRequestCollectionItem> DeliveryRequestCollectionItems { get; set; }
        public DbSet<DeliveryRequestNote> DeliveryRequestNotes { get; set; }

        public DbSet<Job> Jobs { get; set; }
        public DbSet<UserJob> UserJobs { get; set; }
        public DbSet<JobCollection> JobCollections { get; set; }

        public AuthContext(string connectionString)
            : base(connectionString)
        {

        }

        public AuthContext()
            :base("DefaultConnection")
        {
            
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Collection>().Property(x => x.Volume).HasPrecision(9, 3);
            modelBuilder.Entity<Item>().Property(x => x.Volume).HasPrecision(9, 3);
            modelBuilder.Entity<VideoChapter>().Property(x => x.Volume).HasPrecision(9, 3);

            modelBuilder.Entity<ApplicationUser>()
                .HasMany(x => x.CreatedCollaborators)
                .WithMany(x => x.CreatedBy)
                .Map(m =>
                {
                    m.ToTable("CollaboratorsUsers");
                    m.MapRightKey("Id");
                    m.MapLeftKey("CreatedBy");
                });
            modelBuilder.Entity<VideoChapter>().HasRequired(x => x.Video).WithMany(x => x.VideoChapters);
        }

        public static AuthContext Create()
        {
            return new AuthContext();
        }
    }
}
