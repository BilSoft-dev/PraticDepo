﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class Collection : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime CreateAt { get; set; }

        [Required]
        [ForeignKey("User")]
        public string UserId { get; set; }

        [Required]
        [ForeignKey("Home")]
        public Guid HomeId { get; set; }

        [ForeignKey("Room")]
        public Guid? RoomId { get; set; }

        [ForeignKey("RoomPart")]
        public Guid? RoomPartId { get; set; }

        public string Note { get; set; }

        [MaxLength(512)]
        public string Barcode { get; set; }

        [Range(0, 999999.999)]
        public decimal? Volume { get; set; }

        public int? Status { get; set; }

        public virtual ICollection<Item> Items { get; set; }
        public virtual ICollection<Collaborator> Collaborators { get; set; }
        public virtual ApplicationUser User { get; set; }
        public virtual Location Home { get; set; }
        public virtual Location Room { get; set; }
        public virtual Location RoomPart { get; set; }

        [MaxLength(5, ErrorMessage = "Storage location must be 5 characters long")]
        public string StorageLocation { get; set; }

        [MaxLength(4, ErrorMessage = "Bin number must be 4 characters long")]
        public string BinNumber { get; set; }

        public bool? IsLoaded { get; set; }

        public virtual ICollection<CollectionPhoto> Photos { get; set; }
    }
}
