﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class Location : IEntity
    {
        public enum LocationType
        {
            HOME,
            ROOM,
            ROOMPART
        }

        [Key]
        public Guid Id { get; set; }
        [ForeignKey("Parent")]
        public Guid? ParentId { get; set; }
        [Required]
        public string OwnerId { get; set; }
        [Required]
        public string Name { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string City { get; set; }
        [Required]
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        public DateTime CreateAt { get; set; }

        public virtual Location Parent { get; set; }

        [NotMapped]
        public LocationType Type
        {
            get
            {
                if (ParentId.HasValue)
                {
                    if (Parent != null && Parent.ParentId.HasValue)
                        return LocationType.ROOMPART;
                    else
                        return LocationType.ROOM;
                }
                else
                    return LocationType.HOME;
            }
        }

        /*[NotMapped]
        public string Address
        {
            get
            {
                var city = string.Empty;
                var home = string.Empty;
                var room = string.Empty;
                var roomPart = string.Empty;

                switch(Type)
                {
                    case LocationType.HOME:
                        city = City;
                        home = Name;
                        return string.Format("{0} > {1}", city, home).Trim();                        
                    case LocationType.ROOM:
                        room = Name;
                        home = Parent != null ? Parent.Name : string.Empty;
                        city = Parent != null ? Parent.City : string.Empty;
                        return string.Format("{0} > {1} > {2}", city, home, room).Trim();
                    case LocationType.ROOMPART:
                        roomPart = Name;
                        room = Parent != null ? Parent.Name : string.Empty;
                        home = Parent != null && Parent.Parent != null ? Parent.Parent.Name : string.Empty;
                        city = Parent != null && Parent.Parent != null ? Parent.Parent.City : string.Empty;
                        return string.Format("{0} > {1} > {2} > {3}", city, home, room, roomPart).Trim();
                }

                return string.Format("{0} > {1} > {2} > {3}", city, home, room, roomPart).Trim();
            }
        }*/
    }
}
