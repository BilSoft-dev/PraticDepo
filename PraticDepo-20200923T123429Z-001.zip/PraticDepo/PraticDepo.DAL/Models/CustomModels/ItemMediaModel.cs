﻿using System.Collections.Generic;

namespace PraticDepo.DAL.Models.CustomModels
{
    public class ItemMedia
    {
        public VideoChapter VideoChapter { get; set; }
        public Item Item { get; set; }
        public Collection Collection { get; set; }
        public IEnumerable<ApplicationUser> ItemOwners { get; set; }
        public ApplicationUser ItemCreator { get; set; }
    }
}
