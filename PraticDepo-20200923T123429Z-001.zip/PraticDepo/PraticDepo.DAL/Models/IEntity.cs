﻿using System;

namespace PraticDepo.DAL.Models
{
    public interface IEntity
    {
        Guid Id { get; set; }
    }
}
