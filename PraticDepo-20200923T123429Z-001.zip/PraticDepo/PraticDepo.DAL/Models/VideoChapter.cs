﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class VideoChapter : IEntity
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [Required]
        //[DataType(System.ComponentModel.DataAnnotations.DataType.Time)]
        public double Time { get; set; }
        [Required]
        [ForeignKey("Video")]
        public Guid VideoId { get; set; }
        [Required]
        [ForeignKey("Cover")]
        public Guid CoverId { get; set; }
        
        [MaxLength(512)]
        public string Barcode { get; set; }

        [Range(0, 999999.999)]
        public decimal? Volume { get; set; }

        public int? Status { get; set; }

        public bool? IsLoaded { get; set; }

        public virtual Media Cover { get; set; }

        public virtual Media Video { get; set; }
    }
}