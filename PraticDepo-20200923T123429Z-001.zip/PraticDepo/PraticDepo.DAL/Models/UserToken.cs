﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class UserToken : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [ForeignKey("User")]
        public string UserId { get; set; }

        [Required]
        public string RefreshToken { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime ExpiresAt { get; set; }

        public virtual ApplicationUser User { get; set; }
    }
}