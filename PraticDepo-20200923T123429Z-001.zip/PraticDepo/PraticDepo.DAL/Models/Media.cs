﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraticDepo.DAL.Models
{
    public class Media : IEntity
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        public string FileName { get; set; }
        [Required]
        public int Type { get; set; }
        public double Duration { get; set; }
        public Guid? ItemId { get; set; }
        [Required]
        [DataType(System.ComponentModel.DataAnnotations.DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        public virtual ICollection<VideoChapter> VideoChapters { get; set; }
    }

    public enum MediaType
    {
        PHOTO = 0,
        VIDEO
    }
}
