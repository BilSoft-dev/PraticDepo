﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class DeliveryRequestCollection : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [ForeignKey("DeliveryRequest")]
        public Guid DeliveryRequestId { get; set; }

        [Required]
        [ForeignKey("Collection")]
        public Guid CollectionId { get; set; }

        [Required]
        public int Status { get; set; }

        public virtual DeliveryRequest DeliveryRequest { get; set; }
        public virtual Collection Collection { get; set; }
        public virtual ICollection<DeliveryRequestCollectionItem> DeliveryRequestCollectionItems { get; set; }
    }
}