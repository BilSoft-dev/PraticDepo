﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class DeliveryRequestNote : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [ForeignKey("DeliveryRequest")]
        public Guid DeliveryRequestId { get; set; }

        public string Note { get; set; }

        public DateTime DateModified { get; set; }

        public virtual DeliveryRequest DeliveryRequest { get; set; }
    }
}