﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.DAL.Models
{
    public class DeliveryRequest : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        public string RequestNumber { get; set; }

        [Required]
        public string UserId { get; set; }

        public string UserFirstName { get; set; }

        public string UserLastName { get; set; }

        public string UserEmail { get; set; }

        public string UserPhoneNumber { get; set; }

        [Required]
        public int Status { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime DateCreated { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? DateDelivered { get; set; }

        public string AdminNote { get; set; }

        public virtual ICollection<DeliveryRequestCollection> DeliveryRequestCollections { get; set; }
        public virtual ICollection<DeliveryRequestNote> DeliveryRequestNotes { get; set; }
    }
}