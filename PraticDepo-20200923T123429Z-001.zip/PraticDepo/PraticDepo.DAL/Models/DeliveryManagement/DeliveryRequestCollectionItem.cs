﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class DeliveryRequestCollectionItem : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [ForeignKey("DeliveryRequestCollection")]
        public Guid DeliveryRequestCollectionId { get; set; }

        [Required]
        [ForeignKey("Item")]
        public Guid ItemId { get; set; }

        public Guid? ChapterId { get; set; }

        public virtual DeliveryRequestCollection DeliveryRequestCollection { get; set; }
        public virtual Item Item { get; set; }
    }
}