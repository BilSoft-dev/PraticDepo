﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class JobCollection : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [ForeignKey("Job")]
        public Guid JobId { get; set; }

        [Required]
        public string CollectionId { get; set; }

        public virtual Job Job { get; set; }
    }
}
