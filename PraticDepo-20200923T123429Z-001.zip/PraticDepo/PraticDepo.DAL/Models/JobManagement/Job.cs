﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.DAL.Models
{
    public class Job : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public int Number { get; set; }

        [Required]
        public int Status { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime DateCreated { get; set; }

        public string ClientId { get; set; }
        public string ClientFirstName { get; set; }
        public string ClientLastName { get; set; }
        public string ClientEmail { get; set; }
        public string ClientAddress { get; set; }

        public string Notes { get; set; }

        public virtual ICollection<UserJob> UserJobs { get; set; }
        public virtual ICollection<JobCollection> Collections { get; set; }
    }
}