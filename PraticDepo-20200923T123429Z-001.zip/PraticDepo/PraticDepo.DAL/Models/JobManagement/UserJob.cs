﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class UserJob : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        public string UserId { get; set; }

        [Required]
        public int Status { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime? DateCancelled { get; set; }

        public int ResponsibilityType { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime DatePackingEstimatedStart { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime? DatePackingActualStart { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime DatePackingEstimatedFinish { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime? DatePackingActualFinish { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime DateMovingEstimatedStart { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime? DateMovingActualStart { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime DateMovingEstimatedFinish { get; set; }
        [DataType(DataType.DateTime)]
        public DateTime? DateMovingActualFinish { get; set; }

        public bool IsRestart { get; set; }

        [Required]
        [ForeignKey("Job")]
        public Guid JobId { get; set; }

        public virtual Job Job { get; set; }
    }
}
