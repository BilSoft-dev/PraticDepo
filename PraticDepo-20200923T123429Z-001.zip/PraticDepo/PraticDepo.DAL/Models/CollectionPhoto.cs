﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class CollectionPhoto : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        [ForeignKey("Collection")]
        public Guid CollectionId { get; set; }

        [Required]
        public string FileName { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        public virtual Collection Collection { get; set; }
    }
}