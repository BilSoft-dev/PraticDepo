﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PraticDepo.DAL.Models
{
    public class Item : IEntity
    {
        [Key]
        public Guid Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime CreateDate { get; set; }

        [Required]
        [ForeignKey("Collection")]
        public Guid CollectionId { get; set; }

        [Required]
        public string UserId { get; set; }

        [MaxLength(512)]
        public string Barcode { get; set; }

        [Range(0, 999999.999)]
        public decimal? Volume { get; set; }

        public int? Status { get; set; }

        public bool? IsLoaded { get; set; }

        public virtual ICollection<Media> Media { get; set; }
        public virtual Collection Collection { get; set; }
    }
}
