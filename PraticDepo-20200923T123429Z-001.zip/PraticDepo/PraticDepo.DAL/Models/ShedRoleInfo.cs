﻿using System;

namespace PraticDepo.DAL.Models
{
    public class ShedRoleInfo
    {
        public int Id { get; internal set; }
        public string DbId { get; internal set; }
        public string Description { get; internal set; }
    }
}