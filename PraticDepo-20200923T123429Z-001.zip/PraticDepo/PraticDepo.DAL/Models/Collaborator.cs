﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraticDepo.DAL.Models
{
    public class Collaborator : IEntity
    {
        public Guid Id { get; set; }
        [ForeignKey("User")]
        public string UserId { get; set; }
        
        [StringLength(30)]
        public string Name { get; set; }
        [EmailAddress]
        public string Email { get; set; }

        public virtual ApplicationUser User { get; set; }
        public virtual ICollection<Collection> Collections { get; set; }

        public virtual ICollection<ApplicationUser> CreatedBy { get; set; }

    }
}
