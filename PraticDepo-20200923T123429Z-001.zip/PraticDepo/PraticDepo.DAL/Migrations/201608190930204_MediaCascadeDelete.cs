namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class MediaCascadeDelete : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Media", "ItemId", "dbo.Items");
            AddForeignKey("dbo.Media", "ItemId", "dbo.Items", "Id", cascadeDelete:true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Media", "ItemId", "dbo.Items");
            AddForeignKey("dbo.Media", "ItemId", "dbo.Items", "Id");
        }
    }
}
