namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddDurationIntoMedia : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Media", "Duration", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Media", "Duration");
        }
    }
}
