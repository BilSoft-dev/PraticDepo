namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddIsLoadedField : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Collections", "IsLoaded", c => c.Boolean());
            AddColumn("dbo.Items", "IsLoaded", c => c.Boolean());
            AddColumn("dbo.VideoChapters", "IsLoaded", c => c.Boolean());
        }
        
        public override void Down()
        {
            DropColumn("dbo.VideoChapters", "IsLoaded");
            DropColumn("dbo.Items", "IsLoaded");
            DropColumn("dbo.Collections", "IsLoaded");
        }
    }
}
