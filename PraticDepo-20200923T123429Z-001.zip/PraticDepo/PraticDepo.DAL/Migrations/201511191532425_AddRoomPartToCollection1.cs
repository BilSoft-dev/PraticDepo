namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddRoomPartToCollection1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Collections", "RoomPartId", "dbo.RoomParts");
            DropIndex("dbo.Collections", new[] { "RoomPartId" });
            AlterColumn("dbo.Collections", "RoomPartId", c => c.Guid());
            CreateIndex("dbo.Collections", "RoomPartId");
            AddForeignKey("dbo.Collections", "RoomPartId", "dbo.RoomParts", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Collections", "RoomPartId", "dbo.RoomParts");
            DropIndex("dbo.Collections", new[] { "RoomPartId" });
            AlterColumn("dbo.Collections", "RoomPartId", c => c.Guid(nullable: false));
            CreateIndex("dbo.Collections", "RoomPartId");
            AddForeignKey("dbo.Collections", "RoomPartId", "dbo.RoomParts", "Id", cascadeDelete: true);
        }
    }
}
