namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SetCollectionIdNullableOfNotificationTable : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Notifications", "CollectionId", c => c.Guid());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Notifications", "CollectionId", c => c.Guid(nullable: false));
        }
    }
}
