namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NoteMovedToCollection : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Collections", "Note_Id", "dbo.Notes");
            DropIndex("dbo.Collections", new[] { "Note_Id" });
            AddColumn("dbo.Collections", "Note", c => c.String());
            DropColumn("dbo.Collections", "Note_Id");
            DropTable("dbo.Notes");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.Notes",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        CollectionId = c.Guid(nullable: false),
                        Text = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.Collections", "Note_Id", c => c.Guid());
            DropColumn("dbo.Collections", "Note");
            CreateIndex("dbo.Collections", "Note_Id");
            AddForeignKey("dbo.Collections", "Note_Id", "dbo.Notes", "Id");
        }
    }
}
