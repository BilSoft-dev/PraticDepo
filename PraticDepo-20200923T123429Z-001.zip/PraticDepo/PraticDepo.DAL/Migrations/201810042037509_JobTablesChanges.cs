namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class JobTablesChanges : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.UserJobs",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        UserId = c.String(),
                        Status = c.Int(nullable: false),
                        DateStartPlan = c.DateTime(nullable: false),
                        DateStarted = c.DateTime(),
                        DateFinishPlan = c.DateTime(nullable: false),
                        DateFinished = c.DateTime(),
                        DateCancelled = c.DateTime(),
                        ResponsibilityType = c.Int(nullable: false),
                        DateEstimatedStart = c.DateTime(nullable: false),
                        DateActualStart = c.DateTime(),
                        DateEstimatedFinish = c.DateTime(nullable: false),
                        DateActualFinish = c.DateTime(),
                        JobId = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Jobs", t => t.JobId, cascadeDelete: true)
                .Index(t => t.JobId);
            
            AddColumn("dbo.Jobs", "ClientAddress", c => c.String());
            AddColumn("dbo.Jobs", "Notes", c => c.String());
            DropColumn("dbo.Jobs", "Status");
            DropColumn("dbo.Jobs", "DateStartPlan");
            DropColumn("dbo.Jobs", "DateStarted");
            DropColumn("dbo.Jobs", "DateFinishPlan");
            DropColumn("dbo.Jobs", "DateFinished");
            DropColumn("dbo.Jobs", "DateCancelled");
            DropColumn("dbo.Jobs", "UserId");
            DropColumn("dbo.Jobs", "DateEstimatedPackingStart");
            DropColumn("dbo.Jobs", "DateActualPackingStart");
            DropColumn("dbo.Jobs", "DateEstimatedPackingFinish");
            DropColumn("dbo.Jobs", "DateActualPackingFinish");
            DropColumn("dbo.Jobs", "DateEstimatedMoveStart");
            DropColumn("dbo.Jobs", "DateActualMoveStart");
            DropColumn("dbo.Jobs", "DateEstimatedMoveFinish");
            DropColumn("dbo.Jobs", "DateActualMoveFinish");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Jobs", "DateActualMoveFinish", c => c.DateTime());
            AddColumn("dbo.Jobs", "DateEstimatedMoveFinish", c => c.DateTime(nullable: false));
            AddColumn("dbo.Jobs", "DateActualMoveStart", c => c.DateTime());
            AddColumn("dbo.Jobs", "DateEstimatedMoveStart", c => c.DateTime(nullable: false));
            AddColumn("dbo.Jobs", "DateActualPackingFinish", c => c.DateTime());
            AddColumn("dbo.Jobs", "DateEstimatedPackingFinish", c => c.DateTime(nullable: false));
            AddColumn("dbo.Jobs", "DateActualPackingStart", c => c.DateTime());
            AddColumn("dbo.Jobs", "DateEstimatedPackingStart", c => c.DateTime(nullable: false));
            AddColumn("dbo.Jobs", "UserId", c => c.String());
            AddColumn("dbo.Jobs", "DateCancelled", c => c.DateTime());
            AddColumn("dbo.Jobs", "DateFinished", c => c.DateTime());
            AddColumn("dbo.Jobs", "DateFinishPlan", c => c.DateTime(nullable: false));
            AddColumn("dbo.Jobs", "DateStarted", c => c.DateTime());
            AddColumn("dbo.Jobs", "DateStartPlan", c => c.DateTime(nullable: false));
            AddColumn("dbo.Jobs", "Status", c => c.Int(nullable: false));
            DropForeignKey("dbo.UserJobs", "JobId", "dbo.Jobs");
            DropIndex("dbo.UserJobs", new[] { "JobId" });
            DropColumn("dbo.Jobs", "Notes");
            DropColumn("dbo.Jobs", "ClientAddress");
            DropTable("dbo.UserJobs");
        }
    }
}
