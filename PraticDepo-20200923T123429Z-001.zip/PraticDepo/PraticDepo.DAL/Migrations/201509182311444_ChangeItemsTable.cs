namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeItemsTable : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Items", "RoomPartId", "dbo.RoomParts");
            DropIndex("dbo.Items", new[] { "RoomPartId" });
            AlterColumn("dbo.Items", "RoomPartId", c => c.Guid());
            CreateIndex("dbo.Items", "RoomPartId");
            AddForeignKey("dbo.Items", "RoomPartId", "dbo.RoomParts", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Items", "RoomPartId", "dbo.RoomParts");
            DropIndex("dbo.Items", new[] { "RoomPartId" });
            AlterColumn("dbo.Items", "RoomPartId", c => c.Guid(nullable: false));
            CreateIndex("dbo.Items", "RoomPartId");
            AddForeignKey("dbo.Items", "RoomPartId", "dbo.RoomParts", "Id", cascadeDelete: false);
        }
    }
}
