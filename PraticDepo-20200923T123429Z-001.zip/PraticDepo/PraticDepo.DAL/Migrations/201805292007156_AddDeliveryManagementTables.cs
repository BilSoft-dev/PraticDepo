namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddDeliveryManagementTables : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.DeliveryRequestCollectionItems",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        DeliveryRequestCollectionId = c.Guid(nullable: false),
                        ItemId = c.Guid(nullable: false),
                        ChapterId = c.Guid(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.DeliveryRequestCollections", t => t.DeliveryRequestCollectionId, cascadeDelete: true)
                .ForeignKey("dbo.Items", t => t.ItemId, cascadeDelete: false)
                .Index(t => t.DeliveryRequestCollectionId)
                .Index(t => t.ItemId);
            
            CreateTable(
                "dbo.DeliveryRequestCollections",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        DeliveryRequestId = c.Guid(nullable: false),
                        CollectionId = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Collections", t => t.CollectionId, cascadeDelete: false)
                .ForeignKey("dbo.DeliveryRequests", t => t.DeliveryRequestId, cascadeDelete: true)
                .Index(t => t.DeliveryRequestId)
                .Index(t => t.CollectionId);
            
            CreateTable(
                "dbo.DeliveryRequests",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        UserId = c.String(nullable: false, maxLength: 128),
                        Status = c.Int(nullable: false),
                        DateCreated = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: false)
                .Index(t => t.UserId);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.DeliveryRequestCollectionItems", "ItemId", "dbo.Items");
            DropForeignKey("dbo.DeliveryRequestCollectionItems", "DeliveryRequestCollectionId", "dbo.DeliveryRequestCollections");
            DropForeignKey("dbo.DeliveryRequestCollections", "DeliveryRequestId", "dbo.DeliveryRequests");
            DropForeignKey("dbo.DeliveryRequests", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.DeliveryRequestCollections", "CollectionId", "dbo.Collections");
            DropIndex("dbo.DeliveryRequests", new[] { "UserId" });
            DropIndex("dbo.DeliveryRequestCollections", new[] { "CollectionId" });
            DropIndex("dbo.DeliveryRequestCollections", new[] { "DeliveryRequestId" });
            DropIndex("dbo.DeliveryRequestCollectionItems", new[] { "ItemId" });
            DropIndex("dbo.DeliveryRequestCollectionItems", new[] { "DeliveryRequestCollectionId" });
            DropTable("dbo.DeliveryRequests");
            DropTable("dbo.DeliveryRequestCollections");
            DropTable("dbo.DeliveryRequestCollectionItems");
        }
    }
}
