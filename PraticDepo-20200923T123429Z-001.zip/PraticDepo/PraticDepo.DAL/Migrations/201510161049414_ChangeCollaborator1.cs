namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeCollaborator1 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Collaborators", "CollectionId", "dbo.Collections");
            DropIndex("dbo.Collaborators", new[] { "CollectionId" });
            CreateTable(
                "dbo.CollaboratorCollections",
                c => new
                    {
                        Collaborator_Id = c.Guid(nullable: false),
                        Collection_Id = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => new { t.Collaborator_Id, t.Collection_Id })
                .ForeignKey("dbo.Collaborators", t => t.Collaborator_Id, cascadeDelete: false)
                .ForeignKey("dbo.Collections", t => t.Collection_Id, cascadeDelete: false)
                .Index(t => t.Collaborator_Id)
                .Index(t => t.Collection_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CollaboratorCollections", "Collection_Id", "dbo.Collections");
            DropForeignKey("dbo.CollaboratorCollections", "Collaborator_Id", "dbo.Collaborators");
            DropIndex("dbo.CollaboratorCollections", new[] { "Collection_Id" });
            DropIndex("dbo.CollaboratorCollections", new[] { "Collaborator_Id" });
            DropTable("dbo.CollaboratorCollections");
            CreateIndex("dbo.Collaborators", "CollectionId");
            AddForeignKey("dbo.Collaborators", "CollectionId", "dbo.Collections", "Id", cascadeDelete: false);
        }
    }
}
