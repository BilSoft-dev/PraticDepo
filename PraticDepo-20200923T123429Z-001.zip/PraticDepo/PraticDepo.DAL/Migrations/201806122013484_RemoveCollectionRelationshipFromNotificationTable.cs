namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemoveCollectionRelationshipFromNotificationTable : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Notifications", "CollectionId", "dbo.Collections");
            DropIndex("dbo.Notifications", new[] { "CollectionId" });
        }
        
        public override void Down()
        {
            CreateIndex("dbo.Notifications", "CollectionId");
            AddForeignKey("dbo.Notifications", "CollectionId", "dbo.Collections", "Id", cascadeDelete: true);
        }
    }
}
