namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeCollaborator : DbMigration
    {
        public override void Up()
        {
            DropIndex("dbo.Collaborators", new[] { "User_Id" });
            DropColumn("dbo.Collaborators", "UserId");
            RenameColumn(table: "dbo.Collaborators", name: "User_Id", newName: "UserId");
            AlterColumn("dbo.Collaborators", "UserId", c => c.String(maxLength: 128));
            CreateIndex("dbo.Collaborators", "UserId");
        }
        
        public override void Down()
        {
            DropIndex("dbo.Collaborators", new[] { "UserId" });
            AlterColumn("dbo.Collaborators", "UserId", c => c.Guid());
            RenameColumn(table: "dbo.Collaborators", name: "UserId", newName: "User_Id");
            AddColumn("dbo.Collaborators", "UserId", c => c.Guid());
            CreateIndex("dbo.Collaborators", "User_Id");
        }
    }
}
