namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddBarcodeToCollectionsItemsVideoChapter : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Collections", "Barcode", c => c.String(maxLength: 512));
            AddColumn("dbo.Items", "Barcode", c => c.String(maxLength: 512));
            AddColumn("dbo.VideoChapters", "Barcode", c => c.String(maxLength: 512));
        }
        
        public override void Down()
        {
            DropColumn("dbo.VideoChapters", "Barcode");
            DropColumn("dbo.Items", "Barcode");
            DropColumn("dbo.Collections", "Barcode");
        }
    }
}
