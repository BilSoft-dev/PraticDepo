namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NotificationTableChanges : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Notifications", "RequestId", c => c.Guid());
        }
        
        public override void Down()
        {
            DropColumn("dbo.Notifications", "RequestId");
        }
    }
}
