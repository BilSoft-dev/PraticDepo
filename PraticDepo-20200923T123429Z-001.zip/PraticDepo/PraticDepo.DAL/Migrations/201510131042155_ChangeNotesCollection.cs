namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeNotesCollection : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Notes", "CollectionId", "dbo.RoomParts");
            AddColumn("dbo.Notes", "RoomPart_Id", c => c.Guid());
            CreateIndex("dbo.Notes", "RoomPart_Id");
            AddForeignKey("dbo.Notes", "RoomPart_Id", "dbo.RoomParts", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Notes", "RoomPart_Id", "dbo.RoomParts");
            DropIndex("dbo.Notes", new[] { "RoomPart_Id" });
            DropColumn("dbo.Notes", "RoomPart_Id");
            AddForeignKey("dbo.Notes", "CollectionId", "dbo.RoomParts", "Id", cascadeDelete: false);
        }
    }
}
