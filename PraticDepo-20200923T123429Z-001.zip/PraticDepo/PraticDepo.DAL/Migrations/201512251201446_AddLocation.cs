namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddLocation : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Rooms", "Home_Id", "dbo.Homes");
            DropForeignKey("dbo.RoomParts", "RoomId", "dbo.Rooms");
            DropForeignKey("dbo.Items", "RoomPartId", "dbo.RoomParts");
            DropForeignKey("dbo.Collections", "RoomPartId", "dbo.RoomParts");
            DropIndex("dbo.Collections", new[] { "RoomPartId" });
            DropIndex("dbo.Items", new[] { "RoomPartId" });
            DropIndex("dbo.RoomParts", new[] { "RoomId" });
            DropIndex("dbo.Rooms", new[] { "Home_Id" });
            CreateTable(
                "dbo.Locations",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        ParentId = c.Guid(),
                        OwnerId = c.String(nullable: false),
                        Name = c.String(nullable: false),
                        Latitude = c.Double(nullable: false),
                        Longitude = c.Double(nullable: false),
                        City = c.String(),
                        CreateAt = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Locations", t => t.ParentId)
                .Index(t => t.ParentId);
            
            AddColumn("dbo.Collections", "LocationId", c => c.Guid(nullable: true));
            AddColumn("dbo.Items", "LocationId", c => c.Guid(nullable: true));
            CreateIndex("dbo.Collections", "LocationId");
            CreateIndex("dbo.Items", "LocationId");
            AddForeignKey("dbo.Items", "LocationId", "dbo.Locations", "Id");
            AddForeignKey("dbo.Collections", "LocationId", "dbo.Locations", "Id");
            DropColumn("dbo.Collections", "RoomPartId");
            DropColumn("dbo.Items", "RoomPartId");
            //DropTable("dbo.RoomParts");
            //DropTable("dbo.Rooms");
            //DropTable("dbo.Homes");
        }
        
        public override void Down()
        {
            /*CreateTable(
                "dbo.Homes",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 30),
                        Latitude = c.Double(nullable: false),
                        Longitude = c.Double(nullable: false),
                        Address = c.String(),
                        OwnerId = c.String(),
                        City = c.String(),
                        CreateAt = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Rooms",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 30),
                        CreateAt = c.DateTime(nullable: false),
                        Home_Id = c.Guid(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.RoomParts",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 30),
                        CreateAt = c.DateTime(nullable: false),
                        RoomId = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => t.Id);*/
            
            AddColumn("dbo.Items", "RoomPartId", c => c.Guid());
            AddColumn("dbo.Collections", "RoomPartId", c => c.Guid());
            DropForeignKey("dbo.Collections", "LocationId", "dbo.Locations");
            DropForeignKey("dbo.Items", "LocationId", "dbo.Locations");
            DropForeignKey("dbo.Locations", "ParentId", "dbo.Locations");
            DropIndex("dbo.Locations", new[] { "ParentId" });
            DropIndex("dbo.Items", new[] { "LocationId" });
            DropIndex("dbo.Collections", new[] { "LocationId" });
            DropColumn("dbo.Items", "LocationId");
            DropColumn("dbo.Collections", "LocationId");
            DropTable("dbo.Locations");
            CreateIndex("dbo.Rooms", "Home_Id");
            CreateIndex("dbo.RoomParts", "RoomId");
            CreateIndex("dbo.Items", "RoomPartId");
            CreateIndex("dbo.Collections", "RoomPartId");
            AddForeignKey("dbo.Collections", "RoomPartId", "dbo.RoomParts", "Id");
            AddForeignKey("dbo.Items", "RoomPartId", "dbo.RoomParts", "Id");
            AddForeignKey("dbo.RoomParts", "RoomId", "dbo.Rooms", "Id", cascadeDelete: true);
            AddForeignKey("dbo.Rooms", "Home_Id", "dbo.Homes", "Id");
        }
    }
}
