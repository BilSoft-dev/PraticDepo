namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddChaptersTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.VideoChapters",
                c => new
                {
                    Id = c.Guid(nullable: false),
                    Name = c.String(nullable: false, maxLength: 50),
                    Time = c.Int(nullable: false),
                    VideoId = c.Guid(),
                    CoverId = c.Guid()
                })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Media", t => t.VideoId)
                .ForeignKey("dbo.Media", t => t.CoverId)
                .Index(t => t.VideoId);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.VideoChapters", "VideoId", "dbo.Media");
            DropForeignKey("dbo.VideoChapters", "CoverId", "dbo.Media");
            DropIndex("dbo.VideoChapters", new[] { "VideoId" });
            DropTable("dbo.VideoChapters");
        }
    }
}
