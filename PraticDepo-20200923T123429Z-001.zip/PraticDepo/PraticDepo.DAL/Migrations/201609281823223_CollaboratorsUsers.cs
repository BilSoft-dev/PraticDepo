namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CollaboratorsUsers : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CollaboratorsUsers",
                c => new
                    {
                        CreatedBy = c.String(nullable: false, maxLength: 128),
                        Id = c.Guid(nullable: false),
                    })
                .PrimaryKey(t => new { t.CreatedBy, t.Id })
                .ForeignKey("dbo.AspNetUsers", t => t.CreatedBy, cascadeDelete: true)
                .ForeignKey("dbo.Collaborators", t => t.Id, cascadeDelete: true)
                .Index(t => t.CreatedBy)
                .Index(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CollaboratorsUsers", "Id", "dbo.Collaborators");
            DropForeignKey("dbo.CollaboratorsUsers", "CreatedBy", "dbo.AspNetUsers");
            DropIndex("dbo.CollaboratorsUsers", new[] { "Id" });
            DropIndex("dbo.CollaboratorsUsers", new[] { "CreatedBy" });
            DropTable("dbo.CollaboratorsUsers");
        }
    }
}
