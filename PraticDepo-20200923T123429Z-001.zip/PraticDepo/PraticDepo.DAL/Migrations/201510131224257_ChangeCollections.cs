namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeCollections : DbMigration
    {
        public override void Up()
        {
            //RenameColumn(table: "dbo.Collaborators", name: "Collection_Id", newName: "CollectionId");
            //RenameIndex(table: "dbo.Collaborators", name: "IX_Collection_Id", newName: "IX_CollectionId");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.Collaborators", name: "IX_CollectionId", newName: "IX_Collection_Id");
            RenameColumn(table: "dbo.Collaborators", name: "CollectionId", newName: "Collection_Id");
        }
    }
}
