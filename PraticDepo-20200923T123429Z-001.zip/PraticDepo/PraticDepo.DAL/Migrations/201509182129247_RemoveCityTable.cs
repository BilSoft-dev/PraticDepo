namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemoveCityTable : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Homes", "City_Id", "dbo.Cities");
            DropIndex("dbo.Homes", new[] { "City_Id" });
            AddColumn("dbo.Homes", "City", c => c.String());
            DropColumn("dbo.Homes", "City_Id");
            DropTable("dbo.Cities");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.Cities",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Name = c.String(nullable: false),
                        Latitude = c.Double(nullable: false),
                        Longitude = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.Homes", "City_Id", c => c.Guid());
            DropColumn("dbo.Homes", "City");
            CreateIndex("dbo.Homes", "City_Id");
            AddForeignKey("dbo.Homes", "City_Id", "dbo.Cities", "Id");
        }
    }
}
