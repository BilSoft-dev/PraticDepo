namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangeNotes : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Notes", "CollectionId", "dbo.Collections");
            DropForeignKey("dbo.Notes", "RoomPart_Id", "dbo.RoomParts");
            DropIndex("dbo.Notes", new[] { "CollectionId" });
            DropIndex("dbo.Notes", new[] { "RoomPart_Id" });
            AddColumn("dbo.Notes", "ItemId", c => c.Guid(nullable: false));
            CreateIndex("dbo.Notes", "ItemId");
            AddForeignKey("dbo.Notes", "ItemId", "dbo.Items", "Id", cascadeDelete: false);
            DropColumn("dbo.Notes", "CollectionId");
            DropColumn("dbo.Notes", "RoomPart_Id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Notes", "RoomPart_Id", c => c.Guid());
            AddColumn("dbo.Notes", "CollectionId", c => c.Guid(nullable: false));
            DropForeignKey("dbo.Notes", "ItemId", "dbo.Items");
            DropIndex("dbo.Notes", new[] { "ItemId" });
            DropColumn("dbo.Notes", "ItemId");
            CreateIndex("dbo.Notes", "RoomPart_Id");
            CreateIndex("dbo.Notes", "CollectionId");
            AddForeignKey("dbo.Notes", "RoomPart_Id", "dbo.RoomParts", "Id");
            AddForeignKey("dbo.Notes", "CollectionId", "dbo.Collections", "Id", cascadeDelete: false);
        }
    }
}
