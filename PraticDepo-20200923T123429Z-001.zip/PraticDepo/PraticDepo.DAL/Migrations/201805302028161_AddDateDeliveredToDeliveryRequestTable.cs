namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddDateDeliveredToDeliveryRequestTable : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.DeliveryRequests", "DateDelivered", c => c.DateTime());
        }
        
        public override void Down()
        {
            DropColumn("dbo.DeliveryRequests", "DateDelivered");
        }
    }
}
