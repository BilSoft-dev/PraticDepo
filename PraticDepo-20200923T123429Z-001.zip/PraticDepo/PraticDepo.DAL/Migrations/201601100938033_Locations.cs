namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Locations : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Items", "LocationId", "dbo.Locations");
            DropIndex("dbo.Items", new[] { "LocationId" });
            //AlterColumn("dbo.Items", "LocationId", c => c.Guid(nullable: false));
            CreateIndex("dbo.Items", "LocationId");
            AddForeignKey("dbo.Items", "LocationId", "dbo.Locations", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Items", "LocationId", "dbo.Locations");
            DropIndex("dbo.Items", new[] { "LocationId" });
            AlterColumn("dbo.Items", "LocationId", c => c.Guid());
            CreateIndex("dbo.Items", "LocationId");
            AddForeignKey("dbo.Items", "LocationId", "dbo.Locations", "Id");
        }
    }
}
