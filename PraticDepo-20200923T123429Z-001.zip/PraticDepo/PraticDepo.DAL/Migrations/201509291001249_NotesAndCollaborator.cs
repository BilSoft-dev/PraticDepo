namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NotesAndCollaborator : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Notes",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        CollectionId = c.Guid(nullable: false),
                        Text = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.RoomParts", t => t.CollectionId, cascadeDelete: false)
                .Index(t => t.CollectionId);
            
            AddColumn("dbo.Collaborators", "CollectionId", c => c.Guid(nullable: false));
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Notes", "CollectionId", "dbo.RoomParts");
            DropIndex("dbo.Notes", new[] { "CollectionId" });
            DropColumn("dbo.Collaborators", "CollectionId");
            DropTable("dbo.Notes");
        }
    }
}
