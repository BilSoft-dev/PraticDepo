namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CollectionCollaboratorsCascadeDelete : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.CollectionCollaborators", "FK_dbo.CollaboratorCollections_dbo.Collaborators_Collaborator_Id");
            DropForeignKey("dbo.CollectionCollaborators", "Collaborator_Id", "dbo.Collaborators");
            AddForeignKey("dbo.CollectionCollaborators", "Collaborator_Id", "dbo.Collaborators", "Id", cascadeDelete: true);

            DropForeignKey("dbo.CollectionCollaborators", "FK_dbo.CollaboratorCollections_dbo.Collections_Collection_Id");
            DropForeignKey("dbo.CollectionCollaborators", "Collection_Id", "dbo.Collections");
            AddForeignKey("dbo.CollectionCollaborators", "Collection_Id", "dbo.Collections", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CollectionCollaborators", "Collaborator_Id", "dbo.Collaborators");
            AddForeignKey("dbo.CollectionCollaborators", "Collaborator_Id", "dbo.Collaborators", "Id", cascadeDelete: false);

            DropForeignKey("dbo.CollectionCollaborators", "Collection_Id", "dbo.Collections");
            AddForeignKey("dbo.CollectionCollaborators", "Collection_Id", "dbo.Collections", "Id", cascadeDelete: false);
        }
    }
}
