namespace PraticDepo.DAL.Migrations
{
    using Microsoft.AspNet.Identity.EntityFramework;
    using PraticDepo.DAL.Configs;
    using PraticDepo.DAL.Models;
    using System;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<PraticDepo.DAL.AuthContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(PraticDepo.DAL.AuthContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            /*
            Guid userId = Guid.NewGuid();
            context.Users.AddOrUpdate(
                u => u.Email,
                new ApplicationUser { Id = userId.ToString(), Email = AdminConfig.EMAIL, PasswordHash = AdminConfig.PASSWORD_HASH, FirstName = "Admin", LastName = "Admin", SecurityStamp = Guid.NewGuid().ToString(), EmailConfirmed = true, PhoneNumberConfirmed = false, TwoFactorEnabled = false, LockoutEnabled = false, UserName = AdminConfig.NAME }
                );
            */

            foreach (var roleKey in ShedRoleConfig.GetRoleKeys())
            {
                var roleInfo = ShedRoleConfig.GetRoleInfo(roleKey);
                context.Roles.AddOrUpdate(r => r.Name, new ApplicationRole { Name = roleKey, Description = roleInfo.Description });
            }

            var adminUser = context.Users.SingleOrDefault(u => u.Email == AdminConfig.EMAIL);
            var adminRole = context.Roles.SingleOrDefault(r => r.Name == ShedRoleConfig.ADMIN_ROLE);
            if (adminUser != null && adminRole != null)
            {
                context.Set<IdentityUserRole>().AddOrUpdate(
                            r => r.UserId,
                            new IdentityUserRole { RoleId = adminRole.Id, UserId = adminUser.Id }
                        );
                context.SaveChanges();
            }

            foreach (var roleKey in ShedRoleConfig.GetRoleKeys())
            {
                var role = context.Roles.SingleOrDefault(r => r.Name == roleKey);
                ShedRoleConfig.SetDbId(roleKey, role.Id);
            }

            context.Locations.AddOrUpdate(l => new { l.Name, l.OwnerId }, new Location
            {
                Id = Guid.NewGuid(),
                ParentId = null,
                OwnerId = adminUser.Id,
                Name = ShedStorageConfig.NAME,
                Latitude = ShedStorageConfig.LATITUDE,
                Longitude = ShedStorageConfig.LONGITUDE,
                City = ShedStorageConfig.CITY,
                CreateAt = DateTime.Now
            });
            context.SaveChanges();

            var adminRoleDbId = ShedRoleConfig.GetRoleInfo(ShedRoleConfig.ADMIN_ROLE).DbId;
            var usersWithoutRoles = context.Users.Where(x => x.Id != adminUser.Id && x.Roles.Count(r => r.RoleId != adminRoleDbId) == 0);

            if (usersWithoutRoles.Any())
            {
                var regularRoleDbId = ShedRoleConfig.GetRoleInfo(ShedRoleConfig.REGULARUSER_ROLE).DbId;

                foreach (var user in usersWithoutRoles)
                {
                    context.Set<IdentityUserRole>().Add(new IdentityUserRole { RoleId = regularRoleDbId, UserId = user.Id });
                }
                context.SaveChanges();
            }

            AdminConfig.Id = adminUser.Id;
        }
    }
}