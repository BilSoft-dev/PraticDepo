namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TablesCleanUp : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Notifications", "CollectionId", "dbo.RoomParts");
            DropTable("dbo.RoomParts");
            DropTable("dbo.Homes");
            DropTable("dbo.Rooms");
            AddForeignKey("dbo.Notifications", "CollectionId", "dbo.Collections", "Id");
            DropForeignKey("dbo.Items", "Collection_Id", "dbo.Collections");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.Homes",
                c => new
                {
                    Id = c.Guid(nullable: false),
                    Name = c.String(nullable: false, maxLength: 30),
                    Latitude = c.Double(nullable: false),
                    Longitude = c.Double(nullable: false),
                    City_Id = c.Guid(),
                })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Cities", t => t.City_Id, cascadeDelete: true)
                .Index(t => t.City_Id);

            CreateTable(
                "dbo.Rooms",
                c => new
                {
                    Id = c.Guid(nullable: false),
                    Name = c.String(nullable: false, maxLength: 30),
                    Home_Id = c.Guid(),
                })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Homes", t => t.Home_Id, cascadeDelete: true)
                .Index(t => t.Home_Id);

            CreateTable(
                "dbo.RoomParts",
                c => new
                {
                    Id = c.Guid(nullable: false),
                    Name = c.String(nullable: false, maxLength: 30),
                    Room_Id = c.Guid(),
                })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Rooms", t => t.Room_Id, cascadeDelete: true)
                .Index(t => t.Room_Id);
            DropForeignKey("dbo.Notifications", "CollectionId", "dbo.Collections");
            AddForeignKey("dbo.Notifications", "CollectionId", "dbo.RoomParts", "Id");
            AddForeignKey("dbo.Items", "Collection_Id", "dbo.Collections", "Id");
        }
    }
}
