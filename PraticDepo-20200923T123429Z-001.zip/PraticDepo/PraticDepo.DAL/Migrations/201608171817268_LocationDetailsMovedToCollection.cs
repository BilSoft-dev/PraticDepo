namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class LocationDetailsMovedToCollection : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Items", "CollectionId", "dbo.Collections");
            DropForeignKey("dbo.Collections", "LocationId", "dbo.Locations");
            DropIndex("dbo.Collections", new[] { "LocationId" });
            DropIndex("dbo.Items", new[] { "CollectionId" });
            RenameColumn(table: "dbo.Collections", name: "LocationId", newName: "HomeId");
            AddColumn("dbo.Collections", "RoomId", c => c.Guid());
            AddColumn("dbo.Collections", "RoomPartId", c => c.Guid());
            AlterColumn("dbo.Collections", "HomeId", c => c.Guid(nullable: false));
            AlterColumn("dbo.Items", "CollectionId", c => c.Guid(nullable: false));
            CreateIndex("dbo.Collections", "HomeId");
            CreateIndex("dbo.Collections", "RoomId");
            CreateIndex("dbo.Collections", "RoomPartId");
            CreateIndex("dbo.Items", "CollectionId");
            AddForeignKey("dbo.Collections", "RoomId", "dbo.Locations", "Id");
            AddForeignKey("dbo.Collections", "RoomPartId", "dbo.Locations", "Id");
            AddForeignKey("dbo.Items", "CollectionId", "dbo.Collections", "Id", cascadeDelete: true);
            AddForeignKey("dbo.Collections", "HomeId", "dbo.Locations", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Collections", "HomeId", "dbo.Locations");
            DropForeignKey("dbo.Items", "CollectionId", "dbo.Collections");
            DropForeignKey("dbo.Collections", "RoomPartId", "dbo.Locations");
            DropForeignKey("dbo.Collections", "RoomId", "dbo.Locations");
            DropIndex("dbo.Items", new[] { "CollectionId" });
            DropIndex("dbo.Collections", new[] { "RoomPartId" });
            DropIndex("dbo.Collections", new[] { "RoomId" });
            DropIndex("dbo.Collections", new[] { "HomeId" });
            AlterColumn("dbo.Items", "CollectionId", c => c.Guid());
            AlterColumn("dbo.Collections", "HomeId", c => c.Guid());
            DropColumn("dbo.Collections", "RoomPartId");
            DropColumn("dbo.Collections", "RoomId");
            RenameColumn(table: "dbo.Collections", name: "HomeId", newName: "LocationId");
            CreateIndex("dbo.Items", "CollectionId");
            CreateIndex("dbo.Collections", "LocationId");
            AddForeignKey("dbo.Collections", "LocationId", "dbo.Locations", "Id");
            AddForeignKey("dbo.Items", "CollectionId", "dbo.Collections", "Id");
        }
    }
}
