namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddUserIntoCollections : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Collections", "UserId", c => c.String(nullable: false, maxLength: 128));
            CreateIndex("dbo.Collections", "UserId");
            AddForeignKey("dbo.Collections", "UserId", "dbo.AspNetUsers", "Id", cascadeDelete: false);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Collections", "UserId", "dbo.AspNetUsers");
            DropIndex("dbo.Collections", new[] { "UserId" });
            DropColumn("dbo.Collections", "UserId");
        }
    }
}
