namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemoveItemIdFromLocations : DbMigration
    {
        public override void Up()
        {
            //DropColumn("dbo.Locations", "ItemId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Locations", "ItemId", c => c.Guid());
        }
    }
}
