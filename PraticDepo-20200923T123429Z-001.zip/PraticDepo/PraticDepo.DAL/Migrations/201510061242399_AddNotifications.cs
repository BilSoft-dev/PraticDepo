namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddNotifications : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Notifications",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        UserId = c.String(nullable: false),
                        CollectionId = c.Guid(nullable: false),
                        Text = c.String(nullable: false),
                        CreateAt = c.DateTime(nullable: false),
                        IsReaded = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.RoomParts", t => t.CollectionId, cascadeDelete: false)
                .Index(t => t.CollectionId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Notifications", "CollectionId", "dbo.RoomParts");
            DropIndex("dbo.Notifications", new[] { "CollectionId" });
            DropTable("dbo.Notifications");
        }
    }
}
