namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddUnitNumberToCollection : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Collections", "StorageLocation", c => c.String(maxLength: 5));
            AddColumn("dbo.Collections", "BinNumber", c => c.String(maxLength: 4));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Collections", "BinNumber");
            DropColumn("dbo.Collections", "StorageLocation");
        }
    }
}
