namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddJobCollectionsTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.JobCollections",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        JobId = c.Guid(nullable: false),
                        CollectionId = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Jobs", t => t.JobId, cascadeDelete: true)
                .Index(t => t.JobId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.JobCollections", "JobId", "dbo.Jobs");
            DropIndex("dbo.JobCollections", new[] { "JobId" });
            DropTable("dbo.JobCollections");
        }
    }
}
