namespace PraticDepo.DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DropLocationInItem : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Items", "LocationId", "dbo.Locations");
            DropIndex("dbo.Items", new[] { "LocationId" });
            DropColumn("dbo.Items", "LocationId");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Items", "LocationId", c => c.Guid(nullable: false));
            CreateIndex("dbo.Items", "LocationId");
            AddForeignKey("dbo.Items", "LocationId", "dbo.Locations", "Id", cascadeDelete: true);
        }
    }
}
