﻿using PraticDepo.DAL.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraticDepo.DAL.Repository
{
    public class UsersRepository : IDisposable
    {
        private AuthContext context;
        private readonly DbSqlQuery<ApplicationUser> _set;

        public AuthContext Context { get { return context; } }

        public UsersRepository()
        {
            context = new AuthContext();
            //_set = context.Set<ApplicationUser>();
            _set = context.Set<ApplicationUser>().SqlQuery("select * from AspNetUsers");
        }

        public IQueryable<ApplicationUser> GetAll()
        {
            return _set.AsQueryable();
        }

        public ApplicationUser GetById(string userId)
        {
            return _set.SingleOrDefault(x => x.Id == userId);
        }

        public string GetUserName(string userId)
        {
            var user = GetById(userId);
            return string.Format("{0} {1}", user.FirstName, user.LastName).Trim();
        }

        public string GetUserEmail(string userId)
        {
            var user = GetById(userId);
            return user.Email;
        }

        public void UpdateUser(ApplicationUser user)
        {
            context.Entry<ApplicationUser>(user).State = EntityState.Modified;
            context.SaveChanges();
        }

        public void Dispose()
        {
            context.Dispose();
        }
    }
}
