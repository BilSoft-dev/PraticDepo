﻿using System;
using System.Collections.Generic;
using System.Linq;
using PraticDepo.DAL.Models;

namespace PraticDepo.DAL.Configs
{
    public static class ShedRoleConfig
    {
        public const string ADMIN_ROLE = "Admin";
        public const string SHEDUSER_ROLE = "ShedUser";
        public const string REGULARUSER_ROLE = "RegularUser";

        private static Dictionary<string, ShedRoleInfo> roles = new Dictionary<string, ShedRoleInfo>();

        static ShedRoleConfig()
        {
            roles.Add(ADMIN_ROLE, new ShedRoleInfo { Id = 1, Description = "Administrator" });
            roles.Add(SHEDUSER_ROLE, new ShedRoleInfo { Id = 2, Description = "Shed User" });
            roles.Add(REGULARUSER_ROLE, new ShedRoleInfo { Id = 3, Description = "Regular User" });
        }

        public static List<string> GetRoleKeys()
        {
            return roles.Keys.ToList();
        }

        public static Dictionary<string, string> GetAllRoles(bool shouldExcludeAdminRole = true)
        {
            if (shouldExcludeAdminRole)
            {
                return roles.Where(x => x.Key != ADMIN_ROLE).ToDictionary(d => d.Key, d => d.Value.Description);
            }
            else
            {
                return roles.ToDictionary(d => d.Key, d => d.Value.Description);
            }
        }

        public static ShedRoleInfo GetRoleInfo(string roleKey)
        {
            return roles[roleKey];
        }

        public static void SetDbId(string roleKey, string dbId)
        {
            var roleInfo = GetRoleInfo(roleKey);
            roleInfo.DbId = dbId;
        }

        public static string GetRoleKey(List<string> roleDbIds)
        {
            foreach (var roleDbId in roleDbIds)
            {
                var roleKey = GetRoleKeyByDbId(roleDbId);
                if (roleKey != ADMIN_ROLE) return roleKey;
            }

            return REGULARUSER_ROLE;
        }

        public static string GetRoleByPriorityKey(List<string> roleDbIds)
        {
            var rolesPriorityList = roles.OrderBy(kvp => kvp.Value.Id);

            foreach (var role in rolesPriorityList)
            {
                if (roleDbIds.Contains(role.Value.DbId))
                {
                    return role.Key;
                }
            }

            return REGULARUSER_ROLE;
        }

        private static string GetRoleKeyByDbId(string dbId)
        {
            var role = roles.FirstOrDefault(x => x.Value.DbId == dbId);

            if (string.IsNullOrEmpty(role.Key)) return string.Empty;

            return role.Key;
        }
    }
}