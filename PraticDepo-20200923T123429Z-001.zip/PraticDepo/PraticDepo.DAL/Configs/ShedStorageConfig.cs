﻿using System;

namespace PraticDepo.DAL.Configs
{
    public static class ShedStorageConfig
    {
        public const string NAME = "Shed Storage";
        public const double LATITUDE = 49.144579;
        public const double LONGITUDE = -123.002211;
        public const string CITY = "7950 Huston Rd, Delta, BC V4G 1A8";
    }
}