﻿using System;

namespace PraticDepo.DAL.Configs
{
    public static class AdminConfig
    {
        public static string Id { get; set; }

        public const string EMAIL = "admin@admin.com";
        public const string NAME = "admin@admin.com";

        public const string PASSWORD_HASH = "AJvoFhBnqV0uWoGozE7OuWJ0L+SWPJhPXvAW6x7ZSv0bUJi7rTmw9UKDWJBaLLX4ug==";
        //"AGPLP9pWGWqiMMh0C4zQiVB3v19r7ZO61W74epKXO6ebePYxdbEggNPbBgp8HxjMvw==";
    }
}