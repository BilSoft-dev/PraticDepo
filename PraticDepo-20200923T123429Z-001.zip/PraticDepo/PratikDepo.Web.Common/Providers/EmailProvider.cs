﻿using System;
using System.Threading.Tasks;
using System.Net.Mail;
using Microsoft.AspNet.Identity;

namespace PraticDepo.Web.Common.Providers
{
    public class EmailProvider
    {
        public async Task SendMailAsync(IdentityMessage model)
        {
            var message = new MailMessage();
            message.To.Add(model.Destination);
            message.Subject = model.Subject;
            message.Body = model.Body;
            message.IsBodyHtml = true;

            using (var client = new SmtpClient())
            {
                await client.SendMailAsync(message);
            }
        }

        public async Task SendMailAsync(string to, string subject, string body)
        {
            var message = new MailMessage();
            message.To.Add(to);
            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = true;

            using (var client = new SmtpClient())
            {
                await client.SendMailAsync(message);
            }
        }

        public void SendMail(IdentityMessage model)
        {
            var message = new MailMessage();
            message.To.Add(new MailAddress(model.Destination));
            message.Subject = model.Subject;
            message.Body = model.Body;
            message.IsBodyHtml = true;

            using (var client = new SmtpClient())
            {
                client.Send(message);
            }
        }

        public void SendMail(string to, string subject, string body)
        {
            var message = new MailMessage();
            message.To.Add(to);
            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = true;

            using (var client = new SmtpClient())
            {
                client.Send(message);
            }
        }
    }
}