﻿using System;
using System.Text.RegularExpressions;
using System.Web.Security;

namespace PraticDepo.Web.Common.Helpers
{
    public class PasswordGenerator
    {
        public static string GeneratePassword()
        {
            var password = Membership.GeneratePassword(10, 0);
            var rand = new Random();
            return Regex.Replace(password, @"[^a-zA-Z0-9]", m => rand.Next(0, 9).ToString());
        }
    }
}