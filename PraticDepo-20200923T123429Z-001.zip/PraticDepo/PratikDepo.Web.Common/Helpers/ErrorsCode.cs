﻿namespace PraticDepo.Web.Common.Helpers
{
    public class ErrorsCode
    {
        public static string USERERROR = "user with such email already exists";
        public static string FBIDERROR = "user with such ID already exists";
        public static string FBERROR = "Wrong Facebook Token";
        public static string EMAILERROR = "This email address is already being used. Please enter another email address.";
    }

    public enum ErrorCode
    {
        USERERROR = 1,
        FBIDERROR,
        FBERROR,
        EMAILERROR
    }
}