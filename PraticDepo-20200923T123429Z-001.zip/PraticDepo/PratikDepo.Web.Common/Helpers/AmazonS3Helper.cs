﻿using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using PraticDepo.BusinessLayer.Item;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Threading.Tasks;

namespace PraticDepo.Web.Common.Helpers
{
    public class AmazonS3Helper
    {
        private readonly string bucketName;
        private IAmazonS3 s3Client;

        public AmazonS3Helper()
        {
            bucketName = ConfigurationManager.AppSettings["S3BucketName"];
        }

        public async Task<string> UploadPhoto(string base64Content, string fileExtension)
        {
            string key = Guid.NewGuid().ToString();
            using (s3Client = new AmazonS3Client())
            {
                using (TransferUtility fileTransferUtility = new TransferUtility(s3Client))
                {
                    using (MemoryStream stream = new MemoryStream(Convert.FromBase64String(base64Content)))
                    {
                        using (MemoryStream previewStream = new MemoryStream())
                        {
                            MediaService.CreatePhotoPreview(stream, previewStream);
                            var previewUploadRequest = new TransferUtilityUploadRequest
                            {
                                BucketName = bucketName,
                                InputStream = previewStream,
                                StorageClass = S3StorageClass.Standard,
                                Key = string.Format("photo/{0}_preview{1}", key, fileExtension),
                                CannedACL = S3CannedACL.Private
                            };
                            await fileTransferUtility.UploadAsync(previewUploadRequest);
                        }

                        var fileTransferUtilityRequest = new TransferUtilityUploadRequest
                        {
                            BucketName = bucketName,
                            InputStream = stream,
                            StorageClass = S3StorageClass.Standard,
                            Key = string.Format("photo/{0}{1}", key, fileExtension),
                            CannedACL = S3CannedACL.Private
                        };
                        await fileTransferUtility.UploadAsync(fileTransferUtilityRequest);
                    }
                }

            }
            return string.Format("photo/{0}{1}", key, fileExtension);
        }

        public async Task<string> UploadVideo(string base64Content, string fileExtension)
        {
            string key = string.Format("video/{0}{1}", Guid.NewGuid().ToString(), fileExtension);
            using (s3Client = new AmazonS3Client())
            {
                using (TransferUtility fileTransferUtility = new TransferUtility(s3Client))
                {
                    using (MemoryStream stream = new MemoryStream(Convert.FromBase64String(base64Content)))
                    {
                        var fileTransferUtilityRequest = new TransferUtilityUploadRequest
                        {
                            BucketName = bucketName,
                            InputStream = stream,
                            StorageClass = S3StorageClass.Standard,
                            Key = key,
                            CannedACL = S3CannedACL.Private
                        };
                        await fileTransferUtility.UploadAsync(fileTransferUtilityRequest);
                    }
                }

            }
            return key;
        }

        public async Task<string> UploadVideo(Stream stream, string fileExtension)
        {
            string key = string.Format("video/{0}{1}", Guid.NewGuid().ToString(), fileExtension);
            using (s3Client = new AmazonS3Client())
            {
                using (TransferUtility fileTransferUtility = new TransferUtility(s3Client))
                {
                    var fileTransferUtilityRequest = new TransferUtilityUploadRequest
                    {
                        BucketName = bucketName,
                        InputStream = stream,
                        StorageClass = S3StorageClass.Standard,
                        Key = key,
                        CannedACL = S3CannedACL.Private
                    };
                    await fileTransferUtility.UploadAsync(fileTransferUtilityRequest);
                }
            }
            return key;
        }

        public string getUrl(string key, DateTime? expireDate = null)
        {
            if (!String.IsNullOrEmpty(key) && !key.Contains("http")) // Need for compatibility
            {
                GetPreSignedUrlRequest request = new GetPreSignedUrlRequest
                {
                    BucketName = bucketName,
                    Key = key,
                    Expires = expireDate.HasValue ? expireDate.Value : DateTime.Now.AddHours(1)
                };
                using (s3Client = new AmazonS3Client())
                {
                    return s3Client.GetPreSignedURL(request);
                }

            }
            else
            {
                return key;
            }


            //UriBuilder builder = new UriBuilder()
            //{
            //    Scheme = "http",
            //    Host = bucketName + ".s3.amazonaws.com",
            //    Path = key,
            //};
            //return builder.Uri.ToString();
        }

        public List<MediaService.MediaModel> ReplaceMediaLinks(List<MediaService.MediaModel> models)
        {
            foreach (MediaService.MediaModel mediaModel in models)
            {
                ReplaceMediaLink(mediaModel);
            }
            return models;
        }

        public MediaService.MediaModel ReplaceMediaLink(MediaService.MediaModel model)
        {
            model.PreviewFilePath = getUrl(GetPreviewKey(model.FilePath));
            model.FilePath = getUrl(model.FilePath);
            if (model.Chapters != null)
            {
                foreach (var chapter in model.Chapters)
                {
                    ReplaceChapterLink(chapter);
                }
            }
            return model;
        }

        public MediaService.Chapter ReplaceChapterLink(MediaService.Chapter chapter)
        {
            chapter.CoverPreview = getUrl(GetPreviewKey(chapter.Cover));
            chapter.Cover = getUrl(chapter.Cover);
            return chapter;
        }

        public string GetPreviewUrl(string key)
        {
            return getUrl(GetPreviewKey(key));
        }

        private string GetPreviewKey(string key)
        {
            int dotIndex = key.LastIndexOf('.');
            string extension;
            string path;
            if (dotIndex > 0)
            {
                extension = key.Substring(dotIndex);
                path = key.Substring(0, dotIndex);
            }
            else
            {
                extension = "";
                path = key;
            }
            return string.Format("{0}_preview{1}", path, extension);
        }

        public void DeleteMedia(MediaService.MediaModel model)
        {
            DeleteMediaForPath(model.FilePath);
            DeleteMediaForPath(GetPreviewKey(model.FilePath));
            if (model.Type == MediaService.MediaType.VIDEO)
            {
                if (model.Chapters != null)
                {
                    model.Chapters.ForEach(x => DeleteMediaForPath(x.Cover));
                    model.Chapters.ForEach(x => DeleteMediaForPath(GetPreviewKey(x.Cover)));
                }
            }
        }

        public void DeleteChapter(MediaService.Chapter chapter)
        {
            DeleteMediaForPath(chapter.Cover);
            DeleteMediaForPath(GetPreviewKey(chapter.Cover));
        }

        private void DeleteMediaForPath(string path)
        {
            using (s3Client = new AmazonS3Client())
            {
                DeleteObjectRequest deleteObject = new DeleteObjectRequest
                {
                    BucketName = bucketName,
                    Key = path
                };

                try
                {
                    s3Client.DeleteObject(deleteObject);
                }
                catch (Exception e)
                {
                    Logger.Instance.Error("Failed to delete file from S3", e);
                }
            }
        }
    }
}