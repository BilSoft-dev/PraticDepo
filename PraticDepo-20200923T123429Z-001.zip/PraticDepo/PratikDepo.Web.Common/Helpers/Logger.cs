﻿using System;
using log4net;
using log4net.Config;

namespace PraticDepo.Web.Common.Helpers
{
    public class Logger
    {
        readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static Logger _instance;
        public static Logger Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Logger();

                return _instance;
            }
        }

        protected Logger()
        {
            BasicConfigurator.Configure();
        }

        public void Debug(string message, Exception exception = null)
        {
            log.Debug(message, exception);
        }

        public void Error(string message, Exception exception = null)
        {
            log.Error(message, exception);
        }

        public void Fatal(string message, Exception exception = null)
        {
            log.Fatal(message, exception);
        }

        public void Warn(string message, Exception exception = null)
        {
            log.Warn(message, exception);
        }

        public void Info(string message, Exception exception = null)
        {
            log.Info(message, exception);
        }
    }
}
