﻿using System;

namespace PraticDepo.Web.Common.Helpers
{
    public class ConfirmCode
    {
        public static string GenerateConfirmCode()
        {
            return new Random().Next(1000, 9999).ToString();
        }
    }
}