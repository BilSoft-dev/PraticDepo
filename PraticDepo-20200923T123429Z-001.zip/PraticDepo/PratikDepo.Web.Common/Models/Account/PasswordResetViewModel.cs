﻿using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Web.Common.Models.Account
{
    public class PasswordResetViewModel
    {
        [Required]
        [EmailAddress(ErrorMessage = "Please use a valid e-mail address")]
        public string Email { get; set; }
    }
}