﻿namespace PraticDepo.Web.Common.Models.Account
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}