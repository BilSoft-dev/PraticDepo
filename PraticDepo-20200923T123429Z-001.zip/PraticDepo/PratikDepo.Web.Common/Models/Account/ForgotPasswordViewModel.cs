﻿using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Web.Common.Models.Account
{
    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress(ErrorMessage = "Please use a valid e-mail address")]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }
}