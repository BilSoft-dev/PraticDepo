﻿namespace PraticDepo.Web.Common.Models.Account
{
    public class UserLoginInfoViewModel
    {
        public string LoginProvider { get; set; }
        public string ProviderKey { get; set; }
    }
}