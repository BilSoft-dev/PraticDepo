﻿using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Web.Common.Models.Account
{
    public class InfoViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        [Display(Name = "Email")]
        [EmailAddress(ErrorMessage = "Wrong email")]
        public string Email { get; set; }

        [Phone(ErrorMessage = "Wrong phone")]
        [MaxLength(10, ErrorMessage = "Phone length must be at 10")]
        public string PhoneNumber { get; set; }

        public bool HasJobStarted { get; set; }
    }
}