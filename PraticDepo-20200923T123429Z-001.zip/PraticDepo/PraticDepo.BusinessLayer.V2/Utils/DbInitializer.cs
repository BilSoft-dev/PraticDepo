﻿using PraticDepo.DAL;
using PraticDepo.DataLayer.Repo;

namespace PraticDepo.BusinessLayer.V2.Utils
{
    public static class DbInitializer
    {
        private static string _connectionString;
        private static AuthContext _context;

        public static void AdminV2Initialize(string connectionString)
        {
            _connectionString = connectionString;
            Storage.Initialize(connectionString);
        }

        public static void WebApiInitialize(AuthContext context)
        {
            //_connectionString = connectionString;
            _context = context;
        }

        public static Storage CreateStorage()
        {
            if (string.IsNullOrEmpty(_connectionString))
            {
                return new Storage();
            }

            return new Storage(_connectionString);
        }
    }
}