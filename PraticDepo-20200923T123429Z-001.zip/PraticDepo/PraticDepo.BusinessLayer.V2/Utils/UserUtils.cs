﻿using PraticDepo.DAL.Configs;
using System;

namespace PraticDepo.BusinessLayer.V2.Utils
{
    public class UserUtils
    {
        public static bool IsShedAdmin(string id)
        {
            return string.Equals(AdminConfig.Id, id, StringComparison.OrdinalIgnoreCase);
        }
    }
}
