﻿using Microsoft.Extensions.Options;
using PraticDepo.BusinessLayer.V2.Models.Configs;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace PraticDepo.BusinessLayer.V2.Utils.Providers.Emails
{
    public class EmailProvider : IEmailProvider
    {
        private readonly SmtpClientConfig _config;

        public EmailProvider(IOptions<SmtpClientConfig> config)
        {
            _config = config.Value;
        }

        public EmailProvider(SmtpClientConfig config)
        {
            _config = config;
        }

        public async Task SendMailAsync(string to, string subject, string body)
        {
            using (var message = new MailMessage(new MailAddress(_config.From, _config.DisplayName), new MailAddress(to)))
            {
                message.Subject = subject;
                message.Body = body;
                message.IsBodyHtml = true;

                using (var client = new SmtpClient(_config.Host, _config.Port))
                {
                    SetSmtpParameters(client);
                    await client.SendMailAsync(message);
                }
            }
        }

        public void SendMail(string to, string subject, string body)
        {
            Task.Factory.StartNew(() =>
            {
                using (var message = new MailMessage(new MailAddress(_config.From, _config.DisplayName), new MailAddress(to)))
                {
                    message.Subject = subject;
                    message.Body = body;
                    message.IsBodyHtml = true;

                    using (var client = new SmtpClient(_config.Host, _config.Port))
                    {
                        SetSmtpParameters(client);
                        client.Send(message);
                    }
                }
            });
        }

        public void SendMail(IEnumerable<string> recipients, string subject, string body)
        {
            Task.Factory.StartNew(() =>
            {
                using (var message = new MailMessage())
                {
                    message.From = new MailAddress(_config.From, _config.DisplayName);
                    message.To.Add(string.Join(",", recipients));
                    message.Subject = subject;
                    message.Body = body;
                    message.IsBodyHtml = true;

                    using (var client = new SmtpClient(_config.Host, _config.Port))
                    {
                        SetSmtpParameters(client);
                        client.Send(message);
                    }
                }
            });
        }

        private void SetSmtpParameters(SmtpClient client)
        {
            client.EnableSsl = _config.EnableSSL;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.Credentials = new NetworkCredential(_config.UserName, _config.Password);
            client.Host = _config.Host;
        }
    }
}
