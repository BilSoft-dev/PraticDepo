﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace PraticDepo.BusinessLayer.V2.Utils.Providers.Emails
{
    public interface IEmailProvider
    {
        void SendMail(string to, string subject, string body);
        Task SendMailAsync(string to, string subject, string body);
        void SendMail(IEnumerable<string> recipients, string subject, string body);
    }
}