﻿using PraticDepo.BusinessLayer.V2.Models.Delivery;
using System;
using System.Globalization;
using System.Text;
using System.Linq;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Utils.Providers.Emails
{
    public static class EmailDataProvider
    {
        public static string GetUserCreatedSubject => "Welcome to Shed";
        public static string GetUserResetedSubject => "Shed Password Reset";
        public static string GetPasswordChangedSubject => "Your password was changed";

        public static string GetUserCreatedEmailBody(string email, string password)
        {
            return "Hi,<br /><br />"
                 + "This email is to confirm that a user account for the Shed Cataloging App has been created for you.<br /><br />"
                 + $"Username: {email}<br />"
                 + $"Password: {password}<br /><br />"
                 + "You can download the iOS version through this link:<br />"
                 + "https://itunes.apple.com/us/app/shed-smarter-living/id1279781718<br />"
                 + "You can download the Android version through this link:<br />"
                 + "https://play.google.com/store/apps/details?id=com.shedthat.app<br /><br />"
                 + "We are looking forward to serving you.<br /><br />"
                 + "Best Regards,<br /><br />"
                 + "Shed Services Team";
        }

        public static string GetUserResettedEmailBody(string email, string password)
        {
            return "Hi,<br /><br />"
                 + "This email is to confirm that a password for your account has been reset.<br /><br />"
                 + $"Username: {email}<br />"
                 + $"New password: {password}<br /><br />"
                 + "You can download the iOS version at:<br />"
                 + "https://itunes.apple.com/us/app/shed-smarter-living/id1279781718<br />"
                 + "You can download the Android version at:<br />"
                 + "https://play.google.com/store/apps/details?id=com.shedthat.app<br /><br />"
                 + "Looking forward to serve you.<br /><br />"
                 + "Best,<br /><br />"
                 + "Shed Team";
        }

        public static string GetPasswordChangedEmailBody(string email, DateTime date)
        {
            return "Hi,<br /><br />"
                 + "You have changed your password at " 
                 + $"{date.ToString("MMMM dd, yyyy hh:mm tt", CultureInfo.InvariantCulture)}<br /><br />"
                 + "Best,<br /><br />"
                 + "Shed Team";
        }

        public static string GetDeliveryRequestSubmittedEmailSubject(DeliveryRequestModel deliveryRequestModel)
        {
            return $"New delivery request - {deliveryRequestModel.UserFirstName} {deliveryRequestModel.UserLastName}, {deliveryRequestModel.UserEmail} - ID: {deliveryRequestModel.RequestNumber}";
        }

        public static string GetDeliveryRequestSubmittedEmailBody(DeliveryRequestModel deliveryRequestModel, string linkToAdminPanel)
        {

            return "You've got a new delivery request!<br /><br />"
                 + $"ID: {deliveryRequestModel.RequestNumber}<br /><br />"
                 + GetDeliveryRequestSubmittedNotes(deliveryRequestModel.Notes.Select(n => n.Note))
                 + $"{deliveryRequestModel.UserFirstName} {deliveryRequestModel.UserLastName} with email {deliveryRequestModel.UserEmail}" 
                 + " has requested the following collection(s)/item(s):<br /><br />"
                 + $"{GetDeliveryRequestSubmittedEmailCollectionAndItemsDetails(deliveryRequestModel)}"
                 + $"<a href=\"{linkToAdminPanel}\">Click here to view and process the request in the admin panel.</a>";
        }

        public static string GetDeliveryRequestCancelledEmailSubject(DeliveryRequestModel deliveryRequestModel)
        {
            return $"Cancelled delivery - {deliveryRequestModel.UserFirstName} {deliveryRequestModel.UserLastName}, {deliveryRequestModel.UserEmail} - ID: {deliveryRequestModel.RequestNumber}";
        }

        public static string GetDeliveryRequestCancelledEmailBody(DeliveryRequestModel deliveryRequestModel, string linkToAdminPanel)
        {
            return $"Delivery request with ID {deliveryRequestModel.RequestNumber} has been cancelled.<br /><br />"
                 + $"<a href=\"{linkToAdminPanel}\">Click here to view the request in the admin panel.</a>";
        }

        public static string GetNoteAddedToSubmittedDeliveryRequestSubject(DeliveryNoteSumbittedEmailModel model)
        {
            return $"New Note to delivery request - ID: {model.RequestNumber}";
        }

        public static string GetNoteAddedToSubmittedDeliveryRequestBody(DeliveryNoteSumbittedEmailModel model, string linkToAdminPanel)
        {
            return $"ID: {model.RequestNumber}<br /><br />"
                + $"{model.FirstName} {model.LastName} with email {model.Email} has added new note.<br />"
                + $"Note: {model.Note}<br /><br />"
                + $"<a href=\"{linkToAdminPanel}\">Click here to view and process the request in the admin panel.</a>";
        }

        private static string GetDeliveryRequestSubmittedEmailCollectionAndItemsDetails(DeliveryRequestModel deliveryRequestModel)
        {
            var details = new StringBuilder();

            foreach (var collection in deliveryRequestModel.Collections)
            {
                details.Append($"<b>{collection.CollectionName}</b>, {collection.Barcode}<br /><br />");

                foreach (var item in collection.Items)
                {
                    if (item.ChapterId.HasValue)
                    {
                        details.Append($"&nbsp; &nbsp; &nbsp; &nbsp; {item.ChapterName}, {item.ChapterBarcode}<br /><br />");
                    }
                    else
                    {
                        details.Append($"&nbsp; &nbsp; &nbsp; &nbsp; {item.ItemName}, {item.Barcode}<br /><br />");
                    }
                }
            }

            return details.ToString();
        }

        private static string GetDeliveryRequestSubmittedNotes(IEnumerable<string> notes)
        {
            return string.Join(string.Empty, notes.Select(n => $"Note: {n}<br /><br />"));
        }
    }
}
