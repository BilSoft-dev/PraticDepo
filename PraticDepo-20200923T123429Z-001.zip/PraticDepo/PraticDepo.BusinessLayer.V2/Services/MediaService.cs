﻿using PraticDepo.BusinessLayer.V2.Models.Media;
using PraticDepo.BusinessLayer.V2.Utils;
using System;
using System.Linq;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public class MediaService : BaseService, IMediaService
    {
        public bool IsMediaItemExist(Guid id)
        {
            return Storage.Media.GetById(id, true) != null;
        }

        public Media GetMedia(Guid mediaId)
        {
            try
            {
                var dalMedia = Storage.Media.GetById(mediaId, true);

                if (dalMedia != null)
                {
                    return new Media()
                    {
                        Id = dalMedia.Id,
                        FilePath = dalMedia.FileName,
                        Type = (MediaType)dalMedia.Type,
                        Duration = Math.Round(dalMedia.Duration, 2)
                    };
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }

            return null;
        }

        public Chapter GetChapter(Guid mediaId)
        {
            try
            {
                var dalChapter = Storage.VideoChapters.GetById(mediaId, true);

                if (dalChapter != null)
                {
                    return new Chapter()
                    {
                        Cover = dalChapter.Cover.FileName,
                        Id = dalChapter.Id,
                        Time = dalChapter.Time,
                        Name = dalChapter.Name,
                        Barcode = dalChapter.Barcode,
                        Volume = dalChapter.Volume
                    };
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }

            return null;
        }

        public bool IsMediaItemBelongsToUser(Guid mediaId, string userId)
        {
            try
            {
                var dalMedia = Storage.Media.GetById(mediaId, true);

                if (dalMedia?.ItemId.HasValue == true)
                {
                    if (dalMedia.ItemId.HasValue)
                    {
                        var item = Storage.Items.GetById(dalMedia.ItemId.Value, true);

                        return item.Collection.UserId == userId || item.Collection.Collaborators.Any(c => c.UserId == userId);
                    }
                }
                else
                {
                    var dalChapter = Storage.VideoChapters.GetById(mediaId, true);

                    if (dalChapter?.Video?.ItemId.HasValue == true)
                    {
                        var item = Storage.Items.GetById(dalChapter.Video.ItemId.Value, true);

                        return item.Collection.UserId == userId || item.Collection.Collaborators.Any(c => c.UserId == userId);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }

            return false;
        }
    }
}
