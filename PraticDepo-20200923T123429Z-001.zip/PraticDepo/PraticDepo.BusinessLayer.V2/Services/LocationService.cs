﻿using PraticDepo.BusinessLayer.V2.Integration.Permissions;
using PraticDepo.BusinessLayer.V2.Models.Locations;
using PraticDepo.BusinessLayer.V2.Utils;
using PraticDepo.DAL.Configs;
using System.Collections.Generic;
using System.Linq;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public class LocationService : BaseService, ILocationService
    {
        public List<Home> GetUserLocationsByEmail(string userEmail)
        {
            var user = Storage.Users.GetUserByEmail(userEmail).Result;

            if (user == null)
            {
                Logger.Instance.Error($"User was not found during action GetUserLocationsByEmail, user email [{userEmail}]");
                return new List<Home>();
            }

            var role = ShedRoleConfig.GetRoleByPriorityKey(user.Roles.Select(x => x.RoleId).ToList());

            if (role == ShedRoleConfig.SHEDUSER_ROLE)
            {
                return new List<Home> { MapTo(GetShedLocation()) };
            }

            return GetUserLocationsInternal(user, role);
        }

        public List<Home> GetUserLocationsById(string userId)
        {
            var user = Storage.Users.GetUser(u => u.Id.Equals(userId, System.StringComparison.OrdinalIgnoreCase));

            if (user == null)
            {
                Logger.Instance.Error($"User was not found during action GetUserLocationsById");
                return new List<Home>();
            }

            return Storage.Collections.GetBy(c => c.UserId == user.Id).GroupBy(x => x.HomeId)
                                      .ToList()
                                      .Select(x => MapTo(x.Key.ToString(), x.First()))
                                      .ToList();
        }

        private List<Home> GetUserLocationsInternal(DAL.Models.ApplicationUser user, string role)
        {
            var result = new List<Home>();
            var homes = Storage.Locations.GetBy(l => l.OwnerId == user.Id && l.ParentId == null).ToList();

            foreach (var home in homes)
            {
                
                var blHome = MapTo(home);
                var isCollaborator = IsLocationCollaborator(user.Id, role, blHome);

                blHome.Permissions = LocationLevel.GetLocationLevelMask(role, home.OwnerId == user.Id, isCollaborator, home.OwnerId == AdminConfig.Id);

                if (LocationLevel.CanChooseForCollection(blHome.Permissions))
                {
                    result.Add(blHome);
                }
            }

            return result;
        }

        private Home MapTo(string id, DAL.Models.Collection collection)
        {
            return new Home
            {
                Id = id,
                CreateAt = collection.Home.CreateAt,
                Name = collection.Home.Name,
                OwnerId = collection.Home.OwnerId,
                Latitude = collection.Home.Latitude,
                Longitude = collection.Home.Longitude,
                City = collection.Home.City,
                IsShedLocation = collection.Home.OwnerId == AdminConfig.Id
            };
        }

        private Home MapTo(DAL.Models.Location location)
        {
            return new Home
            {
                Id = location.Id.ToString(),
                CreateAt = location.CreateAt,
                Name = location.Name,
                OwnerId = location.OwnerId,
                Latitude = location.Latitude,
                Longitude = location.Longitude,
                City = location.City,
                IsShedLocation = location.OwnerId == AdminConfig.Id
            };
        }

        private bool IsLocationCollaborator(string userId, string role, Home home)
        {
            if (home.OwnerId == userId) return false;
            if (home.IsShedLocation && ShedRoleConfig.SHEDUSER_ROLE == role) return false;

            return Storage.Collections.GetBy(x => x.HomeId.ToString().ToLowerInvariant() == home.Id.ToLowerInvariant() && x.Collaborators.Any(c => c.UserId == userId)).Any();
        }

        private DAL.Models.Location GetShedLocation()
        {
            return Storage.Locations.GetBy(h => h.OwnerId == AdminConfig.Id && h.ParentId == null).First();
        }
    }
}
