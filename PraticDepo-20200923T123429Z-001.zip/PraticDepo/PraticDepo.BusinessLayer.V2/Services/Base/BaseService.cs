﻿using System;
using PraticDepo.BusinessLayer.V2.Utils;
using PraticDepo.DataLayer.Repo;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public abstract class BaseService : IDisposable
    {
        private readonly Storage _storage;

        protected BaseService()
        {
            _storage = _storage ?? DbInitializer.CreateStorage();
        }

        protected Storage Storage => _storage;

        public virtual void Dispose()
        {
            if (_storage != null)
            {
                _storage.Dispose();
            }
        }
    }
}