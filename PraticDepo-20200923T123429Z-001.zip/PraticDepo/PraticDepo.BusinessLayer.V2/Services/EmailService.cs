﻿using PraticDepo.BusinessLayer.V2.Models.Delivery;
using PraticDepo.BusinessLayer.V2.Utils;
using PraticDepo.BusinessLayer.V2.Utils.Providers.Emails;
using System;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public class EmailService : IEmailService
    {
        private readonly IEmailProvider _emailProvider;

        public EmailService(IEmailProvider emailProvider)
        {
            _emailProvider = emailProvider;
        }

        public void SendUserCreatedEmail(string email, string password)
        {
            try
            {
                _emailProvider.SendMail(email, EmailDataProvider.GetUserCreatedSubject, EmailDataProvider.GetUserCreatedEmailBody(email, password));
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }
        }

        public void SendUserResettedEmail(string email, string password)
        {
            try
            {
                _emailProvider.SendMail(email, EmailDataProvider.GetUserResetedSubject, EmailDataProvider.GetUserResettedEmailBody(email, password));
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }
        }

        public void SendPasswordChangedEmail(string email)
        {
            try
            {
                _emailProvider.SendMail(email, EmailDataProvider.GetPasswordChangedSubject, EmailDataProvider.GetPasswordChangedEmailBody(email, DateTime.Now));
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }
        }

        public void SendDeliveryRequestSubmittedEmail(IEnumerable<string> recipients, DeliveryRequestModel deliveryRequestModel, string linkToAdminPanel)
        {
            try
            {
                _emailProvider.SendMail(recipients, EmailDataProvider.GetDeliveryRequestSubmittedEmailSubject(deliveryRequestModel),
                                        EmailDataProvider.GetDeliveryRequestSubmittedEmailBody(deliveryRequestModel, linkToAdminPanel));
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }
        }

        public void SendDeliveryRequestCancelledEmail(IEnumerable<string> recipients, DeliveryRequestModel deliveryRequestModel, string linkToAdminPanel)
        {
            try
            {
                _emailProvider.SendMail(recipients, EmailDataProvider.GetDeliveryRequestCancelledEmailSubject(deliveryRequestModel),
                                        EmailDataProvider.GetDeliveryRequestCancelledEmailBody(deliveryRequestModel, linkToAdminPanel));
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }
        }

        public void SendNoteAddedToSubmittedDeliveryRequest(IEnumerable<string> recipients, DeliveryNoteSumbittedEmailModel model, string linkToAdminPanel)
        {
            try
            {
                _emailProvider.SendMail(recipients, EmailDataProvider.GetNoteAddedToSubmittedDeliveryRequestSubject(model),
                                        EmailDataProvider.GetNoteAddedToSubmittedDeliveryRequestBody(model, linkToAdminPanel));
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }
        }
    }
}
