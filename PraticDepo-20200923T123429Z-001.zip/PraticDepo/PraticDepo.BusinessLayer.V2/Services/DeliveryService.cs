﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using PraticDepo.BusinessLayer.V2.Utils;
using PraticDepo.BusinessLayer.V2.Models.Shared;
using PraticDepo.BusinessLayer.V2.Models.Delivery;
using PraticDepo.BusinessLayer.V2.Integration.Amazon;
using PraticDepo.BusinessLayer.V2.Integration.CSV;
using PraticDepo.DAL.Configs;
using PraticDepo.BusinessLayer.V2.Models.Media;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public class DeliveryService : BaseService, IDeliveryService
    {
        private const int REQUEST_NUMBER_START = 300001;

        private const int DR_NOT_SUBMITTED_STATUS = (int)Enums.DeliveryRequestStatus.NotSubmitted;
        private const int DR_SUBMITTED_STATUS = (int)Enums.DeliveryRequestStatus.Submitted;
        private const int DR_ON_DELIVERY_STATUS = (int)Enums.DeliveryRequestStatus.OnDelivery;

        private const int COLLECTION_NOT_SUBMITTED_STATUS = (int)Enums.DeliveryRequestCollectionStatus.NotSubmitted;
        private const int COLLECTION_DELIVERED_STATUS = (int)Enums.DeliveryRequestCollectionStatus.Returned;
        private const int COLLECTION_CANCELLED_STATUS = (int)Enums.DeliveryRequestCollectionStatus.Cancelled;

        private const int ITEM_CANCELLED_STATUS = (int)Enums.DeliveryRequestItemStatus.Cancelled;

        private const string DELIVERY_REQUEST_NOTIFICATION_TYPE = "action_delivery";
        private const string DELIVERY_REQUEST_DELIVERED_TEXT_PATTERN = "Your items from delivery request <b>{0}</b> have been returned to you";
        private const string DELIVERY_REQUEST_CANCELLED_TEXT_PATTERN = "Your delivery request <b>{0}</b> has been cancelled by an administrator";
        private const string DELIVERY_REQUEST_ONDELIVERY_TEXT_PATTERN = " Your items from delivery request <b>{0}</b> have been picked and are on the way to be delivered";

        public AddedRequestModel AddDeliveryRequest(string userId, Guid collectionId, Guid? itemId, Guid? chapterId)
        {
            using (var transaction = Storage.StartTransaction())
            {
                try
                {
                    #region Validation

                    var drCollection = Storage.DeliveryRequestCollections.GetSingleBy(x => x.CollectionId == collectionId && x.Status != COLLECTION_DELIVERED_STATUS && x.Status != COLLECTION_CANCELLED_STATUS);
                    if (drCollection != null
                        && ((drCollection.Status == COLLECTION_NOT_SUBMITTED_STATUS && drCollection.DeliveryRequest.UserId != userId)
                            || (drCollection.Status != COLLECTION_NOT_SUBMITTED_STATUS)))
                    {
                        if (itemId.HasValue)
                        {
                            var drItem = Storage.DeliveryRequestCollectionItems.GetSingleBy(x => x.DeliveryRequestCollectionId == drCollection.Id && x.ItemId == itemId && x.ChapterId == chapterId);
                            if (drItem != null) throw new Exception("The item has already been added to a delivery request by another user");
                        }
                        else
                        {
                            if (drCollection.DeliveryRequest.UserId == userId)
                            {
                                throw new Exception("Some of collection items are already requested or on delivery. Please select separate items you want to be delivered.");
                            }
                            else
                            {
                                throw new Exception("The collection or some of its items has already been added to a delivery request by another user");
                            }
                        }
                    }

                    #endregion

                    var requestId = Guid.Empty;
                    var requestNumber = string.Empty;
                    CreateOrUpdateDeliveryRequest(userId, out requestId, out requestNumber);

                    var deliveryRequestCollectionId = Guid.Empty;
                    CreateOrUpdatedDeliveryRequestCollection(userId, requestId, collectionId, out deliveryRequestCollectionId);

                    if (itemId.HasValue)
                    {
                        var deliveryRequestCollectionItem = Storage.DeliveryRequestCollectionItems.GetSingleBy(x => x.DeliveryRequestCollectionId == deliveryRequestCollectionId && x.ItemId == itemId && x.ChapterId == chapterId);
                        if (deliveryRequestCollectionItem == null)
                        {
                            Storage.DeliveryRequestCollectionItems.Add(new DAL.Models.DeliveryRequestCollectionItem
                            {
                                Id = Guid.NewGuid(),
                                DeliveryRequestCollectionId = deliveryRequestCollectionId,
                                ItemId = itemId.Value,
                                ChapterId = chapterId
                            });
                            UpdateItemStatus(itemId.Value, chapterId, Enums.DeliveryRequestItemStatus.NotSubmitted);
                            UpdateCollectionStatus(collectionId, Enums.DeliveryRequestCollectionStatus.NotSubmitted);
                        }
                        else
                        {
                            throw new Exception("The item has already been added to a delivery request by another user");
                        }
                    }
                    else
                    {
                        var drItems = GetCollectionItemsToRequest(collectionId, deliveryRequestCollectionId);
                        if (drItems.Any())
                        {
                            Storage.DeliveryRequestCollectionItems.AddRange(drItems);
                            UpdateCollectionStatus(collectionId, Enums.DeliveryRequestCollectionStatus.NotSubmitted);
                        }
                        else
                        {
                            var itemsCount = Storage.DeliveryRequestCollectionItems.GetBy(x => x.DeliveryRequestCollectionId == deliveryRequestCollectionId).Count();
                            if (itemsCount == 0)
                            {
                                Storage.DeliveryRequestCollections.Delete(deliveryRequestCollectionId);

                                var dr = Storage.DeliveryRequests.GetById(requestId);
                                if (dr.DeliveryRequestCollections == null || !dr.DeliveryRequestCollections.Any())
                                {
                                    Storage.DeliveryRequests.Delete(dr);
                                }
                            }
                        }
                    }

                    transaction.Commit();

                    return new AddedRequestModel
                    {
                        RequestId = requestId,
                        RequestNumber = requestNumber,
                        CollectionId = collectionId,
                        ItemId = itemId,
                        ChapterId = chapterId
                    };
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public void RemoveDeliveryRequestDetail(string userId, Guid collectionId, Guid? itemId, Guid? chapterId)
        {
            using (var transaction = Storage.StartTransaction())
            {
                try
                {
                    var deliveryRequestCollection = Storage.DeliveryRequestCollections.GetSingleBy(x => x.CollectionId == collectionId && x.DeliveryRequest.Status == DR_NOT_SUBMITTED_STATUS && x.DeliveryRequest.UserId == userId);
                    if (deliveryRequestCollection == null)
                    {
                        if (itemId.HasValue) throw new Exception("Cannot remove the item from a delivery request. The item is already requested or on delivery.");

                        throw new Exception("Cannot remove the collection from a delivery request. The collection is already requested or on delivery.");
                    }

                    var requestId = deliveryRequestCollection.DeliveryRequestId;
                    if (itemId.HasValue)
                    {
                        var deliveryRequestItem = deliveryRequestCollection.DeliveryRequestCollectionItems.FirstOrDefault(x => x.ItemId == itemId && x.ChapterId == chapterId);
                        if (deliveryRequestItem == null) throw new Exception($"Delivery Request Item with such ItemId: {itemId.Value} doesn't exist");

                        UpdateItemStatus(deliveryRequestItem.ItemId, deliveryRequestItem.ChapterId, null);
                        Storage.DeliveryRequestCollectionItems.Delete(deliveryRequestItem);
                    }
                    else
                    {
                        foreach (var deliveryRequestItem in deliveryRequestCollection.DeliveryRequestCollectionItems)
                        {
                            UpdateItemStatus(deliveryRequestItem.ItemId, deliveryRequestItem.ChapterId, null);
                        }

                        Storage.DeliveryRequestCollections.Delete(deliveryRequestCollection);
                    }

                    UpdateCollectionStatus(collectionId, null);

                    deliveryRequestCollection = Storage.DeliveryRequestCollections.GetSingleBy(x => x.CollectionId == collectionId && x.DeliveryRequest.Status == DR_NOT_SUBMITTED_STATUS && x.DeliveryRequest.UserId == userId);
                    if (deliveryRequestCollection != null && (deliveryRequestCollection.DeliveryRequestCollectionItems == null || !deliveryRequestCollection.DeliveryRequestCollectionItems.Any()))
                    {
                        Storage.DeliveryRequestCollections.Delete(deliveryRequestCollection);
                    }

                    var deliveryRequest = Storage.DeliveryRequests.GetById(requestId);
                    if (deliveryRequest != null && (deliveryRequest.DeliveryRequestCollections == null || !deliveryRequest.DeliveryRequestCollections.Any()))
                    {
                        RemoveDeliveryRequest(deliveryRequest);
                    }

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public void RemoveDeliveryRequest(Guid requestId, bool isAdministrationManagement = false)
        {
            using (var transaction = Storage.StartTransaction())
            {
                try
                {
                    var deliveryRequest = Storage.DeliveryRequests.GetById(requestId);
                    if (deliveryRequest == null) throw new Exception($"Delivery Request with such Id: {requestId} doesn't exist");

                    if (!isAdministrationManagement)
                    {
                        if (deliveryRequest.Status == (int)Enums.DeliveryRequestStatus.OnDelivery || deliveryRequest.Status == (int)Enums.DeliveryRequestStatus.Submitted)
                        {
                            throw new Exception("Cannot remove the collection from a delivery request. The collection is already requested or on delivery.");
                        }
                    }

                    foreach (var drCollection in deliveryRequest.DeliveryRequestCollections)
                    {
                        foreach (var drItem in drCollection.DeliveryRequestCollectionItems)
                        {
                            UpdateItemStatus(drItem.ItemId, drItem.ChapterId, null);
                        }

                        UpdateCollectionStatus(drCollection.CollectionId, null);
                    }

                    RemoveDeliveryRequest(deliveryRequest);
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public void SetStatusToDeliveryRequest(Guid requestId, Enums.DeliveryRequestStatus status, IEmailService emailService,
                                               bool isAdministrationManagement = false, bool shouldSendEmail = false, string linkToAdminPanel = "")
        {
            using (var transaction = Storage.StartTransaction())
            {
                try
                {
                    var deliveryRequest = Storage.DeliveryRequests.GetById(requestId);
                    if (deliveryRequest == null) throw new Exception($"Delivery Request with such Id: {requestId} doesn't exist");

                    if (status == Enums.DeliveryRequestStatus.Cancelled && !isAdministrationManagement && deliveryRequest.Status == DR_ON_DELIVERY_STATUS)
                    {
                        throw new Exception("Cannot cancel the delivery request. The requested items are already on delivery");
                    }

                    deliveryRequest.Status = (int)status;

                    if (status == Enums.DeliveryRequestStatus.Delivered)
                    {
                        deliveryRequest.DateDelivered = DateTime.Now;
                    }

                    Storage.DeliveryRequests.Update(deliveryRequest);

                    var collectionStatus = GetCollectionStatusByRequestStatus(status);
                    var itemStatus = GetItemStatusByRequestStatus(status);

                    if (shouldSendEmail && (status == Enums.DeliveryRequestStatus.Submitted || status == Enums.DeliveryRequestStatus.Cancelled))
                    {
                        SendDeliveryRequestEmail(status, deliveryRequest, emailService, GetAdminUserEmails(), linkToAdminPanel);
                    }

                    AddNotificationForDeliveryRequestStatusChange(deliveryRequest, status, deliveryRequest.UserId, isAdministrationManagement);

                    foreach (var drCollection in deliveryRequest.DeliveryRequestCollections)
                    {
                        drCollection.Status = (int)collectionStatus.Value;
                        Storage.DeliveryRequestCollections.Update(drCollection);

                        foreach (var drItem in drCollection.DeliveryRequestCollectionItems)
                        {
                            UpdateItemStatus(drItem.ItemId, drItem.ChapterId, itemStatus);
                        }

                        UpdateCollectionStatus(drCollection.CollectionId, collectionStatus);
                    }

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public void SetStatusToDeliveryRequestItem(Guid itemId, Enums.DeliveryRequestItemStatus status)
        {
            using (var transaction = Storage.StartTransaction())
            {
                try
                {
                    var deliveryRequestCollectionItem = Storage.DeliveryRequestCollectionItems.GetById(itemId);
                    if (deliveryRequestCollectionItem == null) throw new Exception($"Delivery request collection item with such Id: {itemId} doesn't exist");

                    var deliveryRequestCollectionId = deliveryRequestCollectionItem.DeliveryRequestCollectionId;

                    UpdateItemStatus(deliveryRequestCollectionItem.ItemId, deliveryRequestCollectionItem.ChapterId, status);

                    UpdateDeliveryRequestCollectionStatus(deliveryRequestCollectionItem.DeliveryRequestCollection);

                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        public DeliveryRequestCollectionModel GetDeliveryRequestCollectionForWebAPI(string userId, Guid collectionId)
        {
            var drCollection = Storage.DeliveryRequestCollections.GetSingleBy(x => x.CollectionId == collectionId
                                                                                && (x.DeliveryRequest.Status == DR_NOT_SUBMITTED_STATUS || x.DeliveryRequest.Status == DR_SUBMITTED_STATUS || x.DeliveryRequest.Status == DR_ON_DELIVERY_STATUS)
                                                                                && x.DeliveryRequest.UserId == userId);
            if (drCollection == null) return null;

            return new DeliveryRequestCollectionModel
            {
                DeliveryRequestId = drCollection.DeliveryRequestId,
                Status = GetDeliveryStatus(drCollection.Status)
            };
        }

        // TEMP SOLUTION (not good solutions) !!! To return status to Mobile Clients.
        public int GetDeliveryStatus(int dbStatus)
        {
            if (dbStatus == 3) return 2; // Delivered. Collection/item is delivered
            if (dbStatus == 4) return 3; // Cancelled. Collection/item request is cancelled
            if (dbStatus == 1) return 4; // Submitted. Collection/item is not picked
            if (dbStatus == 2) return 5; // On Delivery. Collection/item is picked

            return 1; // collection/item is added to a request
        }

        public List<DeliveryRequestModel> GetDeliveryRequests(string userId)
        {
            var result = new List<DeliveryRequestModel>();
            var requests = Storage.DeliveryRequests.GetBy(x => x.UserId == userId).OrderByDescending(x => x.DateCreated).ToList();

            foreach (var request in requests)
            {
                result.Add(new DeliveryRequestModel
                {
                    RequestId = request.Id,
                    RequestNumber = request.RequestNumber,
                    DateCreated = request.DateCreated,
                    DateDelivered = request.DateDelivered,
                    Status = request.Status,
                    ItemCounter = request.DeliveryRequestCollections.Sum(x => x.DeliveryRequestCollectionItems.Count())
                });
            }

            return result;
        }

        public DeliveryRequestModel GetDeliveryRequestById(Guid requestId, IAmazonS3Provider amazonS3Provider, string webClientUrl)
        {
            try
            {
                var dalDeliveryRequestResult = Storage.DeliveryRequests.GetSingleBy(x => x.Id == requestId);
                var deliveryRequestCollectionModels = new List<DeliveryRequestCollectionModel>();
                var requestCollection = Storage.DeliveryRequestCollections.GetBy(x => x.DeliveryRequestId == requestId).ToList();

                var result = MapToDeliveryRequest(dalDeliveryRequestResult, Storage.Users.GetById(dalDeliveryRequestResult.UserId) == null);

                foreach (var rc in requestCollection)
                {
                    var collection = new DeliveryRequestCollectionModel
                    {
                        CollectionId = rc.CollectionId,
                        CollectionName = rc.Collection.Name,
                        Status = rc.Status,
                        Items = new List<DeliveryRequestItemModel>(),
                        Barcode = rc.Collection.Barcode,
                        BinNumber = rc.Collection.BinNumber,
                        StorageLocation = rc.Collection.StorageLocation
                    };

                    if (rc.Collection.Photos.Any())
                    {
                        collection.ThumbnailUrl = amazonS3Provider.GetPreviewUrl(rc.Collection.Photos.First().FileName);
                        collection.WebClientAppUrl = $"{new Uri(webClientUrl)}CollectionPhoto/{rc.Collection.Photos.First().Id.ToString()}";
                    }

                    foreach (var item in rc.DeliveryRequestCollectionItems)
                    {
                        var model = new DeliveryRequestItemModel();
                        model.ItemId = item.Id;
                        model.ChapterId = item.ChapterId;
                        model.ItemName = item.Item.Name;
                        model.Barcode = item.Item.Barcode;
                        model.Status = item.Item.Status.HasValue ? item.Item.Status.Value : 0;
                        model.FileName = string.Empty;

                        var mediaId = string.Empty;

                        if (item.Item.Media != null && item.Item.Media.Any())
                        {
                            if (item.ChapterId.HasValue)
                            {
                                mediaId = item.ChapterId.Value.ToString("N");
                                var videoMedia = item.Item.Media.FirstOrDefault(m => m.Type == (int)DAL.Models.MediaType.VIDEO);
                                var chapter = videoMedia.VideoChapters.FirstOrDefault(x => x.Id == item.ChapterId.Value);
                                if (chapter != null)
                                {
                                    model.ItemName = chapter.Name;
                                    model.Barcode = chapter.Barcode;
                                    model.Status = chapter.Status.HasValue ? chapter.Status.Value : 0;
                                    if (chapter.Cover != null)
                                    {
                                        model.FileName = chapter.Cover.FileName;
                                    }
                                }
                            }
                            else
                            {
                                var media = item.Item.Media.FirstOrDefault();
                                if (media != null)
                                {
                                    mediaId = media.Id.ToString("N");
                                    model.FileName = media.FileName;
                                }
                            }
                        }

                        model.ThumbnailUrl = amazonS3Provider.GetPreviewUrl(model.FileName);
                        model.WebClientAppUrl = new Uri(new Uri(webClientUrl), mediaId).ToString();

                        collection.Items.Add(model);
                    }

                    deliveryRequestCollectionModels.Add(collection);
                }

                result.Collections = deliveryRequestCollectionModels;

                return result;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public List<DeliveryRequestCollectionModel> GetDeliveryRequestDetails(Guid requestId)
        {
            var result = new List<DeliveryRequestCollectionModel>();
            var requestCollections = Storage.DeliveryRequestCollections.GetBy(x => x.DeliveryRequestId == requestId).ToList();

            foreach (var rc in requestCollections)
            {
                var collection = new DeliveryRequestCollectionModel
                {
                    CollectionId = rc.CollectionId,
                    CollectionName = rc.Collection.Name,
                    Status = rc.Status,
                    Barcode = rc.Collection.Barcode,
                    ItemsTotal = (rc.Collection.Items == null) ? 0 : GetCollectionItemsCount(rc.Collection.Items),
                    Items = new List<DeliveryRequestItemModel>()
                };

                if (rc.Collection.Photos.Any())
                {
                    collection.PhotoFileName = rc.Collection.Photos.First().FileName;
                }

                foreach (var item in rc.DeliveryRequestCollectionItems)
                {
                    var model = new DeliveryRequestItemModel();
                    model.ItemId = item.ItemId;
                    model.ChapterId = item.ChapterId;
                    model.ItemName = string.Empty;
                    model.Barcode = string.Empty;
                    model.Status = 0;
                    model.FileName = string.Empty;

                    if (item.Item != null)
                    {
                        model.ItemName = item.Item.Name;
                        model.Barcode = item.Item.Barcode;
                        model.Status = item.Item.Status.HasValue ? item.Item.Status.Value : 0;

                        if (item.Item.Media != null && item.Item.Media.Any())
                        {
                            if (item.ChapterId.HasValue)
                            {
                                var videoMedia = item.Item.Media.FirstOrDefault(m => m.Type == (int)DAL.Models.MediaType.VIDEO);
                                var chapter = videoMedia.VideoChapters.FirstOrDefault(x => x.Id == item.ChapterId.Value);
                                if (chapter != null)
                                {
                                    model.ItemName = chapter.Name;
                                    model.Barcode = chapter.Barcode;
                                    model.Status = chapter.Status.HasValue ? chapter.Status.Value : 0;
                                    if (chapter.Cover != null) model.FileName = chapter.Cover.FileName;
                                }
                            }
                            else
                            {
                                var media = item.Item.Media.FirstOrDefault();
                                if (media != null) model.FileName = media.FileName;
                            }
                        }
                    }

                    collection.Items.Add(model);
                }

                result.Add(collection);
            }

            return result;
        }

        public EntitiesList<DeliveryRequestModel> GetDeliveryRequests(int number, int size, string sortingField, string pageSort, string filter)
        {
            try
            {
                var result = new EntitiesList<DeliveryRequestModel>();
                var query = Storage.DeliveryRequests.GetAll().Where(x => x.Status != DR_NOT_SUBMITTED_STATUS);

                result.Entities = GetQueryBySorting(query, number, size, sortingField, pageSort, filter, out int totalCount)
                                        .ToList()
                                        .Select(x => MapToDeliveryRequest(x, Storage.Users.GetById(x.UserId) == null))
                                        .ToList();

                result.TotalCount = totalCount;

                return result;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public List<DeliveryRequestNoteModel> GetDeliveryRequestNotes(Guid requestId)
        {
            var requestNotes = Storage.DeliveryRequestNotes.GetBy(x => x.DeliveryRequestId == requestId).OrderByDescending(x => x.DateModified).ToList();
            return requestNotes.Select(drn => new DeliveryRequestNoteModel(drn)).ToList();
        }

        public bool IsDeliveryRequestExists(Guid requestId)
        {
            return Storage.DeliveryRequests.GetById(requestId) != null;
        }

        public string GetRequestDataCSV(string requestId, string itemTemplateUrl, IRequestDataCSVGenerator reqestDataCSVGenerator, string dateFormat, IFormatProvider formatProvider)
        {
            try
            {
                var deliveryRequest = Storage.DeliveryRequests.GetById(Guid.Parse(requestId));

                if (deliveryRequest != null)
                {
                    var blDeliveryRequest = new DeliveryRequestModel(deliveryRequest);
                    return reqestDataCSVGenerator.GetStringifiedRequestDataCsv(blDeliveryRequest, itemTemplateUrl, dateFormat, formatProvider);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }

            return null;
        }

        public Guid AddDeliveryRequestNote(Guid requestId, string note, IEmailService emailService, string linkToAdminPanel)
        {
            var deliveryRequest = Storage.DeliveryRequests.GetById(requestId);

            if (deliveryRequest == null)
            {
                throw new Exception("Delivery request doesn't exist");
            }

            Enums.DeliveryRequestStatus requestStatus;

            Enum.TryParse(deliveryRequest.Status.ToString(), out requestStatus);

            switch (requestStatus)
            {
                case Enums.DeliveryRequestStatus.NotSubmitted:
                    var existingDeliveryRequestNote = Storage.DeliveryRequestNotes.GetBy(drn => drn.DeliveryRequestId == deliveryRequest.Id).FirstOrDefault();

                    if (existingDeliveryRequestNote != null)
                    {
                        throw new Exception("Request with not submitted stattus is not permitted to have more than 1 note");
                    }
                    break;
                case Enums.DeliveryRequestStatus.Submitted:

                    var emailModel = new DeliveryNoteSumbittedEmailModel
                    {
                        Email = deliveryRequest.UserEmail,
                        FirstName = deliveryRequest.UserFirstName,
                        LastName = deliveryRequest.UserLastName,
                        RequestNumber = deliveryRequest.RequestNumber,
                        Note = note
                    };

                    emailService.SendNoteAddedToSubmittedDeliveryRequest(GetAdminUserEmails(), emailModel, linkToAdminPanel);
                    break;
            }

            var dalDeliveryRequestNote = new DAL.Models.DeliveryRequestNote
            {
                Id = Guid.NewGuid(),
                Note = note,
                DateModified = DateTime.Now,
                DeliveryRequest = deliveryRequest,
                DeliveryRequestId = deliveryRequest.Id
            };

            var noteAddedId = Storage.DeliveryRequestNotes.Add(dalDeliveryRequestNote);

            return noteAddedId;
        }

        public void UpdateDeliveryRequestNote(Guid noteId, string note)
        {
            var deliveryRequestNote = Storage.DeliveryRequestNotes.GetById(noteId);

            if (deliveryRequestNote == null)
            {
                throw new Exception("Delivery request note doesn't exist");
            }

            if (deliveryRequestNote.DeliveryRequest.Status != (int)Enums.DeliveryRequestStatus.NotSubmitted)
            {
                throw new Exception("You cannot edit note in request which was submitted");
            }

            deliveryRequestNote.Note = note;
            deliveryRequestNote.DateModified = DateTime.Now;

            Storage.DeliveryRequestNotes.Update(deliveryRequestNote);
        }

        public void DeleteDeliveryRequestNote(Guid noteId)
        {
            var deliveryRequestNote = Storage.DeliveryRequestNotes.GetById(noteId);

            if (deliveryRequestNote == null)
            {
                throw new Exception("Delivery request note doesn't exist");
            }


            if (deliveryRequestNote.DeliveryRequest.Status != (int)Enums.DeliveryRequestStatus.NotSubmitted)
            {
                throw new Exception("You cannot delete note in request which was submitted");
            }

            Storage.DeliveryRequestNotes.Delete(deliveryRequestNote);
        }

        public void UpdateDeliveryRequestAdminNote(Guid requestId, string note)
        {
            try
            {
                var deliveryRequest = Storage.DeliveryRequests.GetById(requestId);

                if (deliveryRequest == null)
                {
                    throw new Exception("Delivery request doesn't exist");
                }

                deliveryRequest.AdminNote = note;

                Storage.DeliveryRequests.Update(deliveryRequest);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        #region Auxiliary methods

        private void CreateOrUpdateDeliveryRequest(string userId, out Guid requestId, out string requestNumber)
        {
            var deliveryRequest = Storage.DeliveryRequests.GetSingleBy(x => x.UserId == userId && x.Status == DR_NOT_SUBMITTED_STATUS);

            if (deliveryRequest == null)
            {
                var lastDR = Storage.DeliveryRequests.GetAll().OrderByDescending(x => x.DateCreated).FirstOrDefault();
                if (lastDR == null)
                {
                    requestNumber = REQUEST_NUMBER_START.ToString();
                }
                else
                {
                    var lastRequestNumber = Int32.Parse(lastDR.RequestNumber);
                    requestNumber = (lastRequestNumber + 1).ToString();
                }

                var dr = new DAL.Models.DeliveryRequest
                {
                    Id = Guid.NewGuid(),
                    RequestNumber = requestNumber,
                    Status = (int)Enums.DeliveryRequestStatus.NotSubmitted,
                    UserId = userId,
                    DateCreated = DateTime.Now
                };

                var user = Storage.Users.GetById(userId);
                if (user != null)
                {
                    dr.UserFirstName = user.FirstName;
                    dr.UserLastName = user.LastName;
                    dr.UserEmail = user.Email;
                    dr.UserPhoneNumber = user.PhoneNumber;
                }

                requestId = Storage.DeliveryRequests.Add(dr);
            }
            else
            {
                Storage.DeliveryRequests.Update(deliveryRequest);

                requestId = deliveryRequest.Id;
                requestNumber = deliveryRequest.RequestNumber;
            }
        }

        private void CreateOrUpdatedDeliveryRequestCollection(string userId, Guid requestId, Guid collectionId, out Guid deliveryRequestCollectionId)
        {
            var deliveryRequestCollection = Storage.DeliveryRequestCollections.GetSingleBy(x => x.DeliveryRequestId == requestId && x.CollectionId == collectionId);

            if (deliveryRequestCollection == null)
            {
                deliveryRequestCollectionId = Storage.DeliveryRequestCollections.Add(new DAL.Models.DeliveryRequestCollection
                {
                    Id = Guid.NewGuid(),
                    DeliveryRequestId = requestId,
                    CollectionId = collectionId,
                    Status = (int)Enums.DeliveryRequestCollectionStatus.NotSubmitted
                });
            }
            else
            {
                deliveryRequestCollectionId = deliveryRequestCollection.Id;
            }
        }

        private List<DAL.Models.DeliveryRequestCollectionItem> GetCollectionItemsToRequest(Guid collectionId, Guid deliveryRequestCollectionId)
        {
            var drItems = new List<DAL.Models.DeliveryRequestCollectionItem>();
            var items = Storage.Items.GetBy(x => x.CollectionId == collectionId).ToList();
            foreach (var item in items)
            {
                if (!item.Status.HasValue || (item.Status.HasValue && item.Status.Value == ITEM_CANCELLED_STATUS))
                {
                    if (item.Media != null && item.Media.Any())
                    {
                        if (item.Media.Any(m => m.Type == (int)DAL.Models.MediaType.VIDEO)) // This is a video item
                        {
                            var videoMedia = item.Media.FirstOrDefault(m => m.Type == (int)DAL.Models.MediaType.VIDEO); // This is the video itself
                            if (videoMedia != null && videoMedia.VideoChapters != null && videoMedia.VideoChapters.Any())
                            {
                                foreach (var chapter in videoMedia.VideoChapters)
                                {
                                    drItems.Add(new DAL.Models.DeliveryRequestCollectionItem
                                    {
                                        Id = Guid.NewGuid(),
                                        DeliveryRequestCollectionId = deliveryRequestCollectionId,
                                        ItemId = item.Id,
                                        ChapterId = chapter.Id
                                    });
                                    UpdateItemStatus(item.Id, chapter.Id, Enums.DeliveryRequestItemStatus.NotSubmitted);
                                }
                            }
                        }
                        else
                        {
                            drItems.Add(new DAL.Models.DeliveryRequestCollectionItem
                            {
                                Id = Guid.NewGuid(),
                                DeliveryRequestCollectionId = deliveryRequestCollectionId,
                                ItemId = item.Id,
                                ChapterId = null
                            });
                            UpdateItemStatus(item.Id, null, Enums.DeliveryRequestItemStatus.NotSubmitted);
                        }
                    }
                }
            }

            return drItems;
        }

        private void UpdateCollectionStatus(Guid collectionId, Enums.DeliveryRequestCollectionStatus? status)
        {
            var collection = Storage.Collections.GetById(collectionId);
            if (collection == null) throw new Exception($"Collection with such Id:{collectionId} doesn't exist.");

            if (status.HasValue)
            {
                var statusInt = (int?)status;
                if (collection.Items.All(x => x.Status == statusInt))
                {
                    collection.Status = statusInt;
                }
            }
            else
            {
                collection.Status = (int?)status;
            }

            Storage.Collections.Update(collection);
        }

        private void AddNotificationForDeliveryRequestStatusChange(DAL.Models.DeliveryRequest deliveryRequest, Enums.DeliveryRequestStatus status,
                                                                   string userId, bool isAdministrationManagement)
        {
            switch (status)
            {
                case Enums.DeliveryRequestStatus.OnDelivery:
                    {
                        AddDeliveryRequestNotification(string.Format(DELIVERY_REQUEST_ONDELIVERY_TEXT_PATTERN, deliveryRequest.RequestNumber), userId, deliveryRequest.Id);
                    }
                    break;
                case Enums.DeliveryRequestStatus.Cancelled:
                    if (isAdministrationManagement)
                    {
                        AddDeliveryRequestNotification(string.Format(DELIVERY_REQUEST_CANCELLED_TEXT_PATTERN, deliveryRequest.RequestNumber), userId, deliveryRequest.Id);
                    }
                    break;
                case Enums.DeliveryRequestStatus.Delivered:
                    AddDeliveryRequestNotification(string.Format(DELIVERY_REQUEST_DELIVERED_TEXT_PATTERN, deliveryRequest.RequestNumber), userId, deliveryRequest.Id);
                    break;
            }
        }

        private void UpdateItemStatus(Guid itemId, Guid? chapterId, Enums.DeliveryRequestItemStatus? status)
        {
            var item = Storage.Items.GetById(itemId);
            if (item == null) throw new Exception($"Item with such Id:{itemId} doesn't exist.");

            if (chapterId.HasValue)
            {
                var chapter = Storage.VideoChapters.GetById(chapterId.Value);
                if (chapter == null) throw new Exception($"Item with such Id:{chapterId.Value} doesn't exist.");

                chapter.Status = (int?)status;
                Storage.VideoChapters.Update(chapter);

                var chapters = Storage.VideoChapters.GetBy(x => x.Video != null && x.Video.ItemId == itemId).ToList();
                if (chapters.All(x => x.Status == (int?)status))
                {
                    item.Status = (int?)status;
                    Storage.Items.Update(item);
                }
            }
            else
            {
                item.Status = (int?)status;
                Storage.Items.Update(item);
            }
        }

        private Enums.DeliveryRequestCollectionStatus? GetCollectionStatusByRequestStatus(Enums.DeliveryRequestStatus status)
        {
            switch (status)
            {
                case Enums.DeliveryRequestStatus.Submitted: return Enums.DeliveryRequestCollectionStatus.NotPicked;
                case Enums.DeliveryRequestStatus.OnDelivery: return Enums.DeliveryRequestCollectionStatus.Picked;
                case Enums.DeliveryRequestStatus.Cancelled: return Enums.DeliveryRequestCollectionStatus.Cancelled;
                case Enums.DeliveryRequestStatus.Delivered: return Enums.DeliveryRequestCollectionStatus.Returned;
                default: return null;
            }
        }

        private Enums.DeliveryRequestItemStatus? GetItemStatusByRequestStatus(Enums.DeliveryRequestStatus status)
        {
            switch (status)
            {
                case Enums.DeliveryRequestStatus.Submitted: return Enums.DeliveryRequestItemStatus.NotPicked;
                case Enums.DeliveryRequestStatus.OnDelivery: return Enums.DeliveryRequestItemStatus.Picked;
                case Enums.DeliveryRequestStatus.Cancelled: return Enums.DeliveryRequestItemStatus.Cancelled;
                case Enums.DeliveryRequestStatus.Delivered: return Enums.DeliveryRequestItemStatus.Returned;
                default: return null;
            }
        }

        private int GetCollectionItemsCount(ICollection<DAL.Models.Item> items)
        {
            var count = 0;
            foreach (var item in items)
            {
                if (item.Media.Any(m => m.Type == (int)MediaType.Video && m.VideoChapters.Any()))
                {
                    count += item.Media.Where(m => m.VideoChapters.Any()).Sum(m => m.VideoChapters.Count);
                }
                else
                {
                    count++;
                }
            }

            return count;
        }

        private void UpdateDeliveryRequestCollectionStatus(DAL.Models.DeliveryRequestCollection collectionToUpdate)
        {
            var deliveryRequestCollectionItems = Storage.DeliveryRequestCollectionItems.GetBy(drci => drci.DeliveryRequestCollectionId == collectionToUpdate.Id).ToList();

            if (deliveryRequestCollectionItems.All(i => IsItemStatusExpected(i.Item, i.ChapterId, (int)Enums.DeliveryRequestItemStatus.Picked)))
            {
                collectionToUpdate.Status = (int)Enums.DeliveryRequestCollectionStatus.Picked;
                Storage.DeliveryRequestCollections.Update(collectionToUpdate);
            }

            if (deliveryRequestCollectionItems.Any(i => IsItemStatusExpected(i.Item, i.ChapterId, (int)Enums.DeliveryRequestItemStatus.NotPicked)))
            {
                collectionToUpdate.Status = (int)Enums.DeliveryRequestCollectionStatus.NotPicked;
                Storage.DeliveryRequestCollections.Update(collectionToUpdate);
            }
        }

        private bool IsItemStatusExpected(DAL.Models.Item item, Guid? chapterId, int status)
        {
            if (chapterId.HasValue)
            {
                var chapter = Storage.VideoChapters.GetById(chapterId.Value);
                if (chapter == null) throw new Exception($"Item with such Id:{chapterId.Value} doesn't exist.");

                return chapter.Status == status;
            }
            else
            {
                return item.Status == status;
            }
        }

        private void AddDeliveryRequestNotification(string notificationText, string userId, Guid? requestId)
        {
            Storage.Notifications.Add(new DAL.Models.Notification
            {
                Id = Guid.NewGuid(),
                CreateAt = DateTime.Now,
                NotificationType = DELIVERY_REQUEST_NOTIFICATION_TYPE,
                Text = notificationText,
                UserId = userId,
                RequestId = requestId
            });
        }

        private void RemoveDeliveryRequest(DAL.Models.DeliveryRequest deliveryRequest)
        {
            var notifications = Storage.Notifications.GetBy(x => x.RequestId == deliveryRequest.Id).ToList();
            if (notifications != null && notifications.Any())
            {
                Storage.Notifications.DeleteRange(notifications);
            }

            Storage.DeliveryRequests.Delete(deliveryRequest);
        }

        private IQueryable<DAL.Models.DeliveryRequest> GetQueryBySorting(IQueryable<DAL.Models.DeliveryRequest> query, int number, int size, string sortingField, string sortOrder, string filter, out int totalCount)
        {
            var isPreciseSearch = TryGetFirstLastNameSearch(filter, out Expression<Func<DAL.Models.DeliveryRequest, bool>> preciseSearchFilter);

            var resultFilteringExpression = isPreciseSearch ? preciseSearchFilter : GetDeliveryRequestsFilteringPredicate(filter);

            totalCount = query.Where(resultFilteringExpression).Count();

            var initialQuery = query.Where(resultFilteringExpression);

            return OrderQuery(initialQuery, sortOrder)
                                .Skip(number * size)
                                .Take(size);
        }

        private bool TryGetFirstLastNameSearch(string filter, out Expression<Func<DAL.Models.DeliveryRequest, bool>> userFilteringPredicate)
        {
            try
            {
                var firstAndLastname = filter.Split(' ');

                if (firstAndLastname.Length == 2) //filter is only first and last name and not some abrakadabra
                {
                    var firstName = firstAndLastname[0];
                    var lastName = firstAndLastname[1];

                    userFilteringPredicate = dr => (!string.IsNullOrEmpty(dr.UserFirstName) && dr.UserFirstName.ToLower().Equals(firstName.ToLower(), StringComparison.OrdinalIgnoreCase)) &&
                                                   (!string.IsNullOrEmpty(dr.UserLastName) && dr.UserLastName.ToLower().Equals(lastName.ToLower(), StringComparison.OrdinalIgnoreCase));

                    return true;
                }
            }
            catch (Exception)
            {
            }

            userFilteringPredicate = null;
            return false;
        }

        private IOrderedQueryable<DAL.Models.DeliveryRequest> OrderQuery(IQueryable<DAL.Models.DeliveryRequest> query, string sortOrder)
        {
            if (string.Equals(sortOrder, "asc", StringComparison.InvariantCultureIgnoreCase))
            {
                return query.OrderBy(dr => dr.DateCreated);
            }
            else
            {
                return query.OrderByDescending(dr => dr.DateCreated);
            }
        }

        private Expression<Func<DAL.Models.DeliveryRequest, bool>> GetDeliveryRequestsFilteringPredicate(string filter)
        {
            return dr => (filter.Equals(string.Empty, StringComparison.InvariantCulture))
                      || (dr.Id != null && dr.Id.ToString().ToLower().Contains(filter.ToLower()))
                      || (dr.RequestNumber != null && dr.RequestNumber.ToLower().Contains(filter.ToLower()))
                      || (dr.UserId != null && dr.UserId.ToLower().Contains(filter.ToLower()))
                      || (dr.UserEmail != null && dr.UserEmail.ToLower().Contains(filter.ToLower()))
                      || (dr.AdminNote != null && dr.AdminNote.ToLower().Contains(filter.ToLower()))
                      || (dr.DeliveryRequestNotes.Where(drn => drn.Note.ToLower().Contains(filter.ToLower())).Count() > 0)
                      || (dr.DeliveryRequestCollections.Any(drc => drc.Collection.BinNumber.ToLower().Contains(filter.ToLower()) || drc.Collection.BinNumber.ToLower().StartsWith(filter.ToLower())))
                      || (dr.DeliveryRequestCollections.Any(drc => drc.Collection.StorageLocation.ToLower().Contains(filter.ToLower())))
                      || (dr.DeliveryRequestCollections.Any(drc => (drc.Collection.BinNumber.ToLower() + drc.Collection.StorageLocation.ToLower()).Contains(filter.ToLower())));
        }

        private DeliveryRequestModel MapToDeliveryRequest(DAL.Models.DeliveryRequest dalDeliveryRequest, bool isUserDeleted)
        {
            return new DeliveryRequestModel()
            {
                DateCreated = dalDeliveryRequest.DateCreated,
                DateDelivered = dalDeliveryRequest.DateDelivered,
                UserEmail = dalDeliveryRequest.UserEmail,
                RequestId = dalDeliveryRequest.Id,
                Status = dalDeliveryRequest.Status,
                UserFirstName = dalDeliveryRequest.UserFirstName,
                UserId = Guid.Parse(dalDeliveryRequest.UserId),
                UserLastName = dalDeliveryRequest.UserLastName,
                StatusName = Enum.Parse(typeof(Enums.DeliveryRequestStatus), dalDeliveryRequest.Status.ToString()).ToString(),
                IsUserDeleted = isUserDeleted,
                RequestNumber = dalDeliveryRequest.RequestNumber,
                UserPhoneNumber = dalDeliveryRequest.UserPhoneNumber,
                AdminNote = dalDeliveryRequest.AdminNote,
                Notes = new List<DeliveryRequestNoteModel>(dalDeliveryRequest.DeliveryRequestNotes.Select(drn => new DeliveryRequestNoteModel(drn)))
            };
        }

        private void SendDeliveryRequestEmail(Enums.DeliveryRequestStatus status, DAL.Models.DeliveryRequest deliveryRequest, IEmailService emailService, IEnumerable<string> deliveryRequestEmailRecipients, string linkToAdminPanel)
        {
            var blDeliveryRequest = new DeliveryRequestModel(deliveryRequest);
            blDeliveryRequest.Collections.ForEach(c => InitializeChapterInfoForDeliveryRequestItems(c.Items));

            switch (status)
            {
                case Enums.DeliveryRequestStatus.Submitted:
                    emailService.SendDeliveryRequestSubmittedEmail(deliveryRequestEmailRecipients, blDeliveryRequest, linkToAdminPanel);
                    break;
                case Enums.DeliveryRequestStatus.Cancelled:
                    emailService.SendDeliveryRequestCancelledEmail(deliveryRequestEmailRecipients, blDeliveryRequest, linkToAdminPanel);
                    break;
            }
        }

        private void InitializeChapterInfoForDeliveryRequestItems(List<DeliveryRequestItemModel> itemsModel)
        {
            foreach (var item in itemsModel)
            {
                if (item.ChapterId.HasValue)
                {
                    var videoMedia = Storage.Items.GetById(item.ItemId)?.Media?.FirstOrDefault(m => m.Type == (int)DAL.Models.MediaType.VIDEO);
                    var chapter = videoMedia?.VideoChapters.FirstOrDefault(x => x.Id == item.ChapterId.Value);

                    if (chapter != null)
                    {
                        item.ChapterName = chapter.Name;
                        item.ChapterBarcode = chapter.Barcode;
                    }
                }
            }
        }

        private IEnumerable<string> GetAdminUserEmails()
        {
            var adminRoleDBId = ShedRoleConfig.GetRoleInfo(ShedRoleConfig.ADMIN_ROLE).DbId;
            var adminUsers = Storage.Users.GetUsersByRole(adminRoleDBId);

            return adminUsers.Select(u => u.Email);
        }

        #endregion
    }
}