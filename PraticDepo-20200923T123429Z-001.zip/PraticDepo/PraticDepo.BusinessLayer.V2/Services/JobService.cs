﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using PraticDepo.BusinessLayer.V2.Enums;
using PraticDepo.BusinessLayer.V2.Enums.JobManagement;
using PraticDepo.BusinessLayer.V2.Models.Jobs;
using PraticDepo.BusinessLayer.V2.Models.Shared;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public class JobService : BaseService, IJobService
    {
        private const string JOB_STARTED_NOTIFICATION_TYPE = "action_jobstarted";
        private const string JOB_STARTED_NOTIFICATION_TEXT_TEMPLATE = "One of your team members started a job for client {0}.";

        private const string JOB_FINISHED_NOTIFICATION_TYPE = "action_jobfinished";
        private const string JOB_FINISHED_NOTIFICATION_TEXT_TEMPLATE = "Your pickup request has been completed. You can now view your collections and items on the Collections screen.";

        public EntitiesList<Job> GetJobs(int number, int size, int jobPeriod, string userId)
        {
            var result = new EntitiesList<Job>();
            var itemsQuery = Storage.UserJobs.GetAll();

            #region Temp fill logic

            if (!Storage.UserJobs.GetBy(uj => uj.UserId == userId).ToList().Any(uj => uj.Status == (int)JobStatus.NotStarted))
            {
                FillTempUserJobs(userId);
            }

            #endregion

            if (!Enum.TryParse(jobPeriod.ToString(), out JobPeriod jobPeriodEnumValue))
            {
                jobPeriodEnumValue = JobPeriod.TodayAndFuture;
            }

            result.Entities = GetQueryBySorting(itemsQuery, number, size, jobPeriodEnumValue, userId, out int totalCount)
                                    .ToList()
                                    .Select(x => MapToJob(x))
                                    .ToList();

            result.TotalCount = totalCount;

            if (jobPeriodEnumValue == JobPeriod.Past)
            {
                result.Entities = result.Entities.Where(x => x.JobStatus == JobStatus.Finished).ToList();
                var firstPastJob = result.Entities.FirstOrDefault();
                if (firstPastJob != null)
                {
                    result.Entities = result.Entities.Where(x => x.DatePackingEstimatedStart.Date == firstPastJob.DatePackingEstimatedStart.Date).ToList();
                }
            }

            return result;
        }

        public void StartJob(string userId, Guid jobId, JobStatus jobStatus, ResponsibilityType responsibilityType)
        {
            var dalUserJob = Storage.UserJobs.GetBy(uj => uj.UserId == userId && uj.JobId == jobId).FirstOrDefault();
            if (dalUserJob == null) throw new Exception($"Job with such Id: {jobId} and responsibility type: {responsibilityType.ToString()} doesn't exist");

            var user = Storage.Users.GetById(userId);
            if (user == null) throw new Exception($"User with such id: {userId} doesn't exist");

            SetStatusToJob(userId, dalUserJob, jobStatus, responsibilityType);
            AddJobClientToCollaborators(dalUserJob, user);

            var currentUserCollaborator = Storage.Collaborators.GetOrCreateCollaborator(user);

            AddUserToCollaborators(dalUserJob, user, currentUserCollaborator);
            ShareJobCollectionsWithUser(dalUserJob.JobId, currentUserCollaborator.Id);
        }

        public void FinishJob(string userId, Guid jobId, JobStatus jobStatus)
        {
            var dalUserJob = Storage.UserJobs.GetBy(j => j.UserId == userId && j.JobId == jobId).FirstOrDefault();
            if (dalUserJob == null) throw new Exception($"Job with such Id: {jobId} doesn't exist");

            var allUserJobs = dalUserJob.Job.UserJobs.Where(x => x.UserId != userId).ToList();
            if (!allUserJobs.Any() || allUserJobs.All(x => x.Status == (int) JobStatus.Finished))
            {
                var collectionIds = Storage.JobCollections.GetBy(jc => jc.JobId == jobId, true).Select(jc => jc.CollectionId).ToList();
                foreach (var collecitonId in collectionIds)
                {
                    var id = Guid.Parse(collecitonId);
                    var dbCollection = Storage.Collections.GetSingleBy(x => x.Id == id, true);

                    if (dbCollection != null)
                    {
                        if ((!string.IsNullOrEmpty(dbCollection.Barcode) && !(dbCollection.IsLoaded.HasValue && dbCollection.IsLoaded.Value))
                         || (dbCollection.Items != null && dbCollection.Items.Where(x => x.Barcode != null).Any(x => !(x.IsLoaded.HasValue && x.IsLoaded.Value))))
                        {
                            throw new Exception($"There are items that have not been loaded yet. Please make sure that all items are loaded.");
                        }
                    }
                }
            }

            SetStatusToJob(userId, dalUserJob, jobStatus);
        }

        public bool HasJobStarted(string userId)
        {
            var startedUserJob = Storage.UserJobs.GetBy(j => j.UserId == userId && j.Status == (int)JobStatus.InProgress).FirstOrDefault();

            if (startedUserJob == null) return false;
            return true;
        }

        public bool IsActionEnabledForCollection(Guid collectionId)
        {
            var collectionRelatedJobIds = Storage.JobCollections.GetBy(jc => jc.CollectionId == collectionId.ToString()).Select(jc => jc.JobId).ToList();

            if (collectionRelatedJobIds == null || !collectionRelatedJobIds.Any())
            {
                return false;
            }

            var collectionRelatedJobs = Storage.Jobs.GetBy(j => collectionRelatedJobIds.Contains(j.Id)).ToList();

            if (collectionRelatedJobs.Any(j => j.Status == (int)JobStatus.Finished))
            {
                return false;
            }

            return true;
        }

        public bool IsActionEnabledForItem(Guid itemId)
        {
            var dbItem = Storage.Items.GetById(itemId);

            if (dbItem == null)
            {
                throw new Exception("The item no longer exists.");
            }

            return IsActionEnabledForCollection(dbItem.CollectionId);
        }

        private void AddJobClientToCollaborators(DAL.Models.UserJob dalUserJob, DAL.Models.ApplicationUser user)
        {
            var client = Storage.Users.GetUser(u => u.Email == dalUserJob.Job.ClientEmail);

            if (client != null)
            {
                var collaborator = Storage.Collaborators.GetSingleBy(c => c.UserId == client.Id);
                if (collaborator == null)
                {
                    var collaboratorId = Storage.Collaborators.Add(new DAL.Models.Collaborator
                    {
                        Id = Guid.NewGuid(),
                        UserId = client.Id,
                        Email = dalUserJob.Job.ClientEmail,
                        Name = string.Format("{0} {1}", dalUserJob.Job.ClientFirstName, dalUserJob.Job.ClientLastName).Trim()
                    });

                    Storage.SaveChanges();

                    Storage.Collaborators.AttachCollaboratorsToTargetUser(new List<Guid> { collaboratorId }, user.Id);
                }
                else
                {
                    if (!user.CreatedCollaborators.Any(uc => uc.Id == collaborator.Id))
                    {
                        Storage.Collaborators.AttachCollaboratorsToTargetUser(new List<Guid> { collaborator.Id }, user.Id);
                    }
                }
            }
        }

        private void AddUserToCollaborators(DAL.Models.UserJob dalUserJob, DAL.Models.ApplicationUser user, DAL.Models.Collaborator collaborator)
        {
            var jobRelatedUserIds = dalUserJob.Job.UserJobs.Where(uj => uj.UserId != user.Id).Select(uj => uj.UserId).Distinct().ToList();

            foreach (var id in jobRelatedUserIds)
            {
                var jobRelatedUser = Storage.Users.GetById(id);

                if (!jobRelatedUser.CreatedCollaborators.Any(uc => uc.Id == collaborator.Id))
                {
                    Storage.Collaborators.AttachCollaboratorsToTargetUser(new List<Guid> { collaborator.Id }, id);
                }
            }
        }

        private void ShareJobCollectionsWithUser(Guid jobId, Guid collaboratorId)
        {
            var collectionIds = Storage.JobCollections.GetBy(jc => jc.JobId == jobId).Select(jc => jc.CollectionId).ToList();

            foreach (var id in collectionIds)
            {
                var collection = Storage.Collections.GetById(Guid.Parse(id));

                if (collection != null && !collection.Collaborators.Any(x => x.Id == collaboratorId))
                {
                    Storage.Collaborators.AttachCollaboratorToCollection(collaboratorId.ToString(), collection.Id.ToString());
                }
            }
        }

        private void SetStatusToJob(string userId, DAL.Models.UserJob dalUserJob, JobStatus jobStatus, ResponsibilityType? responsibilityType = null)
        {
            using (var transaction = Storage.StartTransaction())
            {
                try
                {
                    var currentDate = DateTime.Now;

                    switch (jobStatus)
                    {
                        case JobStatus.InProgress:
                            {
                                if (!responsibilityType.HasValue)
                                {
                                    return;
                                }

                                var startedUserJob = Storage.UserJobs.GetBy(j => j.UserId == userId && j.Status == (int)JobStatus.InProgress).FirstOrDefault();

                                if (startedUserJob != null && responsibilityType == ResponsibilityType.PackingAndCataloging) throw new Exception("You can't start a new job while the current job is in progress.");

                                var allUserJobs = dalUserJob.Job.UserJobs;
                                var isJobRestarted = dalUserJob.Job.Status == (int)JobStatus.Finished;

                                foreach (var userJob in allUserJobs)
                                {
                                    if (isJobRestarted)
                                    {
                                        userJob.DateMovingActualStart = null;
                                        userJob.DatePackingActualStart = null;
                                        userJob.IsRestart = true;
                                    }

                                    switch (responsibilityType)
                                    {
                                        case ResponsibilityType.Moving:
                                            if (!userJob.DateMovingActualStart.HasValue)
                                            {
                                                userJob.DateMovingActualStart = currentDate;
                                            }
                                            break;
                                        case ResponsibilityType.PackingAndCataloging:
                                        default:
                                            if (!userJob.DatePackingActualStart.HasValue)
                                            {
                                                userJob.DatePackingActualStart = currentDate;
                                            }
                                            break;
                                    }
                                }

                                dalUserJob.Status = (int)JobStatus.InProgress;

                                if (dalUserJob.Job.Status != (int)JobStatus.InProgress)
                                {
                                    dalUserJob.Job.Status = (int)JobStatus.InProgress;

                                    foreach (var userJob in allUserJobs.Where(uj => uj.UserId != userId))
                                    {
                                        AddJobNotification(JOB_STARTED_NOTIFICATION_TYPE,
                                                           string.Format(JOB_STARTED_NOTIFICATION_TEXT_TEMPLATE, $"{dalUserJob.Job.ClientFirstName} {dalUserJob.Job.ClientLastName}"),
                                                           userJob.UserId);
                                    }
                                }
                            }
                            break;
                        case JobStatus.Finished:
                            {
                                var allUserJobs = dalUserJob.Job.UserJobs;

                                foreach (var userJob in allUserJobs)
                                {
                                    //userJob.DateMovingActualFinish = currentDate;
                                    //userJob.DatePackingActualFinish = currentDate;

                                    if (!userJob.DateMovingActualStart.HasValue)
                                    {
                                        userJob.DateMovingActualStart = currentDate;
                                    }
                                }

                                dalUserJob.Status = (int)JobStatus.Finished;
                                if (allUserJobs.All(uj => uj.Status == (int)JobStatus.Finished))
                                {
                                    dalUserJob.Job.Status = (int)JobStatus.Finished;
                                    var client = Storage.Users.GetUser(u => u.Email == dalUserJob.Job.ClientEmail);
                                    if (client != null && allUserJobs.All(uj => !uj.IsRestart))
                                    {
                                        AddJobNotification(JOB_FINISHED_NOTIFICATION_TYPE, JOB_FINISHED_NOTIFICATION_TEXT_TEMPLATE, client.Id);
                                    }
                                }
                            }
                            break;
                        case JobStatus.Cancelled:
                            {
                                dalUserJob.Status = (int)JobStatus.Cancelled;
                                dalUserJob.DateCancelled = currentDate;
                            }
                            break;
                        default: break;
                    }

                    Storage.UserJobs.Update(dalUserJob);
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        #region Auxiliary methods

        private IQueryable<DAL.Models.UserJob> GetQueryBySorting(IQueryable<DAL.Models.UserJob> query, int number, int size, JobPeriod jobPeriod, string userId, out int totalCount)
        {
            var resultFilteringExpression = GetJobFilteringPredicate(userId, jobPeriod);

            totalCount = query.Where(resultFilteringExpression).Count();

            var initialQuery = query.Where(resultFilteringExpression);

            return OrderQuery(initialQuery, jobPeriod)
                                .Skip(number * size)
                                .Take(size);
        }

        private Expression<Func<DAL.Models.UserJob, bool>> GetJobFilteringPredicate(string userId, JobPeriod jobPeriod)
        {
            switch (jobPeriod)
            {
                case JobPeriod.Past:
                    return j => j.UserId.Contains(userId) && DbFunctions.TruncateTime(j.DateMovingEstimatedStart) < DbFunctions.TruncateTime(DateTime.Now);

                case JobPeriod.TodayAndFuture:
                default:
                    return j => j.UserId.Contains(userId) && DbFunctions.TruncateTime(j.DateMovingEstimatedStart) >= DbFunctions.TruncateTime(DateTime.Now);
            }
        }

        private IOrderedQueryable<DAL.Models.UserJob> OrderQuery(IQueryable<DAL.Models.UserJob> query, JobPeriod jobPeriod)
        {
            switch (jobPeriod)
            {
                case JobPeriod.Past:
                    return query.OrderByDescending(i => DbFunctions.TruncateTime(i.DateMovingEstimatedStart));
                case JobPeriod.TodayAndFuture:
                default:
                    return query.OrderBy(i => DbFunctions.TruncateTime(i.DateMovingEstimatedStart));
            }
        }

        private Job MapToJob(DAL.Models.UserJob dalUserJob)
        {
            return new Job
            {
                JobId = dalUserJob.Job.Id,
                ClientEmail = dalUserJob.Job.ClientEmail,
                ClientFirstName = dalUserJob.Job.ClientFirstName,
                ClientId = dalUserJob.Job.ClientId,
                ClientLastName = dalUserJob.Job.ClientLastName,
                DateCancelled = dalUserJob.DateCancelled,
                DateCreated = dalUserJob.Job.DateCreated,
                Number = dalUserJob.Job.Number,
                JobStatus = (JobStatus)Enum.Parse(typeof(JobStatus), dalUserJob.Job.Status.ToString()),
                UserJobStatus = (JobStatus)Enum.Parse(typeof(JobStatus), dalUserJob.Status.ToString()),
                UserId = dalUserJob.UserId,
                DateMovingEstimatedStart = dalUserJob.DateMovingEstimatedStart,
                DateMovingEstimatedFinish = dalUserJob.DateMovingEstimatedFinish,
                DateMovingActualStart = dalUserJob.DateMovingActualStart,
                DateMovingActualFinish = dalUserJob.DateMovingActualFinish,
                DatePackingEstimatedStart = dalUserJob.DatePackingEstimatedStart,
                DatePackingEstimatedFinish = dalUserJob.DatePackingEstimatedFinish,
                DatePackingActualStart = dalUserJob.DatePackingActualStart,
                DatePackingActualFinish = dalUserJob.DatePackingActualFinish,
                ClientAddress = dalUserJob.Job.ClientAddress,
                Notes = dalUserJob.Job.Notes,
                ResponsibilityType = (ResponsibilityType)Enum.Parse(typeof(ResponsibilityType), dalUserJob.ResponsibilityType.ToString()),
                CollectionsCount = dalUserJob.Job.Collections.Count()
            };
        }

        #endregion

        #region Temp Auxillary Methods

        private void FillTempUserJobs(string userId)
        {
            for (int i = 0; i < 50; i++)
            {
                DAL.Models.Job dalJob = new DAL.Models.Job
                {
                    Id = Guid.NewGuid(),
                    Number = new Random().Next(1000, 999999),
                    DateCreated = DateTime.Now,
                    ClientId = "15fd7baa-29c4-405d-81fc-f157332a96f3",
                    ClientFirstName = "BobJob",
                    ClientLastName = "TestJob",
                    ClientEmail = "bob.test.job@gmail.com",
                    ClientAddress = "0205 Jewess Burg Apt. 770",
                    Notes = "test note",
                    Status = (int)JobStatus.NotStarted
                };

                Storage.Jobs.Add(dalJob);

                DAL.Models.UserJob dalUserJob = new DAL.Models.UserJob
                {
                    Id = Guid.NewGuid(),
                    Status = (int)JobStatus.NotStarted,
                    DatePackingEstimatedStart = DateTime.Now.AddDays(i % 2 == 0 ? i : -i),
                    DatePackingEstimatedFinish = DateTime.Now.AddDays(i % 2 == 0 ? i : -i).AddHours(i % 2 == 0 ? 2 : -2),
                    DateMovingEstimatedStart = DateTime.Now.AddDays(i % 2 == 0 ? i : -i),
                    DateMovingEstimatedFinish = DateTime.Now.AddDays(i % 2 == 0 ? i : -i).AddHours(i % 2 == 0 ? 3 : -3),
                    UserId = userId,
                    JobId = dalJob.Id,
                    ResponsibilityType = i % 2 == 0 ? (int)ResponsibilityType.Moving : (int)ResponsibilityType.PackingAndCataloging
                };

                Storage.UserJobs.Add(dalUserJob);

                Storage.SaveChanges();
            }
        }

        #endregion

        private void AddJobNotification(string notificationType, string notificationText, string userId)
        {
            Storage.Notifications.Add(new DAL.Models.Notification
            {
                Id = Guid.NewGuid(),
                CreateAt = DateTime.Now,
                NotificationType = notificationType,
                Text = notificationText,
                UserId = userId
            });
        }
    }
}
