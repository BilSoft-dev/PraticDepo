﻿using System;
using System.Collections.Generic;
using System.Linq;
using PraticDepo.BusinessLayer.V2.Utils;
using PraticDepo.DAL.Configs;
using PraticDepo.DAL.Models;
using PraticDepo.BusinessLayer.V2.Integration.Amazon;
using PraticDepo.BusinessLayer.V2.Integration.CSV;
using PraticDepo.BusinessLayer.V2.Models.Users;
using PraticDepo.BusinessLayer.V2.Models.Shared;
using PraticDepo.BusinessLayer.V2.Utils.Providers.Emails;
using System.Linq.Expressions;
using PraticDepo.Common.V2.Helpers;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public class UserService : BaseService, IUserService
    {
        #region Fields

        private readonly IEmailProvider _emailProvider;
        private readonly IAmazonS3Provider _amazonS3Provider;
        private readonly IUserDataCSVGenerator _userDataCSVGenerator;

        #endregion

        #region Ctors

        public UserService(IEmailProvider emailProvider, IAmazonS3Provider amazonS3Provider, IUserDataCSVGenerator userDataCSVGenerator) : base()
        {
            _emailProvider = emailProvider;
            _amazonS3Provider = amazonS3Provider;
            _userDataCSVGenerator = userDataCSVGenerator;
        }

        #endregion

        #region API Methods

        public bool VerifyUser(string userEmail, string userPassword, out string errorMessage, out bool isErrorPopup, bool allowedOnlyAdmin = true)
        {
            try
            {
                isErrorPopup = false;
                var userToVerify = Storage.Users.GetUserByEmail(userEmail).Result;

                if (userToVerify == null || !Storage.Users.CheckUserAndPasswordAsync(userToVerify, userPassword).Result)
                {
                    errorMessage = "Invalid username or password.";
                    return false;
                }

                if (userToVerify.IsLocked)
                {
                    isErrorPopup = true;
                    errorMessage = "You are not allowed to enter the admin panel.";
                    return false;
                }

                if (allowedOnlyAdmin)
                {
                    var adminRoleDBId = ShedRoleConfig.GetRoleInfo(ShedRoleConfig.ADMIN_ROLE).DbId;
                    if (!userToVerify.Roles.Any(x => x.RoleId == adminRoleDBId))
                    {
                        errorMessage = "A user doesn't have Admin role.";
                        return false;
                    }
                }

                errorMessage = string.Empty;
                return true;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public User GetUserById(string userId)
        {
            try
            {
                var user = Storage.Users.GetById(userId);
                if (user != null)
                {
                    return MapToUser(user);
                }

                return null;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public EntitiesList<User> GetUsers(int number, int size, string sortingField, string pageSort, string filter)
        {
            try
            {
                var result = new EntitiesList<User>();
                var usersQuery = Storage.Users.GetAll();

                var usersByOtherCriteria = new List<ApplicationUser>();

                if (!string.IsNullOrWhiteSpace(filter))
                {
                    var filterToSearch = filter.ToLower();

                    var usersByItemBarcodesQuery = Storage.Items.GetBy(i => i.Barcode != null && i.Barcode.ToLower().Contains(filterToSearch)).Select(i => i.Collection.User).ToList();
                    var usersByCollectionBarcodesQuery = Storage.Collections.GetBy(c => c.Barcode != null && c.Barcode.ToLower().Contains(filterToSearch)).Select(c => c.User).ToList();
                    var usersByCollectionCollaboratorsBarcodesQuery = Storage.Collections.GetBy(c => (c.Barcode != null && c.Barcode.ToLower().Contains(filterToSearch))
                                                                                                  || c.Items.Any(x => x.Barcode != null && x.Barcode.ToLower().Contains(filterToSearch)))
                                                                                         .SelectMany(c => c.Collaborators.Select(x => x.User))
                                                                                         .ToList();
                    
                    usersByOtherCriteria = usersByItemBarcodesQuery.Union(usersByCollectionBarcodesQuery).Union(usersByCollectionCollaboratorsBarcodesQuery).ToList();
                }

                result.Entities = GetQueryBySorting(usersQuery, number, size, sortingField, pageSort, filter, usersByOtherCriteria, out int totalCount)
                                    .Select(x => MapToUser(x))
                                    .ToList();

                result.TotalCount = totalCount;

                return result;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return new EntitiesList<User>();
            }

        }

        public Dictionary<string, string> GetShedUsers()
        {
            try
            {
                var shedUserDBId = ShedRoleConfig.GetRoleInfo(ShedRoleConfig.SHEDUSER_ROLE).DbId;

                var users = Storage.Users.GetAll().ToList();
                return users.Where(x => x.Roles.Any(r => r.RoleId == shedUserDBId)).ToDictionary(d => d.Id, d => $"{d.FirstName} {d.LastName} {d.Email}");
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public Dictionary<string, string> GetAllRoles(bool shouldExcludeAdminRole)
        {
            try
            {
                return ShedRoleConfig.GetAllRoles(shouldExcludeAdminRole);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public void SetUserIsLocked(string userId, bool isLocked)
        {
            try
            {
                var user = Storage.Users.GetById(userId);
                if (user == null)
                {
                    string message = "A user hasn't been found.";
                    Logger.Instance.Error(message);

                    throw new Exception(message);
                }

                user.IsLocked = isLocked;
                Storage.Users.UpdateUser(user);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public string GetRegularUserRoleName()
        {
            try
            {
                return ShedRoleConfig.REGULARUSER_ROLE;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public string GeneratePassword()
        {
            try
            {
                return PasswordGenerator.GeneratePassword();
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public bool TryCreateUser(Models.Users.User user, string password, out string userId, out IEnumerable<string> errors)
        {
            try
            {
                var creationResult = Storage.Users.CreateUser(MapToUser(user), password, out userId);
                errors = creationResult.Errors;
                return creationResult.Succeeded;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                userId = string.Empty;
                errors = new List<string>();
                return false;
            }
        }

        public bool AddUserToRole(string userId, string userRole)
        {
            try
            {
                return Storage.Users.AddUserToRole(userId, userRole);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public void EditUser(Models.Users.User blUser)
        {
            try
            {
                var dbUser = Storage.Users.GetById(blUser.Id);
                if (dbUser == null)
                {
                    string message = "A user hasn't been found.";
                    Logger.Instance.Error(message);
                    throw new Exception(message);
                }

                dbUser.FirstName = blUser.FirstName;
                dbUser.LastName = blUser.LastName;
                dbUser.PhoneNumber = blUser.PhoneNumber;
                dbUser.Email = blUser.Email;
                dbUser.UserName = blUser.Email;

                Storage.Users.UpdateUser(dbUser);

                var userRoles = Storage.Users.GetUserRoles(dbUser).Result;

                var removalResult = Storage.Users.RemoveUserFromRoles(dbUser.Id, userRoles.ToArray(), out IEnumerable<string> errors);

                if (!removalResult)
                {
                    string message = $"Failed to delete user roles, {string.Join(",", errors)}";
                    throw new Exception(message);
                }

                Storage.Users.AddUserToRole(dbUser.Id, blUser.Role);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public void EditUserGeneralInfo(Models.Users.User blUser)
        {
            try
            {
                var dbUser = Storage.Users.GetById(blUser.Id);
                if (dbUser == null)
                {
                    string message = "A user hasn't been found.";
                    Logger.Instance.Error(message);
                    return;
                }

                dbUser.FirstName = blUser.FirstName;
                dbUser.LastName = blUser.LastName;
                dbUser.PhoneNumber = blUser.PhoneNumber;

                Storage.Users.UpdateUser(dbUser);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public void EditUserEmail(Models.Users.User blUser)
        {
            try
            {
                var dbUser = Storage.Users.GetById(blUser.Id);
                if (dbUser == null)
                {
                    string message = "A user hasn't been found.";
                    Logger.Instance.Error(message);
                    return;
                }

                dbUser.Email = blUser.Email;
                dbUser.UserName = blUser.Email;

                Storage.Users.UpdateUser(dbUser);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public bool IsPasswordValid(string userId, string oldPassword)
        {
            var dbUser = Storage.Users.GetById(userId);
            if (dbUser == null)
            {
                string message = "A user hasn't been found.";
                Logger.Instance.Error(message);
                return false;
            }

            return Storage.Users.IsPasswordValid(dbUser.UserName, oldPassword);
        }

        public bool EditUserPassword(string userId, string password, out IEnumerable<string> validationErrors)
        {
            var dbUser = Storage.Users.GetById(userId);

            if (dbUser == null)
            {
                string message = "A user hasn't been found.";
                Logger.Instance.Error(message);
                validationErrors = new List<string> { message };
                return false;
            }

            var token = GetPasswordResetToken(dbUser.Id);

            return TryResetPassword(dbUser.Id, token, password, out validationErrors);
        }

        public int GetUsersCountByEmail(string email, string idToExclude = null)
        {
            try
            {
                return Storage.Users.GetCountOfUsers(u => u.Email == email && u.Id != idToExclude);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public int GetUsersCountByPhoneNumber(string phoneNumber, string idToExclude = null)
        {
            try
            {
                return Storage.Users.GetCountOfUsers(u => u.PhoneNumber == phoneNumber && u.Id != idToExclude);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public string GetPasswordResetToken(string userId)
        {
            try
            {
                return Storage.Users.GetPasswordResetToken(userId);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public Models.Users.User GetUserByEmail(string userEmail)
        {
            try
            {
                var user = Storage.Users.GetUser(u => u.Email == userEmail);
                if (user != null)
                {
                    return MapToUser(user);
                }

                return null;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                throw;
            }
        }

        public bool TryResetPassword(string userId, string token, string newPassword, out IEnumerable<string> errors)
        {
            try
            {
                var resetResult = Storage.Users.ResetPassword(userId, token, newPassword);
                errors = resetResult.Errors;
                return resetResult.Succeeded;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                errors = new List<string>();
                return false;
            }
        }

        public bool DeleteUser(string userId, out IEnumerable<string> errors)
        {
            try
            {
                var user = Storage.Users.GetById(userId);

                if (IsShedAdmin(user.Id))
                {
                    errors = new List<string> { "This user cannot be deleted" };
                    return false;
                }

                var userRoles = Storage.Users.GetUserRoles(user).Result;

                if (userRoles.Any(r => r == ShedRoleConfig.SHEDUSER_ROLE))
                {
                    var shedUserCollections = Storage.Collections.GetBy(c => c.UserId == userId ||
                                                                             c.Collaborators.Any(colab => colab.UserId == userId));

                    if (shedUserCollections.Any())
                    {
                        errors = new List<string> { "The Shed user you are trying to delete has collections in his ownership. " +
                                                    "Please transfer user’s collections to another Shed user before deleting this user." };
                        return false;
                    }
                }

                var deleteResult = DeleteUser(user, out errors);

                return deleteResult;
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                errors = new List<string>();
                return false;
            }

        }

        public string GetAmazonMediaUrl(string key, DateTime? expireDate = null)
        {
            try
            {
                return _amazonS3Provider.GetUrl(key, expireDate);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return null;
            }
        }

        public byte[] GetUserDataCSV(string id, string itemTemplateUrl)
        {
            try
            {
                var user = Storage.Users.GetById(id);

                if (user != null)
                {
                    var role = ShedRoleConfig.GetRoleByPriorityKey(user.Roles.Select(x => x.RoleId).ToList());

                    var blUser = new Models.Users.User(user.Id, user.Email, user.FirstName, user.LastName, user.PhoneNumber, role);
                    return _userDataCSVGenerator.GetUserDataCsv(blUser, itemTemplateUrl);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }

            return null;
        }

        public string GetStringifiedUserDataCsv(string id, string itemTemplateUrl)
        {
            try
            {
                var user = Storage.Users.GetById(id);

                if (user != null)
                {
                    var role = ShedRoleConfig.GetRoleByPriorityKey(user.Roles.Select(x => x.RoleId).ToList());

                    var blUser = new Models.Users.User(user.Id, user.Email, user.FirstName, user.LastName, user.PhoneNumber, role);
                    return _userDataCSVGenerator.GetStringifiedUserDataCsv(blUser, itemTemplateUrl);
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }

            return null;
        }

        public bool IsShedAdmin(string id)
        {
            return string.Equals(AdminConfig.Id, id, StringComparison.OrdinalIgnoreCase);
        }

        public bool IsUserAdmin(string id)
        {
            var dbUser = Storage.Users.GetById(id);

            if (dbUser == null)
            {
                string message = "A user hasn't been found.";
                Logger.Instance.Error(message);
                return false;
            }

            var userRoles = Storage.Users.GetUserRoles(dbUser).Result;

            if (userRoles.Contains(ShedRoleConfig.ADMIN_ROLE))
            {
                return true;
            }

            return false;
        }

        public List<Models.Users.User> GetAllUsers()
        {
            try
            {
                return Storage.Users.GetAll().ToList().Select(u => MapToUser(u)).ToList();
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
            }

            return new List<Models.Users.User>();
        }

        #endregion

        #region Mappers

        private Models.Users.User MapToUser(ApplicationUser applicationUser)
        {
            var role = ShedRoleConfig.GetRoleByPriorityKey(applicationUser.Roles.Select(x => x.RoleId).ToList());
            var canTransferCollections = role == ShedRoleConfig.REGULARUSER_ROLE;
            return User.Map(applicationUser, role, canTransferCollections);
        }

        private ApplicationUser MapToUser(User user)
        {
            return new ApplicationUser
            {
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                PhoneNumber = user.PhoneNumber,
                UserName = user.Email
            };
        }

        private bool DeleteUser(ApplicationUser user, out IEnumerable<string> errors)
        {
            using (var transaction = Storage.StartTransaction())
            {
                try
                {
                    var collaborators = Storage.Collaborators.GetBy(colab => colab.UserId == user.Id).ToList();
                    var collections = Storage.Collections.GetBy(col => col.UserId == user.Id).ToList();

                    var collectionIds = collections.Select(c => c.Id);

                    var notifications = Storage.Notifications.GetBy(n => n.CollectionId.HasValue && collectionIds.Contains(n.CollectionId.Value)).ToList();

                    var items = Storage.Items.GetBy(i => collectionIds.Contains(i.CollectionId)).ToList();

                    var itemIds = items.Select(i => i.Id);

                    var media = Storage.Media.GetBy(m => m.ItemId != null && itemIds.Contains(m.ItemId.Value)).ToList();

                    var videoMediaIds = media.Where(m => m.Type == (int)MediaType.VIDEO).Select(m => m.Id);
                    var otherMediaIds = media.Where(m => m.Type != (int)MediaType.VIDEO).Select(m => m.Id);

                    var videoChapters = Storage.VideoChapters.GetBy(vch => videoMediaIds.Contains(vch.Id)).ToList();

                    var locationIds = Storage.Locations.GetBy(l => l.OwnerId == user.Id).Select(l => l.Id).ToList();

                    Storage.VideoChapters.Delete(videoChapters);
                    Storage.Media.Delete(media);
                    Storage.Items.Delete(items);
                    Storage.Notifications.DeleteRange(notifications);
                    Storage.Collections.Delete(collections);

                    Storage.SaveChanges();

                    RemoveLocations(locationIds);
                    Storage.Collaborators.Delete(collaborators);

                    Storage.SaveChanges();

                    var userDeletionResult = Storage.Users.Delete(user);

                    if (userDeletionResult.Succeeded)
                    {
                        transaction.Commit();
                    }
                    else
                    {
                        transaction.Rollback();
                    }
                    errors = userDeletionResult.Errors;
                    return userDeletionResult.Succeeded;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    Logger.Instance.Error(ex.Message, ex);
                    errors = new List<string>();
                    return false;
                }
            }
        }

        private void RemoveLocations(List<Guid> locationIds)
        {
            foreach (var id in locationIds)
            {
                var location = Storage.Locations.GetById(id);

                if (location != null && Storage.Collections.GetBy(x => x.HomeId == location.Id).ToList().Count == 0)
                {
                    var rooms = Storage.Locations.GetBy(x => x.ParentId.HasValue && x.ParentId == location.Id).ToList();

                    if (rooms.Any())
                    {
                        var roomIds = rooms.Select(x => x.Id).ToList();
                        var roomparts = Storage.Locations.GetBy(x => x.ParentId.HasValue && roomIds.Contains(x.ParentId.Value)).ToList();

                        if (roomparts.Any()) Storage.Locations.Delete(roomparts);

                        Storage.Locations.Delete(rooms);
                    }

                    Storage.Locations.Delete(location);
                }
            }
        }

        #endregion

        #region Private Methods

        private IQueryable<ApplicationUser> GetQueryBySorting(IQueryable<ApplicationUser> query, int number, int size, string sortingField, string sortOrder, string filter, List<ApplicationUser> usersByOtherCriterias, out int totalCount)
        {
            var isPreciseSearch = TryGetFirstLastNameSearch(filter, out Expression<Func<ApplicationUser, bool>> preciseSearchFilter);

            var resultFilteringExpression = isPreciseSearch ? preciseSearchFilter : GetUserFilteringPredicate(filter);
            resultFilteringExpression = ExcludeShedAdminFromFilter(resultFilteringExpression);

            totalCount = query.Where(resultFilteringExpression).Union(usersByOtherCriterias).Count();

            if (string.Equals(sortOrder, "asc", StringComparison.InvariantCultureIgnoreCase))
            {
                return query.Where(resultFilteringExpression)
                            .Union(usersByOtherCriterias)
                            .OrderBy(GetUserListKeySelector(sortingField))
                            .Skip(number * size)
                            .Take(size);
            }
            else
            {
                return query.Where(resultFilteringExpression)
                            .Union(usersByOtherCriterias)
                            .OrderByDescending(GetUserListKeySelector(sortingField))
                            .Skip(number * size)
                            .Take(size);
            }
        }

        private bool TryGetFirstLastNameSearch(string filter, out Expression<Func<ApplicationUser, bool>> userFilteringPredicate)
        {
            try
            {
                var firstAndLastname = filter.Split(' ');

                if (firstAndLastname.Length == 2) //filter is only first and last name and not some abrakadabra
                {
                    userFilteringPredicate = u => (!string.IsNullOrWhiteSpace(u.FirstName) && u.FirstName.ToLowerInvariant().Equals(firstAndLastname[0].ToLowerInvariant(), StringComparison.OrdinalIgnoreCase)) &&
                                                  (!string.IsNullOrWhiteSpace(u.LastName) && u.LastName.ToLowerInvariant().Equals(firstAndLastname[1].ToLowerInvariant(), StringComparison.OrdinalIgnoreCase));

                    return true;
                }
            }
            catch (Exception)
            {
            }

            userFilteringPredicate = null;
            return false;
        }

        private Expression<Func<ApplicationUser, object>> GetUserListKeySelector(string pageSort)
        {
            var sortFieldToLower = pageSort.ToLower();
            Expression<Func<ApplicationUser, object>> resultExpression;
            switch (sortFieldToLower)
            {
                case "firstname":
                    resultExpression = x => x.FirstName;
                    return resultExpression;
                case "lastname":
                    resultExpression = x => x.LastName;
                    return resultExpression;
                case "email":
                    resultExpression = x => x.Email;
                    return resultExpression;
                case "createdatutc":
                default:
                    resultExpression = x => x.CreatedAtUtc;
                    return resultExpression;
            }
        }

        private Expression<Func<ApplicationUser, bool>> GetUserFilteringPredicate(string filter)
        {
            return u => (!string.IsNullOrWhiteSpace(u.FirstName) && u.FirstName.ToLowerInvariant().Contains(filter.ToLowerInvariant())) ||
                        (!string.IsNullOrWhiteSpace(u.LastName) && u.LastName.ToLowerInvariant().Contains(filter.ToLowerInvariant())) ||
                        (!string.IsNullOrWhiteSpace(u.Email) && u.Email.ToLowerInvariant().Contains(filter.ToLowerInvariant())) ||
                        (!string.IsNullOrWhiteSpace(u.PhoneNumber) && u.PhoneNumber.ToLowerInvariant().Contains(filter.ToLowerInvariant()));
        }

        private Expression<Func<ApplicationUser, bool>> ExcludeShedAdminFromFilter(Expression<Func<ApplicationUser, bool>> userFilteringPredicate)
        {
            Expression<Func<ApplicationUser, bool>> shedAdminExcludeExpression = us => !IsShedAdmin(us.Id);
            return ExpressionHelper.AndAlso(userFilteringPredicate, shedAdminExcludeExpression);
        }

        #endregion
    }
}