﻿using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PraticDepo.BusinessLayer.V2.Utils;
using PraticDepo.Common.V2.Tokens.Providers;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public class TokenService : BaseService, ITokenService
    {
        private readonly IJwtTokensProvider _jwtTokensProvider;

        public TokenService(IJwtTokensProvider jwtTokensProvier) : base()
        {
            _jwtTokensProvider = jwtTokensProvier;
        }

        public async Task<string> GenerateUserToken(string userEmail)
        {
            var user = Storage.Users.GetUser(x => x.Email == userEmail);

            if (user == null)
            {
                throw new Exception($"There is no user with the following email: [{userEmail}]");
            }

            var userRoles = await Storage.Users.GetUserRoles(user);

            if (userRoles == null)
            {
                throw new Exception($"An error occured during getting user roles for user [{userEmail}]");
            }

            var claims = _jwtTokensProvider.GenerateClaimsIdentity(userEmail, user.Id, userRoles);
            return _jwtTokensProvider.GenerateJwt(claims, userEmail, new JsonSerializerSettings { Formatting = Formatting.None });
        }
    }
}
