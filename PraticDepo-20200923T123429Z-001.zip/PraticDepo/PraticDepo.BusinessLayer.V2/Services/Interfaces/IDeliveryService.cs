﻿using System;
using System.Collections.Generic;
using PraticDepo.BusinessLayer.V2.Integration.Amazon;
using PraticDepo.BusinessLayer.V2.Integration.CSV;
using PraticDepo.BusinessLayer.V2.Models.Delivery;
using PraticDepo.BusinessLayer.V2.Models.Shared;
using PraticDepo.BusinessLayer.V2.Services.Base;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public interface IDeliveryService : IService
    {
        AddedRequestModel AddDeliveryRequest(string userId, Guid collectionId, Guid? itemId, Guid? chapterId);
        void RemoveDeliveryRequestDetail(string userId, Guid collectionId, Guid? itemId, Guid? chapterId);
        void RemoveDeliveryRequest(Guid requestId, bool isAdministrationManagement = false);
        void SetStatusToDeliveryRequest(Guid requestId, Enums.DeliveryRequestStatus status, IEmailService emailService,
                                        bool isAdministrationManagement = false, bool shouldSendEmail = false, string linkToAdminPanel = "");
        void SetStatusToDeliveryRequestItem(Guid itemId, Enums.DeliveryRequestItemStatus status);
        DeliveryRequestCollectionModel GetDeliveryRequestCollectionForWebAPI(string userId, Guid collectionId);
        List<DeliveryRequestModel> GetDeliveryRequests(string userId);
        List<DeliveryRequestCollectionModel> GetDeliveryRequestDetails(Guid requestId);
        EntitiesList<DeliveryRequestModel> GetDeliveryRequests(int number, int size, string sortingField, string pageSort, string filter);
        List<DeliveryRequestNoteModel> GetDeliveryRequestNotes(Guid requestId);
        DeliveryRequestModel GetDeliveryRequestById(Guid requestId, IAmazonS3Provider amazonS3Provider, string webClientUrl);
        bool IsDeliveryRequestExists(Guid requestId);
        string GetRequestDataCSV(string requestId, string itemTemplateUrl, IRequestDataCSVGenerator reqestDataCSVGenerator, string dateFormat, IFormatProvider formatProvider);
        Guid AddDeliveryRequestNote(Guid requestId, string note, IEmailService emailService, string linkToAdminPanel);
        void UpdateDeliveryRequestNote(Guid noteId, string note);
        void DeleteDeliveryRequestNote(Guid noteId);
        void UpdateDeliveryRequestAdminNote(Guid requestId, string note);
    }
}