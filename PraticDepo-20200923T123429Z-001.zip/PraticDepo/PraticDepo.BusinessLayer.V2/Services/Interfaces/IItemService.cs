﻿using PraticDepo.BusinessLayer.V2.Integration.Amazon;
using PraticDepo.BusinessLayer.V2.Models.Items;
using PraticDepo.BusinessLayer.V2.Models.Shared;
using System;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public interface IItemService
    {
        List<Guid> GetItemIdsWhichBelongToDeliveryRequestsAndNotMovable(List<Guid> itemIds);
        void MoveItemsToOtherCollection(List<Guid> itemIds, Guid targetCollectionId, string userId);
        EntitiesList<Item> GetItems(int number, int size, string sortingField, string pageSort, string filter, IAmazonS3Provider amazonS3Provider, string webClientUrl);
    }
}