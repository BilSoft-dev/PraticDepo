﻿using System.Collections.Generic;
using PraticDepo.BusinessLayer.V2.Models.Locations;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public interface ILocationService
    {
        List<Home> GetUserLocationsByEmail(string userEmail);
        List<Home> GetUserLocationsById(string userId);
    }
}