﻿using PraticDepo.BusinessLayer.V2.Models.Delivery;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public interface IEmailService
    {
        void SendPasswordChangedEmail(string email);
        void SendUserCreatedEmail(string email, string password);
        void SendUserResettedEmail(string email, string password);
        void SendDeliveryRequestSubmittedEmail(IEnumerable<string> recipients, DeliveryRequestModel deliveryRequestModel, string linkToAdminPanel);
        void SendDeliveryRequestCancelledEmail(IEnumerable<string> recipients, DeliveryRequestModel deliveryRequestModel, string linkToAdminPanel);
        void SendNoteAddedToSubmittedDeliveryRequest(IEnumerable<string> recipients, DeliveryNoteSumbittedEmailModel model, string linkToAdminPanel);
    }
}