﻿using System;
using PraticDepo.BusinessLayer.V2.Enums;
using PraticDepo.BusinessLayer.V2.Models.Jobs;
using PraticDepo.BusinessLayer.V2.Models.Shared;
using PraticDepo.BusinessLayer.V2.Services.Base;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public interface IJobService : IService
    {
        EntitiesList<Job> GetJobs(int number, int size, int jobTime, string userId);
        void FinishJob(string userId, Guid jobId, JobStatus jobStatus);
        void StartJob(string userId, Guid jobId, JobStatus jobStatus, ResponsibilityType responsibilityType);
        bool HasJobStarted(string userId);
        bool IsActionEnabledForCollection(Guid collectionId);
        bool IsActionEnabledForItem(Guid itemId);
    }
}
