﻿using System;
using PraticDepo.BusinessLayer.V2.Models.Media;

namespace PraticDepo.BusinessLayer.V2.Services
{
    public interface IMediaService
    {
        Chapter GetChapter(Guid mediaId);
        Media GetMedia(Guid mediaId);
        bool IsMediaItemExist(Guid id);
        bool IsMediaItemBelongsToUser(Guid mediaId, string userId);
    }
}