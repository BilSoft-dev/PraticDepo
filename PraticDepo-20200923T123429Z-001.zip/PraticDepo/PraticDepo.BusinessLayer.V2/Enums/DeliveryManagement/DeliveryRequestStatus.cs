﻿namespace PraticDepo.BusinessLayer.V2.Enums
{
    public enum DeliveryRequestStatus
    {
        NotSubmitted = 0, // Request hasn't been submitted yet
        Submitted = 4, // Default status when a request appears in admin panel
        OnDelivery = 1, // Changes the status of all items to Picked
        Delivered = 2, // Changes the status of all items to Returned
        Cancelled = 3, // Changes the status of all items to Cancelled
    }
}