﻿namespace PraticDepo.BusinessLayer.V2.Enums
{
    public enum DeliveryRequestItemStatus
    {
        NotSubmitted = 0, // Request hasn't been submitted yet
        NotPicked = 1,
        Picked = 2,
        Returned = 3,
        Cancelled = 4
    }
}