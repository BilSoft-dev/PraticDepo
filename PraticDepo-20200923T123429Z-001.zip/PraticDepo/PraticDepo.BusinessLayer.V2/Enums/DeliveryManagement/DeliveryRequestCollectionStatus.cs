﻿namespace PraticDepo.BusinessLayer.V2.Enums
{
    public enum DeliveryRequestCollectionStatus
    {
        NotSubmitted = 0, // Request hasn't been submitted yet
        NotPicked = 1, // Default status
        Picked = 2, // Displayed if all items in a collection have been marked Picked
        Returned = 3, // Displayed if all items in a collection have been marked Returned
        Cancelled = 4 // Displayed if all items in a collection have been marked Cancelled
    }
}