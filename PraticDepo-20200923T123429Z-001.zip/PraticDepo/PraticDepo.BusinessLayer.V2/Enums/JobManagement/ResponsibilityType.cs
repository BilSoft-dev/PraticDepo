﻿namespace PraticDepo.BusinessLayer.V2.Enums
{
    public enum ResponsibilityType
    {
        PackingAndCataloging,
        Moving
    }
}
