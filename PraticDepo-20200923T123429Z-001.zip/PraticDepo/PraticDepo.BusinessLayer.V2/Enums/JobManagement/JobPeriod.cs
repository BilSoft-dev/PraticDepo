﻿namespace PraticDepo.BusinessLayer.V2.Enums.JobManagement
{
    public enum JobPeriod
    {
        TodayAndFuture = 0,
        Past = 1
    }
}
