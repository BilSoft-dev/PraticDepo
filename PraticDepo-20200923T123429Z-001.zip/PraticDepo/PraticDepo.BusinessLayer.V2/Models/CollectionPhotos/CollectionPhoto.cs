﻿using System;

namespace PraticDepo.BusinessLayer.V2.Models.CollectionPhotos
{
    public class CollectionPhoto
    {
        public Guid Id { get; set; }
        public Guid CollectionId { get; set; }
        public string FileName { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
