﻿using System;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Models.Collections
{
    public class CollectionItem
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public List<Media.Media> Media { get; set; }
        public Guid? CollectionId { get; set; }
        public DateTime CreateDate { get; set; }
        public string Barcode { get; set; }
        public decimal? Volume { get; set; }
        public int? Status { get; set; }
    }
}
