﻿using PraticDepo.BusinessLayer.V2.Models.Users;
using System;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Models.Collections
{
    public class Collection
    {
        public Guid Id { get; set; }
        public string UserId { get; set; }
        public DateTime CreateAt { get; set; }
        public string Name { get; set; }
        public List<CollectionItem> Items { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public Guid HomeId { get; set; }
        public string HomeName { get; set; }
        public double HomeLatitude { get; set; }
        public double HomeLongitude { get; set; }
        public Guid? RoomId { get; set; }
        public string RoomName { get; set; }
        public Guid? RoomPartId { get; set; }
        public string RoomPartName { get; set; }
        public string Notes { get; set; }
        public string Barcode { get; set; }
        public decimal? Volume { get; set; }
        public bool IsShedCollection { get; set; }
        public int LocationLevelPermissions { get; set; }
        public int? Status { get; set; }
        public string BinNumber { get; set; }
        public string StorageLocation { get; set; }

        public List<UserCollaborator> Collaborators { get; set; }

        public User CollectionOwner { get; set; }
    }
}
