﻿using System;

namespace PraticDepo.BusinessLayer.V2.Models.Delivery
{
    public class DeliveryRequestNoteModel
    {
        public DeliveryRequestNoteModel(DAL.Models.DeliveryRequestNote dalDeliveryRequestNote)
        {
            Id = dalDeliveryRequestNote.Id;
            Note = dalDeliveryRequestNote.Note;
        }

        public Guid Id { get; set; }
        public string Note { get; set; }
    }
}
