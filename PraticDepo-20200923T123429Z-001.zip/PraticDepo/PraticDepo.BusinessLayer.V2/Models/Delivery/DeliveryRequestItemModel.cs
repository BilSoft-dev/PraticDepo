﻿using System;

namespace PraticDepo.BusinessLayer.V2.Models.Delivery
{
    public class DeliveryRequestItemModel
    {
        public DeliveryRequestItemModel() { }

        public DeliveryRequestItemModel(DAL.Models.DeliveryRequestCollectionItem dalDeliveryRequestCollectionItem)
        {
            ItemId = dalDeliveryRequestCollectionItem.ItemId;
            ItemName = dalDeliveryRequestCollectionItem.Item.Name;
            Status = dalDeliveryRequestCollectionItem.Item.Status.HasValue ? dalDeliveryRequestCollectionItem.Item.Status.Value : -1;
            ChapterId = dalDeliveryRequestCollectionItem.ChapterId;
            Barcode = dalDeliveryRequestCollectionItem.Item.Barcode;
        }

        public Guid ItemId { get; set; }
        public string ItemName { get; set; }
        public int Status { get; set; }
        public string FileName { get; set; }
        public Guid? ChapterId { get; set; }
        public string Barcode { get; set; }
        public string ThumbnailUrl { get; set; }
        public string WebClientAppUrl { get; set; }
        public string ChapterName { get; set; }
        public string ChapterBarcode { get; set; }
    }
}
