﻿using System;

namespace PraticDepo.BusinessLayer.V2.Models.Delivery
{
    public class AddedRequestModel
    {
        public Guid RequestId { get; set; }
        public string RequestNumber { get; set; }
        public Guid CollectionId { get; set; }
        public Guid? ItemId { get; set; }
        public Guid? ChapterId { get; set; }
    }
}