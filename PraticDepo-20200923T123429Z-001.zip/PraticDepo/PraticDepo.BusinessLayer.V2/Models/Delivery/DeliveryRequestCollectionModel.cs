﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PraticDepo.BusinessLayer.V2.Models.Delivery
{
    public class DeliveryRequestCollectionModel
    {
        public DeliveryRequestCollectionModel() { }

        public DeliveryRequestCollectionModel(DAL.Models.DeliveryRequestCollection dalDeliveryRequestCollection)
        {
            CollectionId = dalDeliveryRequestCollection.CollectionId;
            CollectionName = dalDeliveryRequestCollection.Collection.Name;
            Status = dalDeliveryRequestCollection.Status;
            Barcode = dalDeliveryRequestCollection.Collection.Barcode;
            Items = new List<DeliveryRequestItemModel>(dalDeliveryRequestCollection.DeliveryRequestCollectionItems.Select(drci => new DeliveryRequestItemModel(drci)));
        }

        public Guid CollectionId { get; set; }
        public string CollectionName { get; set; }
        public int Status { get; set; }
        public string Barcode { get; set; }
        public int ItemsTotal { get; set; }
        public string StorageLocation { get; set; }
        public string BinNumber { get; set; }
        public string ThumbnailUrl { get; set; }
        public string WebClientAppUrl { get; set; }
        public string PhotoFileName { get; set; }

        public Guid DeliveryRequestId { get; set; }

        public List<DeliveryRequestItemModel> Items { get; set; }
    }
}