﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PraticDepo.BusinessLayer.V2.Models.Delivery
{
    public class DeliveryRequestModel
    {
        public DeliveryRequestModel() { }

        public DeliveryRequestModel(DAL.Models.DeliveryRequest dalDeliveryRequest)
        {
            RequestId = dalDeliveryRequest.Id;
            RequestNumber = dalDeliveryRequest.RequestNumber;
            DateCreated = dalDeliveryRequest.DateCreated;
            DateDelivered = dalDeliveryRequest.DateDelivered;
            Status = dalDeliveryRequest.Status;
            UserId = Guid.Parse(dalDeliveryRequest.UserId);
            UserFirstName = dalDeliveryRequest.UserFirstName;
            UserLastName = dalDeliveryRequest.UserLastName;
            UserEmail = dalDeliveryRequest.UserEmail;
            UserPhoneNumber = dalDeliveryRequest.UserPhoneNumber;
            AdminNote = dalDeliveryRequest.AdminNote;
            Collections = new List<DeliveryRequestCollectionModel>(dalDeliveryRequest.DeliveryRequestCollections.Select(drc => new DeliveryRequestCollectionModel(drc)));
            Notes = new List<DeliveryRequestNoteModel>(dalDeliveryRequest.DeliveryRequestNotes.Select(drn => new DeliveryRequestNoteModel(drn)));
        }

        public Guid RequestId { get; set; }
        public string RequestNumber { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime? DateDelivered { get; set; }
        public int Status { get; set; }
        public Guid UserId { get; set; }
        public string UserFirstName { get; set; }
        public string UserLastName { get; set; }
        public string UserEmail { get; set; }
        public string UserPhoneNumber { get; set; }
        public string AdminNote { get; set; }

        public List<DeliveryRequestCollectionModel> Collections { get; set; }

        public string StatusName { get; set; }
        public bool IsUserDeleted { get; set; }

        public int ItemCounter { get; set; }

        public List<DeliveryRequestNoteModel> Notes { get;  set; }
    }
}
