﻿using System;

namespace PraticDepo.BusinessLayer.V2.Models.Media
{
    public class Chapter
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public double Time { get; set; }
        public string Cover { get; set; }
        public string CoverPreview { get; set; }
        public string Barcode { get; set; }
        public decimal? Volume { get; set; }
        public int? Status { get; set; }
    }
}
