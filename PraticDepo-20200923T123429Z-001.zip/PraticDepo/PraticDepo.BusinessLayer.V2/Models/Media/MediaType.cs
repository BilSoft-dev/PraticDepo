﻿namespace PraticDepo.BusinessLayer.V2.Models.Media
{
    public enum MediaType
    {
        Photo = 0,
        Video
    }
}
