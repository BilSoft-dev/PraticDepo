﻿using System;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Models.Media
{
    public class Media
    {
        public Guid Id { get; set; }
        public string FilePath { get; set; }
        public MediaType Type { get; set; }
        public double Duration { get; set; }
        public List<Chapter> Chapters { get; set; }
        public string PreviewFilePath { get; set; }
    }
}
