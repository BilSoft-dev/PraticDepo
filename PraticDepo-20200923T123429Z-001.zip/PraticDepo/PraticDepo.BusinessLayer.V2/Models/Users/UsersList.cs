﻿using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Models.Users
{
    public class UsersList
    {
        public List<User> Users { get; set; }
        public int TotalCount { get; set; }
    }
}