﻿using System;

namespace PraticDepo.BusinessLayer.V2.Models.Locations
{
    public class RoomPart
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public DateTime CreateAt { get; set; }
    }
}
