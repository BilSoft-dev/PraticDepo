﻿using System;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.V2.Models.Locations
{
    public class Room
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public DateTime CreateAt { get; set; }

        public List<RoomPart> RoomParts { get; set; }
    }
}
