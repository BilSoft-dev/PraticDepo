﻿namespace PraticDepo.BusinessLayer.V2.Models.Configs
{
    public interface IWebClientAppConfig
    {
        string Url { get; set; }
    }
}
