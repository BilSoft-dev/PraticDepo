﻿namespace PraticDepo.BusinessLayer.V2.Models.Configs
{
    public interface ISmtpClientConfig
    {
        bool EnableSSL { get; set; }
        string From { get; set; }
        string Host { get; set; }
        string Password { get; set; }
        int Port { get; set; }
        string UserName { get; set; }
    }
}