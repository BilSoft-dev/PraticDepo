﻿namespace PraticDepo.BusinessLayer.V2.Models.Configs
{
    public class AmazonS3ProviderCustomOptions
    {
        public string BucketName { get; set; }
    }
}
