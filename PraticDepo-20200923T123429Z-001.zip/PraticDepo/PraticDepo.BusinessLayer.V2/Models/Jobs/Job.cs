﻿using PraticDepo.BusinessLayer.V2.Enums;
using System;

namespace PraticDepo.BusinessLayer.V2.Models.Jobs
{
    public class Job
    {
        public Guid JobId { get; set; }
        public int Number { get; set; }
        public JobStatus JobStatus { get; set; }
        public JobStatus UserJobStatus { get; set; }
        public DateTime? DateCancelled { get; set; }
        public DateTime DateCreated { get; set; }
        public string UserId { get; set; }
        public string ClientId { get; set; }
        public string ClientFirstName { get; set; }
        public string ClientLastName { get; set; }
        public string ClientEmail { get; set; }
        public string ClientAddress { get; set; }
        public string Notes { get; set; }
        public DateTime DatePackingEstimatedStart { get; set; }
        public DateTime? DatePackingActualStart { get; set; }
        public DateTime DatePackingEstimatedFinish { get; set; }
        public DateTime? DatePackingActualFinish { get; set; }
        public DateTime DateMovingEstimatedStart { get; set; }
        public DateTime? DateMovingActualStart { get; set; }
        public DateTime DateMovingEstimatedFinish { get; set; }
        public DateTime? DateMovingActualFinish { get; set; }
        public ResponsibilityType ResponsibilityType { get; set; }
        public int CollectionsCount { get; set; }
    }
}