﻿using System;
using System.Threading.Tasks;

namespace PraticDepo.BusinessLayer.V2.Integration.Amazon
{
    public interface IAmazonS3Provider : IDisposable
    {
        string GetUrl(string key, DateTime? expireDate = null);
        string GetPreviewUrl(string key);
        Task<string> UploadPhoto(string base64Content, string fileExtension);
        void DeleteMedia(string path);
    }
}