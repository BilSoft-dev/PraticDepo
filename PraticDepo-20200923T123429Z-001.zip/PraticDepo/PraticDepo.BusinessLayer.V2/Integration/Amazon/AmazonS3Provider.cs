﻿using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using PraticDepo.BusinessLayer.V2.Models.Configs;
using System;
using System.IO;
using System.Threading.Tasks;

namespace PraticDepo.BusinessLayer.V2.Integration.Amazon
{
    public class AmazonS3Provider : IAmazonS3Provider
    {
        private readonly AmazonS3ProviderCustomOptions _s3Config;
        private readonly IAmazonS3 _s3Client;

        public AmazonS3Provider(IAmazonS3 s3Client, AmazonS3ProviderCustomOptions s3Config)
        {
            _s3Client = s3Client;
            _s3Config = s3Config;
        }

        public async Task<string> UploadPhoto(string base64Content, string fileExtension)
        {
            string key = Guid.NewGuid().ToString();
            using (TransferUtility fileTransferUtility = new TransferUtility(_s3Client))
            {
                using (MemoryStream stream = new MemoryStream(Convert.FromBase64String(base64Content)))
                {
                    using (MemoryStream previewStream = new MemoryStream())
                    {
                        AmazonHelper.CreatePhotoPreview(stream, previewStream);
                        var previewUploadRequest = new TransferUtilityUploadRequest
                        {
                            BucketName = _s3Config.BucketName,
                            InputStream = previewStream,
                            StorageClass = S3StorageClass.Standard,
                            Key = string.Format("photo/{0}_preview{1}", key, fileExtension),
                            CannedACL = S3CannedACL.Private
                        };
                        await fileTransferUtility.UploadAsync(previewUploadRequest);
                    }

                    var fileTransferUtilityRequest = new TransferUtilityUploadRequest
                    {
                        BucketName = _s3Config.BucketName,
                        InputStream = stream,
                        StorageClass = S3StorageClass.Standard,
                        Key = string.Format("photo/{0}{1}", key, fileExtension),
                        CannedACL = S3CannedACL.Private
                    };
                    await fileTransferUtility.UploadAsync(fileTransferUtilityRequest);
                }
            }

            return string.Format("photo/{0}{1}", key, fileExtension);
        }

        public string GetUrl(string key, DateTime? expireDate = null)
        {
            if (!string.IsNullOrEmpty(key) && !key.Contains("http")) // Need for compatibility
            {
                GetPreSignedUrlRequest request = new GetPreSignedUrlRequest
                {
                    BucketName = _s3Config.BucketName,
                    Key = key,
                    Expires = expireDate.HasValue ? expireDate.Value : DateTime.Now.AddHours(1)
                };

                return _s3Client.GetPreSignedURL(request);
            }
            else
            {
                return key;
            }
        }

        public void DeleteMedia(string path)
        {
            DeleteObjectRequest deleteObject = new DeleteObjectRequest
            {
                BucketName = _s3Config.BucketName,
                Key = path
            };

            _s3Client.DeleteObject(deleteObject);
        }

        public void Dispose()
        {
            _s3Client.Dispose();
        }

        public string GetPreviewUrl(string key)
        {
            return GetUrl(GetPreviewKey(key));
        }

        private string GetPreviewKey(string key)
        {
            int dotIndex = key.LastIndexOf('.');
            string extension;
            string path;
            if (dotIndex > 0)
            {
                extension = key.Substring(dotIndex);
                path = key.Substring(0, dotIndex);
            }
            else
            {
                extension = "";
                path = key;
            }
            return string.Format("{0}_preview{1}", path, extension);
        }
    }
}
