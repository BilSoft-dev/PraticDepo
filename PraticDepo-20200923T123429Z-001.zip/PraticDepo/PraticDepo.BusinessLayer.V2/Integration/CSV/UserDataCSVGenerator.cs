﻿using PraticDepo.BusinessLayer.V2.Models.Collections;
using PraticDepo.BusinessLayer.V2.Models.Media;
using PraticDepo.BusinessLayer.V2.Models.Users;
using PraticDepo.BusinessLayer.V2.Services;
using System.Linq;
using System.Text;

namespace PraticDepo.BusinessLayer.V2.Integration.CSV
{
    public class UserDataCSVGenerator : IUserDataCSVGenerator
    {
        private readonly ICollectionService _collectionService;

        public UserDataCSVGenerator(ICollectionService collectionService)
        {
            _collectionService = collectionService;
        }

        public string GetStringifiedUserDataCsv(User user, string itemUrlTemplate)
        {
            return GetCsv(user, itemUrlTemplate);
        }

        public byte[] GetUserDataCsv(User user, string itemUrlTemplate)
        {
            return Encoding.UTF8.GetBytes(GetCsv(user, itemUrlTemplate));
        }

        #region Auxiliary methods

        private string GetCsv(User user, string itemUrlTemplate)
        {
            var csvData = new StringBuilder();

            AddUserInfo(csvData, user);
            AddCollectionHeader(csvData);

            var collections = _collectionService.GetUserCollections(user.Id, user.Role);

            foreach (var collection in collections)
            {
                AddCollectionInfo(csvData, collection, itemUrlTemplate);
            }

            return csvData.ToString();
        }

        private void AddUserInfo(StringBuilder csvData, User user)
        {
            csvData.AppendLine($"First Name,{user.FirstName},,,,,,,");
            csvData.AppendLine($"Last Name,{user.LastName},,,,,,,");
            csvData.AppendLine($"Email,{user.Email},,,,,,,");
            csvData.AppendLine($"Phone,{user.PhoneNumber},,,,,,,");
            csvData.AppendLine($",,,,,,,,");
        }

        private void AddCollectionHeader(StringBuilder csvData)
        {
            csvData.AppendLine("Barcode,Item Photo,Item Name,Collection Name,Volume,Collection Notes,Room Part,Room,Location Name,Status");
        }

        private void AddCollectionInfo(StringBuilder csvData, Collection collection, string itemUrlTemplate)
        {
            csvData.AppendLine($"{collection.Barcode},,,{string.Format("\"{0}\"", collection.Name)},{collection.Volume},{string.Format("\"{0}\"", collection.Notes)},{string.Format("\"{0}\"", collection.RoomPartName)},{string.Format("\"{0}\"", collection.RoomName)},{string.Format("\"{0}\"", collection.HomeName)},");

            foreach (var item in collection.Items)
            {
                var row = $"{{ItemBarcode}},{{MediaLink}},{{ItemName}},{string.Format("\"{0}\"", collection.Name)},{{ItemVolume}},,{string.Format("\"{0}\"", collection.RoomPartName)},{string.Format("\"{0}\"", collection.RoomName)},{string.Format("\"{0}\"", collection.HomeName)},";

                if (item.Media != null && item.Media.Any())
                {
                    if (item.Media.Any(m => m.Type == MediaType.Video)) // This is a video item
                    {
                        var videoMedia = item.Media.FirstOrDefault(m => m.Type == MediaType.Video); // This is the video itself
                        var coverMedia = item.Media.FirstOrDefault(m => m.Type == MediaType.Photo); // this is a cover
                        if (coverMedia != null)
                        {
                            csvData.AppendLine(row.Replace("{ItemBarcode}", item.Barcode)
                                                  .Replace("{MediaLink}", itemUrlTemplate.Replace("itemMediaId", coverMedia.Id.ToString("N")))
                                                  .Replace("{ItemName}", string.Format("\"{0}\"", item.Name))
                                                  .Replace("{ItemVolume}", item.Volume == null || item.Volume.Value == 0 ? "" : item.Volume.Value.ToString()));
                        }
                        if (videoMedia != null && videoMedia.Chapters != null && videoMedia.Chapters.Any())
                        {
                            foreach (var chapter in videoMedia.Chapters)
                            {
                                csvData.AppendLine(row.Replace("{ItemBarcode}", chapter.Barcode)
                                                      .Replace("{MediaLink}", itemUrlTemplate.Replace("itemMediaId", chapter.Id.ToString("N")))
                                                      .Replace("{ItemName}", string.Format("\"{0}\"", chapter.Name))
                                                      .Replace("{ItemVolume}", chapter.Volume == null || chapter.Volume.Value == 0 ? "" : chapter.Volume.Value.ToString()));
                            }
                        }
                    }
                    else // This is a photo item
                    {
                        var itemMedia = item.Media.First();
                        csvData.AppendLine(row.Replace("{ItemBarcode}", item.Barcode)
                                              .Replace("{MediaLink}", itemUrlTemplate.Replace("itemMediaId", itemMedia.Id.ToString("N")))
                                              .Replace("{ItemName}", string.Format("\"{0}\"", item.Name))
                                              .Replace("{ItemVolume}", item.Volume == null || item.Volume.Value == 0 ? "" : item.Volume.Value.ToString()));
                    }
                }
            }
        }

        #endregion
    }
}
