﻿using PraticDepo.BusinessLayer.V2.Models.Collections;
using PraticDepo.BusinessLayer.V2.Models.Delivery;
using PraticDepo.BusinessLayer.V2.Models.Media;
using PraticDepo.BusinessLayer.V2.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PraticDepo.BusinessLayer.V2.Integration.CSV
{
    public class RequestDataCSVGenerator : IRequestDataCSVGenerator
    {
        private readonly ICollectionService _collectionService;

        public RequestDataCSVGenerator(ICollectionService collectionService)
        {
            _collectionService = collectionService;
        }

        public string GetStringifiedRequestDataCsv(DeliveryRequestModel deliveryRequestModel, string itemUrlTemplate, string dateFormat, IFormatProvider formatProvider)
        {
            return GetCsv(deliveryRequestModel, itemUrlTemplate, dateFormat, formatProvider);
        }

        #region Auxiliary methods

        private string GetCsv(DeliveryRequestModel deliveryRequestModel, string itemUrlTemplate, string dateFormat, IFormatProvider formatProvider)
        {
            var csvData = new StringBuilder();

            AddDeliveryRequestInfo(csvData, deliveryRequestModel, dateFormat, formatProvider);
            AddCollectionHeader(csvData);

            foreach (var deliveryRequestCollection in deliveryRequestModel.Collections)
            {
                var collection = _collectionService.GetCollectionById(deliveryRequestCollection.CollectionId);
                collection.Status = deliveryRequestCollection.Status;

                AddCollectionInfo(csvData, collection, itemUrlTemplate, deliveryRequestCollection.Items);
            }

            return csvData.ToString();
        }

        private void AddDeliveryRequestInfo(StringBuilder csvData, DeliveryRequestModel deliveryRequestModel, string dateFormat, IFormatProvider formatProvider)
        {
            csvData.AppendLine($"First Name,{deliveryRequestModel.UserFirstName},,,,,,,");
            csvData.AppendLine($"Last Name,{deliveryRequestModel.UserLastName},,,,,,,");
            csvData.AppendLine($"Email,{deliveryRequestModel.UserEmail},,,,,,,");
            csvData.AppendLine($"Phone,{deliveryRequestModel.UserPhoneNumber},,,,,,,");
            csvData.AppendLine($"Delivery Request,{deliveryRequestModel.RequestNumber},,,,,,,");
            csvData.AppendLine($"Request Date,{deliveryRequestModel.DateCreated.ToString(dateFormat, formatProvider)},,,,,,,");

            foreach (var noteModel in deliveryRequestModel.Notes)
            {
                csvData.AppendLine($"User note,{noteModel.Note},,,,,,,");
            }

            csvData.AppendLine($"Admin note,{deliveryRequestModel.AdminNote},,,,,,,");

            csvData.AppendLine($",,,,,,,,");
        }

        private void AddCollectionHeader(StringBuilder csvData)
        {
            csvData.AppendLine("Barcode,Item Photo,Item Name,Collection Name,Volume,Collection Notes,Room Part,Room,Location Name,Status");
        }

        private void AddCollectionInfo(StringBuilder csvData, Collection collection, string itemUrlTemplate, List<DeliveryRequestItemModel> deliveryRequestItems)
        {
            csvData.AppendLine($"{collection.Barcode},,,{string.Format("\"{0}\"", collection.Name)},{collection.Volume},{string.Format("\"{0}\"", collection.Notes)},{string.Format("\"{0}\"", collection.RoomPartName)},{string.Format("\"{0}\"", collection.RoomName)},{string.Format("\"{0}\"", collection.HomeName)},{string.Format("\"{0}\"",GetCollectionStatusDisplayName(collection.Status))}");

            foreach (var deliveryItem in deliveryRequestItems)
            {
                var item = collection.Items.FirstOrDefault(ci => ci.Id == deliveryItem.ItemId);

                if (item != null)
                {
                    var row = $"{{ItemBarcode}},{{MediaLink}},{{ItemName}},{string.Format("\"{0}\"", collection.Name)},{{ItemVolume}},,{string.Format("\"{0}\"", collection.RoomPartName)},{string.Format("\"{0}\"", collection.RoomName)},{string.Format("\"{0}\"", collection.HomeName)},{{Status}}";

                    if (item.Media != null && item.Media.Any())
                    {
                        if (deliveryItem.ChapterId.HasValue)
                        {
                            var videoMedia = item.Media.FirstOrDefault(m => m.Type == MediaType.Video); // This is the video itself

                            if (videoMedia != null && videoMedia.Chapters != null && videoMedia.Chapters.Any())
                            {
                                var chapter = videoMedia.Chapters.FirstOrDefault(c => c.Id == deliveryItem.ChapterId.Value);

                                if (chapter != null)
                                {
                                    csvData.AppendLine(row.Replace("{ItemBarcode}", chapter.Barcode)
                                                          .Replace("{MediaLink}", itemUrlTemplate.Replace("itemMediaId", chapter.Id.ToString("N")))
                                                          .Replace("{ItemName}", string.Format("\"{0}\"", chapter.Name))
                                                          .Replace("{ItemVolume}", chapter.Volume == null || chapter.Volume.Value == 0 ? "" : chapter.Volume.Value.ToString()))
                                                          .Replace("{Status}", GetItemStatusDisplayName(chapter.Status, collection.Status));
                                }
                            }
                        }
                        else
                        {
                            var itemMedia = item.Media.First();
                            csvData.AppendLine(row.Replace("{ItemBarcode}", item.Barcode)
                                                  .Replace("{MediaLink}", itemUrlTemplate.Replace("itemMediaId", itemMedia.Id.ToString("N")))
                                                  .Replace("{ItemName}", string.Format("\"{0}\"", item.Name))
                                                  .Replace("{ItemVolume}", item.Volume == null || item.Volume.Value == 0 ? "" : item.Volume.Value.ToString()))
                                                  .Replace("{Status}", GetItemStatusDisplayName(item.Status, collection.Status));
                        }
                    }
                }
            }
        }

        private string GetCollectionStatusDisplayName(int? status)
        {
            if (status.HasValue)
            {
                switch ((Enums.DeliveryRequestCollectionStatus)status.Value)
                {
                    case Enums.DeliveryRequestCollectionStatus.NotSubmitted: return "Not Submitted";
                    case Enums.DeliveryRequestCollectionStatus.NotPicked: return "Not Picked";
                    case Enums.DeliveryRequestCollectionStatus.Picked: return "Picked";
                    case Enums.DeliveryRequestCollectionStatus.Returned: return "Returned";
                    case Enums.DeliveryRequestCollectionStatus.Cancelled: return "Cancelled";
                }
            }

            return "No status";
        }

        private string GetItemStatusDisplayName(int? itemStatus, int? collectionStatus)
        {
            if (collectionStatus.HasValue && collectionStatus.Value == (int) Enums.DeliveryRequestCollectionStatus.Cancelled)
            {
                return "Cancelled";
            }

            if (itemStatus.HasValue)
            {
                switch ((Enums.DeliveryRequestItemStatus)itemStatus.Value)
                {
                    case Enums.DeliveryRequestItemStatus.NotSubmitted: return "Not Submitted";
                    case Enums.DeliveryRequestItemStatus.NotPicked: return "Not Picked";
                    case Enums.DeliveryRequestItemStatus.Picked: return "Picked";
                    case Enums.DeliveryRequestItemStatus.Returned: return "Returned";
                    case Enums.DeliveryRequestItemStatus.Cancelled: return "Cancelled";
                }
            }

            return "No status";
        }

        #endregion
    }
}
