﻿using PraticDepo.BusinessLayer.V2.Models.Delivery;
using System;

namespace PraticDepo.BusinessLayer.V2.Integration.CSV
{
    public interface IRequestDataCSVGenerator
    {
        string GetStringifiedRequestDataCsv(DeliveryRequestModel deliveryRequestModel, string itemUrlTemplate, string dateFormat, IFormatProvider formatProvider);
    }
}