﻿using PraticDepo.BusinessLayer.V2.Models.Users;

namespace PraticDepo.BusinessLayer.V2.Integration.CSV
{
    public interface IUserDataCSVGenerator
    {
        byte[] GetUserDataCsv(User user, string itemUrlTemplate);
        string GetStringifiedUserDataCsv(User user, string itemUrlTemplate);
    }
}