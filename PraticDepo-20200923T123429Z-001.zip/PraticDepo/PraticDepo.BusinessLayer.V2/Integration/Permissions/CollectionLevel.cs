﻿using System;
using PraticDepo.DAL.Configs;

namespace PraticDepo.BusinessLayer.V2.Integration.Permissions
{
    public static class CollectionLevel
    {
        #region Permissions

        private const int CAN_SEE_COLLECTION = 1;
        private const int CAN_REQUEST_DELIVERY = 1 << 1;
        private const int CAN_REQUEST_PICKUP = 1 << 2;
        private const int CAN_INVITE_SHEDUSER_TO_COLLABORATORS = 1 << 3;
        private const int CAN_INVITE_REGULARUSER_TO_COLLABORATORS = 1 << 4;
        private const int CAN_REMOVE_COLLABORATORS = 1 << 5;
        private const int CAN_DELETE_COLLECTION = 1 << 6;
        private const int CAN_ADD_MORE_ITEMS = 1 << 7;
        private const int CAN_EDIT_COLLECTION_NAME = 1 << 8;
        private const int CAN_EDIT_ITEM_NAMES = 1 << 9;
        private const int CAN_DELETE_ITEM = 1 << 10;
        private const int CAN_SEE_ROOM_ROOMPART = 1 << 11;
        private const int CAN_CHANGE_LOCATION_IN_EXISTING_COLLECTION = 1 << 12;
        private const int CAN_SEE_BARCODE_VOLUME_UNIT = 1 << 13;
        private const int CAN_EDIT_BARCODE_VOLUME_UNIT = 1 << 14;
        private const int CAN_SEE_COLLECTION_ON_SETTINGS = 1 << 15;
        private const int CAN_MANAGE_COLLABORATORS = 1 << 16;
        private const int CAN_CHANGE_ROOMROOMPART_IN_EXISTING_COLLECTION = 1 << 17;
        private const int CAN_SEE_COLLECTION_PHOTO = 1 << 20;
        private const int CAN_ADD_CHANGE_REMOVE_COLLECTION_PHOTO = 1 << 21;

        #endregion

        #region Masks

        private const int SHED_USER_MASK = CAN_SEE_COLLECTION | CAN_INVITE_SHEDUSER_TO_COLLABORATORS | CAN_INVITE_REGULARUSER_TO_COLLABORATORS | CAN_REMOVE_COLLABORATORS | CAN_DELETE_COLLECTION
                                         | CAN_ADD_MORE_ITEMS | CAN_EDIT_COLLECTION_NAME | CAN_EDIT_ITEM_NAMES | CAN_DELETE_ITEM | CAN_SEE_ROOM_ROOMPART
                                         | CAN_CHANGE_LOCATION_IN_EXISTING_COLLECTION | CAN_SEE_BARCODE_VOLUME_UNIT | CAN_EDIT_BARCODE_VOLUME_UNIT | CAN_SEE_COLLECTION_ON_SETTINGS
                                         | CAN_MANAGE_COLLABORATORS | CAN_CHANGE_ROOMROOMPART_IN_EXISTING_COLLECTION
                                         | CAN_SEE_COLLECTION_PHOTO | CAN_ADD_CHANGE_REMOVE_COLLECTION_PHOTO;

        private const int REGULAR_USER_MASK = CAN_SEE_COLLECTION | CAN_INVITE_REGULARUSER_TO_COLLABORATORS | CAN_REMOVE_COLLABORATORS | CAN_DELETE_COLLECTION
                                            | CAN_ADD_MORE_ITEMS | CAN_EDIT_COLLECTION_NAME | CAN_EDIT_ITEM_NAMES | CAN_DELETE_ITEM | CAN_SEE_ROOM_ROOMPART
                                            | CAN_CHANGE_LOCATION_IN_EXISTING_COLLECTION | CAN_SEE_COLLECTION_ON_SETTINGS
                                            | CAN_MANAGE_COLLABORATORS | CAN_CHANGE_ROOMROOMPART_IN_EXISTING_COLLECTION
                                            | CAN_SEE_COLLECTION_PHOTO | CAN_ADD_CHANGE_REMOVE_COLLECTION_PHOTO;

        private const int SHED_COLLABORATOR_IN_SHED_COLLECTION_MASK = CAN_SEE_COLLECTION | CAN_INVITE_SHEDUSER_TO_COLLABORATORS | CAN_INVITE_REGULARUSER_TO_COLLABORATORS | CAN_REMOVE_COLLABORATORS | CAN_DELETE_COLLECTION
                                                                    | CAN_ADD_MORE_ITEMS | CAN_EDIT_COLLECTION_NAME | CAN_EDIT_ITEM_NAMES | CAN_DELETE_ITEM | CAN_SEE_ROOM_ROOMPART
                                                                    | CAN_CHANGE_LOCATION_IN_EXISTING_COLLECTION | CAN_SEE_BARCODE_VOLUME_UNIT | CAN_EDIT_BARCODE_VOLUME_UNIT | CAN_SEE_COLLECTION_ON_SETTINGS
                                                                    | CAN_MANAGE_COLLABORATORS | CAN_CHANGE_ROOMROOMPART_IN_EXISTING_COLLECTION
                                                                    | CAN_SEE_COLLECTION_PHOTO | CAN_ADD_CHANGE_REMOVE_COLLECTION_PHOTO;

        private const int SHED_COLLABORATOR_NOT_IN_SHED_COLLECTION_MASK = 0;

        private const int REGULAR_COLLABORATOR_IN_SHED_COLLECTION_MASK = CAN_SEE_COLLECTION | CAN_REQUEST_DELIVERY | CAN_EDIT_ITEM_NAMES | CAN_SEE_ROOM_ROOMPART
                                                                       | CAN_SEE_BARCODE_VOLUME_UNIT | CAN_SEE_COLLECTION_ON_SETTINGS
                                                                       | CAN_SEE_COLLECTION_PHOTO;

        private const int REGULAR_COLLABORATOR_NOT_IN_SHED_COLLECTION_MASK = CAN_SEE_COLLECTION | CAN_DELETE_COLLECTION | CAN_ADD_MORE_ITEMS
                                                                           | CAN_EDIT_COLLECTION_NAME | CAN_EDIT_ITEM_NAMES | CAN_DELETE_ITEM | CAN_SEE_ROOM_ROOMPART
                                                                           | CAN_SEE_COLLECTION_ON_SETTINGS
                                                                           | CAN_SEE_COLLECTION_PHOTO | CAN_ADD_CHANGE_REMOVE_COLLECTION_PHOTO;
        #endregion

        public static int GetCollectionLevelMask(string role, bool isCollaborator, bool isShedCollection)
        {
            if (isShedCollection)
            {
                switch (role)
                {
                    case ShedRoleConfig.SHEDUSER_ROLE: return isCollaborator ? SHED_COLLABORATOR_IN_SHED_COLLECTION_MASK : SHED_USER_MASK;
                    case ShedRoleConfig.REGULARUSER_ROLE: return isCollaborator ? REGULAR_COLLABORATOR_IN_SHED_COLLECTION_MASK : 0;
                    default: return 0;
                }
            }
            else
            {
                switch (role)
                {
                    case ShedRoleConfig.SHEDUSER_ROLE: return isCollaborator ? SHED_COLLABORATOR_NOT_IN_SHED_COLLECTION_MASK : 0;
                    case ShedRoleConfig.REGULARUSER_ROLE: return isCollaborator ? REGULAR_COLLABORATOR_NOT_IN_SHED_COLLECTION_MASK : REGULAR_USER_MASK;
                    default: return 0;
                }
            }
        }

        public static bool CanSeeCollection(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_SEE_COLLECTION) > 0
                && (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_SEE_COLLECTION_ON_SETTINGS) > 0;
        }

        public static bool CanInviteShedUserToCollaborators(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_INVITE_SHEDUSER_TO_COLLABORATORS) > 0;
        }

        public static bool CanInviteRegularUserToCollaborators(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_INVITE_REGULARUSER_TO_COLLABORATORS) > 0;
        }

        public static bool CanRemoveCollaborators(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_REMOVE_COLLABORATORS) > 0;
        }

        public static bool CanDeleteCollection(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_DELETE_COLLECTION) > 0;
        }

        public static bool CanDeleteItem(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_DELETE_ITEM) > 0;
        }

        public static bool CanAddMoreItems(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_ADD_MORE_ITEMS) > 0;
        }

        public static bool CanEditCollectionName(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_EDIT_COLLECTION_NAME) > 0;
        }

        public static bool CanEditItemNames(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_EDIT_ITEM_NAMES) > 0;
        }

        public static bool CanChangeLocationInExistingCollection(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_CHANGE_LOCATION_IN_EXISTING_COLLECTION) > 0;
        }

        public static bool CanEditBarcodeVolumeUnit(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_EDIT_BARCODE_VOLUME_UNIT) > 0;
        }

        public static bool CanManageCollaborators(string role, bool isCollaborator, bool isShedCollection)
        {
            var mask = GetCollectionLevelMask(role, isCollaborator, isShedCollection);
            return ((mask & CAN_INVITE_SHEDUSER_TO_COLLABORATORS) > 0
                     || (mask & CAN_INVITE_REGULARUSER_TO_COLLABORATORS) > 0
                     || (mask & CAN_REMOVE_COLLABORATORS) > 0);
        }

        public static bool CanChangeRoomRoomPartInExistingCollection(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_CHANGE_ROOMROOMPART_IN_EXISTING_COLLECTION) > 0;
        }

        public static bool CanSeeCollectionPhoto(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_SEE_COLLECTION_PHOTO) > 0;
        }

        public static bool CanAddChangeRemoveCollectionPhoto(string role, bool isCollaborator, bool isShedCollection)
        {
            return (GetCollectionLevelMask(role, isCollaborator, isShedCollection) & CAN_ADD_CHANGE_REMOVE_COLLECTION_PHOTO) > 0;
        }
    }
}
