using System;
using Microsoft.AspNetCore.Mvc;
using PraticDepo.BusinessLayer.V2.Services;
using PraticDepo.Common.V2.Constants;

namespace PraticDepo.WebClientApp.Controllers
{
    public class BaseController : Controller
    {
        protected readonly IUserService _userService;

        public BaseController(IUserService userService)
        {
            _userService = userService;
        }

        protected IActionResult GenerateOkResult(Object result)
        {
            return Ok(new { status = Enums.ResponseState.Success, data = result });
        }

        protected IActionResult GenerateBadResult(Object result)
        {
            return Ok(new { status = Enums.ResponseState.Error, data = result });
        }

        protected bool IsUserExistInDatabaseByEmail(string userEmail, out string userMissingError)
        {
            var usersCount = _userService.GetUsersCountByEmail(userEmail);

            if (usersCount == 0)
            {
                userMissingError = "The user no longer exists in the database.";
                return false;
            }

            userMissingError = string.Empty;
            return true;
        }

        protected bool IsUserExistInDatabaseById(string userId, out string userMissingError)
        {
            var user = _userService.GetUserById(userId);

            if (user == null)
            {
                userMissingError = "The user no longer exists in the database.";
                return false;
            }

            userMissingError = string.Empty;
            return true;
        }

        protected string UserId
        {
            get
            {
                try
                {
                    return User.FindFirst(c => c.Type == Jwt.ClaimIdentifiers.Id).Value;
                }
                catch (Exception)
                {
                    return string.Empty;
                }
            }
        }

        protected bool IsAdmin
        {
            get
            {
                try
                {
                    return User.FindFirst(c => c.Type == Jwt.ClaimIdentifiers.Rol).Value == Jwt.Claims.Admin;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
    }
}