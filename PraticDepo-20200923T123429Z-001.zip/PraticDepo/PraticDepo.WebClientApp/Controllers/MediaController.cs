﻿using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PraticDepo.BusinessLayer.V2.Services;

namespace PraticDepo.WebClientApp.Controllers
{
    [Authorize(Policy = "UserExists")]
    [Produces("application/json")]
    [Route("api/media")]
    public class MediaController : BaseController
    {
        private readonly IMediaService _mediaService;
        private const string MEDIA_ITEM_DOESNT_BELONG_TO_USER = "You must be the collection owner or collaborator to view media files from requested collection.";
        private const string COLLECTION_PHOTO_DOESNT_BELONG_TO_USER = "You must be the collection owner or collaborator to view photos from requested collection.";
        private readonly ICollectionPhotosService _collectionPhotosService;

        public MediaController(IUserService userService, IMediaService mediaService, ICollectionPhotosService collectionPhotosService) : base(userService)
        {
            _mediaService = mediaService;
            _collectionPhotosService = collectionPhotosService;
        }

        [HttpGet]
        public IActionResult Index(string id, string collectionPhotoId = null)
        {
            try
            {
                Guid guidId = Guid.Empty;
                Guid collectionPhotoGuidId = Guid.Empty;

                if ((!Guid.TryParse(id, out guidId) && collectionPhotoId == null) || (!Guid.TryParse(collectionPhotoId, out collectionPhotoGuidId) && id == null))
                {
                    return NotFound();
                }

                if (string.IsNullOrWhiteSpace(UserId))
                {
                    return GenerateBadResult("Incorrect user");
                }

                var isItemMedia = guidId != Guid.Empty;

                return isItemMedia ? HandleMediaItem(guidId, UserId) : HandleCollectionPhotoItem(collectionPhotoGuidId, UserId);
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        private IActionResult HandleMediaItem(Guid mediaId, string userId)
        {
            var path = string.Empty;
            var isMediaItemBelongsToUser = true;

            if (!IsAdmin)
            {
                isMediaItemBelongsToUser = _mediaService.IsMediaItemBelongsToUser(mediaId, userId);
            }

            if (isMediaItemBelongsToUser)
            {
                if (_mediaService.IsMediaItemExist(mediaId))
                {
                    var mediaModel = _mediaService.GetMedia(mediaId);
                    path = mediaModel.FilePath;
                }
                else
                {
                    var chapterModel = _mediaService.GetChapter(mediaId);
                    path = chapterModel.Cover;
                }

                var amazonUrl = _userService.GetAmazonMediaUrl(path, DateTime.Now.AddMinutes(1));
                return GenerateOkResult(amazonUrl);
            }
            else
            {
                return GenerateBadResult(MEDIA_ITEM_DOESNT_BELONG_TO_USER);
            }
        }

        private IActionResult HandleCollectionPhotoItem(Guid collectionPhotoId, string userId)
        {
            var isCollectionPhotoBelongsToUser = true;

            var collectionPhoto = _collectionPhotosService.GetCollectionPhoto(collectionPhotoId);

            if (collectionPhoto == null)
            {
                return GenerateBadResult($"Item with id {collectionPhotoId} doesn't exist");
            }

            if (!IsAdmin)
            {
                isCollectionPhotoBelongsToUser = _collectionPhotosService.IsCollectionPhotoBelongsToUser(collectionPhotoId, userId);
            }

            if (isCollectionPhotoBelongsToUser)
            {
                var amazonUrl = _userService.GetAmazonMediaUrl(collectionPhoto.FileName, DateTime.Now.AddMinutes(1));
                return GenerateOkResult(amazonUrl);
            }
            else
            {
                return GenerateBadResult(COLLECTION_PHOTO_DOESNT_BELONG_TO_USER);
            }
        }
    }
}