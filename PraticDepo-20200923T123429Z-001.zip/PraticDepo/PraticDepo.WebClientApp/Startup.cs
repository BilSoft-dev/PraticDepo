﻿using System;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.SpaServices.Webpack;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.AspNetCore.Http;
using PraticDepo.BusinessLayer.V2.Utils;
using PraticDepo.Common.V2.Tokens.Providers;
using PraticDepo.Common.V2.Tokens;
using PraticDepo.BusinessLayer.V2.Services;
using PraticDepo.BusinessLayer.V2.Models.Configs;
using PraticDepo.Admin.V2.Policies;
using Microsoft.AspNetCore.Authorization;
using PraticDepo.Common.V2.Constants;
using Amazon.S3;
using PraticDepo.BusinessLayer.V2.Integration.Amazon;
using PraticDepo.BusinessLayer.V2.Integration.CSV;
using PraticDepo.BusinessLayer.V2.Utils.Providers.Emails;

namespace PraticDepo.WebClientApp
{
    public class Startup
    {
        private readonly SymmetricSecurityKey _signingKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(Jwt.SecretKey));

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            DbInitializer.AdminV2Initialize(Configuration.GetConnectionString("DefaultConnection"));
           
            // Get options from app settings
            var jwtAppSettingOptions = Configuration.GetSection(nameof(JwtIssuerOptions));
            services.Configure<SmtpClientConfig>(Configuration.GetSection(nameof(SmtpClientConfig)));

            services.TryAddTransient<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<ITokenService, TokenService>();
            services.AddScoped<IEmailProvider, EmailProvider>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IMediaService, MediaService>();
            services.AddScoped<ICollectionService, CollectionService>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<ILocationService, LocationService>();
            services.AddScoped<ICollectionPhotosService, CollectionPhotosService>();
            services.AddSingleton<IUserDataCSVGenerator, UserDataCSVGenerator>();

            services.AddMvc();

            ConfigureJwt(services);

            services.AddSingleton(Configuration.GetSection("AmazonS3ProviderCustomOptions").Get<AmazonS3ProviderCustomOptions>());

            var options = Configuration.GetAWSOptions();

            services.AddDefaultAWSOptions(Configuration.GetAWSOptions());
            services.AddAWSService<IAmazonS3>();

            services.AddSingleton<IAmazonS3Provider, AmazonS3Provider>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseWebpackDevMiddleware(new WebpackDevMiddlewareOptions
                {
                    HotModuleReplacement = true
                });
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");

                routes.MapSpaFallbackRoute(
                    name: "spa-fallback",
                    defaults: new { controller = "Home", action = "Index" });
            });

            Logger.Instance.Info("PraticDepo.WebClientApp started.");
        }

        #region Private Methods

        private void ConfigureJwt(IServiceCollection services)
        {
            // Get options from app settings
            var jwtAppSettingOptions = Configuration.GetSection(nameof(JwtIssuerOptions));

            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = jwtAppSettingOptions[nameof(JwtIssuerOptions.Issuer)],

                ValidateAudience = false,
                ValidAudience = jwtAppSettingOptions[nameof(JwtIssuerOptions.Audience)],

                ValidateIssuerSigningKey = true,
                IssuerSigningKey = _signingKey,

                RequireExpirationTime = false,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero
            };

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

            }).AddJwtBearer(options =>
            {
                options.ClaimsIssuer = jwtAppSettingOptions[nameof(JwtIssuerOptions.Issuer)];
                options.Audience = jwtAppSettingOptions[nameof(JwtIssuerOptions.Audience)];
                options.TokenValidationParameters = tokenValidationParameters;
                options.SaveToken = true;
            });

            services.AddTransient<IJwtTokensProvider>(options => 
            {
                var issuerOptions = new JwtIssuerOptions
                {
                    Issuer = jwtAppSettingOptions[nameof(JwtIssuerOptions.Issuer)],
                    Audience = jwtAppSettingOptions[nameof(JwtIssuerOptions.Audience)],
                    SigningCredentials = new SigningCredentials(_signingKey, SecurityAlgorithms.HmacSha256)
                };

                return new JwtTokensProvider(issuerOptions);
            });

            // api user claim policy
            services.AddAuthorization(options =>
            {
                options.AddPolicy("UserExists", policy =>
                {
                    policy.Requirements.Add(new UserExistsRequirement());
                });

                options.AddPolicy("Admin", policy => policy.RequireClaim(Jwt.ClaimIdentifiers.Rol, Jwt.Claims.Admin));
            });

            services.AddScoped<IAuthorizationHandler, UserExistsHandler>();
        }

        #endregion
    }
}
