﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Admin.V2.Models.Users
{
    public class CollectionTransferViewModel
    {
        [Required]
        public string FromUserId { get; set; }

        public string SelectBy { get; set; }

        [EmailAddress(ErrorMessage = "The email format is invalid. Please enter a valid email of a Shed user.")]
        [Display(Name = "Select by email:")]
        [StringLength(128)]
        public string ToUserByEmail { get; set; }

        [Display(Name = "Select from list:")]
        public string ToUserIdFromList { get; set; }

        //public System.Web.Mvc.SelectList ShedUsers { get; set; }

        public List<string> SelectedLocations { get; set; }
        //public System.Web.Mvc.SelectList AvailableLocations { get; set; }
    }
}