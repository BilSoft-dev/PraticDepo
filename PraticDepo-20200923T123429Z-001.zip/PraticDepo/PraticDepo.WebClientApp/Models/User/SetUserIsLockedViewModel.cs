﻿namespace PraticDepo.Admin.V2.Models.Users
{
    public class SetUserIsLockedViewModel
    {
        public string UserId { get; set; }
        public bool IsLocked { get; set; }
    }
}