﻿namespace PraticDepo.Admin.V2.Models.Users
{
    public class CollectionTransferResultViewModel
    {
        public string UserId { get; set; }
    }
}