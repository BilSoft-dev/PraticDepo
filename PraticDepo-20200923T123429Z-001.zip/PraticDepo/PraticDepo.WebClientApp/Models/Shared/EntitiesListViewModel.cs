﻿using System.Collections.Generic;

namespace PraticDepo.Admin.V2.Models.Shared
{
    public class EntitiesListViewModel<T>
    {
        public List<T> Entities { get; set; }
        public Shared.PagerViewModel Pager { get; set; }
    }
}