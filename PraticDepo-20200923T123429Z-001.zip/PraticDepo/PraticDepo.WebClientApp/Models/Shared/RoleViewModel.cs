﻿namespace PraticDepo.Admin.V2.Models.Shared
{
    public class RoleViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}