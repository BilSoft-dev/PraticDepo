﻿using Microsoft.AspNetCore.Authorization;

namespace PraticDepo.Admin.V2.Policies
{
    public class UserExistsRequirement : IAuthorizationRequirement
    {
        public UserExistsRequirement()
        {
        }
    }
}
