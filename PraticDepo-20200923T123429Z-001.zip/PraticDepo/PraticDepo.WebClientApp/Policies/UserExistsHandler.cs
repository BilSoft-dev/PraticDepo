﻿using Microsoft.AspNetCore.Authorization;
using PraticDepo.BusinessLayer.V2.Services;
using PraticDepo.Common.V2.Constants;
using System.Threading.Tasks;

namespace PraticDepo.Admin.V2.Policies
{
    public class UserExistsHandler : AuthorizationHandler<UserExistsRequirement>
    {
        private readonly IUserService _userService;

        public UserExistsHandler(IUserService userService)
        {
            _userService = userService;
        }

        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, UserExistsRequirement requirement)
        {
            if (!context.User.HasClaim(c => c.Type == Jwt.ClaimIdentifiers.Id))
            {
                context.Fail();
                return Task.CompletedTask;
            }

            var id = context.User.FindFirst(c => c.Type == Jwt.ClaimIdentifiers.Id).Value;
            var user = _userService.GetUserById(id);

            if (user == null || user.IsLocked)
            {
                context.Fail();
                return Task.CompletedTask;
            }
            else
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
