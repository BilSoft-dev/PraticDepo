﻿namespace PraticDepo.WebClientApp.Enums
{
    public enum ResponseState
    {
        Error = 0,
        Success = 1
    }
}