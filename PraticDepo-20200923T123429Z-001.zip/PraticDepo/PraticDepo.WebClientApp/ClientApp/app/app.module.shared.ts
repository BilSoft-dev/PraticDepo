import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from "./app-routes.module";

import { AppComponent } from './app.component';

import { SharedModule } from "./shared/shared.module";
import { LoginModule } from "./components/login/login.module";
import { UsersModule } from "./components/users/users.module";

import { AuthGuard } from './auth.guard'


@NgModule({
    declarations: [
        AppComponent,
    ],
    imports: [
        CommonModule,
        HttpModule,       
        AppRoutingModule,
        SharedModule,
        LoginModule,
        UsersModule
    ],
    exports: [
        SharedModule
    ],
    providers: [
        AuthGuard
    ],
    entryComponents: []
})
export class AppModuleShared {
}
