﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { GetAmazonMediaComponent } from './get-amazon-media/get-amazon-media.component';
import { GetAmazonCollectionPhotoComponent } from './get-amazon-collection-photo/get-amazon-collection-photo.component';
import { SharedModule } from "../../shared/shared.module";
import { AuthenticatedHttpService } from '../../AuthenticatedHttpService'
import { Http } from '@angular/http';
import { MediaService } from '../../shared/services/media.service';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        BrowserModule,
        SharedModule
    ],    
    declarations: [
        GetAmazonMediaComponent,
        GetAmazonCollectionPhotoComponent
    ],
    exports: [
        GetAmazonMediaComponent,
        GetAmazonCollectionPhotoComponent
    ],
    providers: [
        MediaService,
        {
            provide: Http, useClass: AuthenticatedHttpService,
        }
    ],
})

export class UsersModule {
}