﻿import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute, Data } from '@angular/router';
import { AuthService } from '../../../shared/services/auth.service';
import { MediaService } from '../../../shared/services/media.service';

@Component({
    templateUrl: './get-amazon-collection-photo.component.html'
})
export class GetAmazonCollectionPhotoComponent {

    constructor(private authService: AuthService, private router: Router, private activatedRoute: ActivatedRoute, private mediaService: MediaService) {
        this.isErrorExists = false;
    }

    isErrorExists: boolean;
    serverError: any;
    collectionPhotoId: any;

    ngOnInit() {
        this.collectionPhotoId = this.activatedRoute.snapshot.paramMap.get('id');

        if (this.collectionPhotoId !== null) {
            this.mediaService.getCollectionPhoto(this.collectionPhotoId).subscribe(result => {
                if (result.success) {
                    window.location.href = result.data;
                }
                else {
                    this.serverError = result.data;
                    this.isErrorExists = true;
                }
            })
        }
        else {
            this.serverError = "Some error occured";
            this.isErrorExists = true;
        }
    }

    onChangeUser(): void {
        this.authService.logout();
        this.router.navigate(['/login'], { queryParams: { returnUrl: this.router.url } });
    }
}