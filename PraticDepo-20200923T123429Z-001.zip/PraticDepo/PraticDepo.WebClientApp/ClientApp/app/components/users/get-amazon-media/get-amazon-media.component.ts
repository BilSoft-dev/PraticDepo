﻿import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute, Data } from '@angular/router';
import { AuthService } from '../../../shared/services/auth.service';
import { MediaService } from '../../../shared/services/media.service';

@Component({
    selector: 'getamazonmediaurl',
    templateUrl: './get-amazon-media.component.html'
})
export class GetAmazonMediaComponent {

    constructor(private authService: AuthService, private router: Router, private activatedRoute: ActivatedRoute, private mediaService: MediaService) {
        this.isErrorExists = false;
    }

    isErrorExists: boolean;
    serverError: any;
    mediaId: any;

    ngOnInit() {
        this.mediaId = this.activatedRoute.snapshot.paramMap.get('id');

        if (this.mediaId !== null) {
            this.mediaService.getMedia(this.mediaId).subscribe(result => {
                if (result.success) {
                    window.location.href = result.data;
                }
                else {
                    this.serverError = result.data;
                    this.isErrorExists = true;
                }
            })
        }
        else {
            this.serverError = "Some error occured";
            this.isErrorExists = true;
        }
    }

    onChangeUser(): void {
        this.authService.logout();
        this.router.navigate(['/login'], { queryParams: { returnUrl: this.router.url } });
    }
}