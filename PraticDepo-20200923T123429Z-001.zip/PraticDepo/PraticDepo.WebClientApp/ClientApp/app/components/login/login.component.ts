import { Injectable, NgModule } from '@angular/core';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MainFormComponent } from "../../shared/components/forms-component/main-form.component";
import { AuthService } from '../../shared/services/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OkDialogComponent } from '../../shared/dialogs/ok-dialog/ok-dialog.component';
import { ValidationMessages } from '../../shared/custom-validators/validation-messages';

@Component({
    selector: 'login',
    templateUrl: './login.component.html'

})

export class LoginComponent extends MainFormComponent {

    constructor(private authService: AuthService, private router: Router, private dialog: MatDialog, private route: ActivatedRoute,) {
        super();
    }

    hide: boolean = true;
    users: any;
    serverError: any;
    returnUrl: string;

    ngOnInit() {

        this.buildLoginForm();
        super.ngOnInit();
        this.users = {
            email: '',
            password: ''
        }

        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
   }

    private buildLoginForm(): void {
        this.mainFormGroup = new FormGroup({
            'email': new FormControl('', [Validators.required]),
            'password': new FormControl('', [Validators.required]),
        });

        this.validationMessages = {
            'email': {
                'required': ValidationMessages.Required("Email"),
                'emailFormat':''
            },
            'password': {
                'required': ValidationMessages.Required("Password"),
            }
        };

        this.formErrors = {
            'email': '',
            'password': ''
        };
    }
    onLoginFormSubmit(): void {

        if (this.mainFormGroup.invalid) {
            this.markFormElementsAsDirty(this.mainFormGroup, this.formErrors);
            this.collectErrorsForFormControl(this.mainFormGroup, this.formErrors);
            return;
        }

        this.isReqestProccessing = true;

        this.authService.login(this.users.email, this.users.password)
            .subscribe(
            result => {
                if (result.success) {
                    //window.open('/home', '_self');
                    this.router.navigateByUrl(this.returnUrl);
                } else {
                    if (result.data.isPopup) {
                        var dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
                    } else {
                        this.serverError = result.data.errorMessage;
                    }
                }
            },
            error => {
                this.serverError = 'Some error occured.';
            });
    }
}
