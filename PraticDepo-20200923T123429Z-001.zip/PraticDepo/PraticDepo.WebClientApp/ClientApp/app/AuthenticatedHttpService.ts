﻿import { Injectable } from '@angular/core';
import { Request, XHRBackend, RequestOptions, Response, Http, RequestOptionsArgs, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { ConfigService } from './shared/utils/config.service';
import { Router } from '@angular/router';

@Injectable()
export class AuthenticatedHttpService extends Http {
    private authorizationHeaderName: string;
    private authorizationHeaderValuePrefix: string;

    constructor(backend: XHRBackend, defaultOptions: RequestOptions, private configService: ConfigService, private router: Router) {
        super(backend, defaultOptions);

        this.authorizationHeaderName = 'Authorization';
        this.authorizationHeaderValuePrefix = 'Bearer ';
    }

    getAuthorizationHeaderValue() {
        var localToken = localStorage.getItem('auth_token');

        if (localToken !== null && localToken !== '') {
            return this.authorizationHeaderValuePrefix + localToken;
        }
        else {
            return '';
        }
    }

    request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
        return super.request(url, options).catch((error: Response) => {
            if ((error.status === 401 || error.status === 403) && (window.location.href.match(/\?/g) || []).length < 2) {
                console.log('The authentication session expires or the user is not authorised. Force refresh of the current page.');
                localStorage.removeItem('auth_token');
                this.router.navigate(['/login']);
            }
            return Observable.throw(error);
        });
    }

    get(url: string, options?: RequestOptionsArgs) {
        var headerValue = this.getAuthorizationHeaderValue();

        var localHeaders = new Headers();
        localHeaders.append(this.authorizationHeaderName, headerValue);

        if (options !== undefined) {

            if (options.headers !== undefined && options.headers !== null) {
                options.headers.append(this.authorizationHeaderName, headerValue);
            }
            else {
                options.headers = localHeaders;
            }

            return super.get(url, options);
        }

        return super.get(url, {
            headers: localHeaders
        });
    }

    post(url: string, data: any, options?: RequestOptionsArgs) {
        var headerValue = this.getAuthorizationHeaderValue();

        var localHeaders = new Headers();
        localHeaders.append(this.authorizationHeaderName, headerValue);

        if (options !== undefined) {

            if (options.headers !== undefined && options.headers !== null) {
                options.headers.append(this.authorizationHeaderName, headerValue);
            }
            else {
                options.headers = localHeaders;
            }

            return super.post(url, data, options);
        }

        return super.post(url, data, {
            headers: localHeaders
        });
    }
}