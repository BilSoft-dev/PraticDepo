﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { ConfigService } from '../utils/config.service';

import { Observable } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/Rx';
import { BaseService } from './base.service';

@Injectable()

export class AuthService extends BaseService {

    // Observable navItem source
    private _authNavStatusSource = new BehaviorSubject<boolean>(false);
    // Observable navItem stream
    authNavStatus$ = this._authNavStatusSource.asObservable();

    private loggedIn = false;

    constructor(private http: Http, configService: ConfigService) {
        super(configService);

        this.loggedIn = !!localStorage.getItem('auth_token');
        // ?? not sure if this the best way to broadcast the status but seems to resolve issue on page refresh where auth status is lost in
        // header component resulting in authed user nav links disappearing despite the fact user is still logged in
        this._authNavStatusSource.next(this.loggedIn);
    }

    login(email: string, password: string) {
        return this.http
            .post(
            this.getBaseUrl() + '/auth/login',
            JSON.stringify({ email, password }),
            { headers: this.getBaseHttpHeaders() }
            )
            .map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    var parsedData = JSON.parse(result.data);
                    localStorage.setItem('auth_token', parsedData.auth_token);
                    this.loggedIn = true;
                    this._authNavStatusSource.next(true);

                    return { success: true, data: { } };
                } else {
                    return { success: false, data: result.data }
                }
            });
    }

    logout() {
        localStorage.removeItem('auth_token');
        this.loggedIn = false;
        this._authNavStatusSource.next(false);
    }

    isLoggedIn() {
        return this.loggedIn;
    }
}

