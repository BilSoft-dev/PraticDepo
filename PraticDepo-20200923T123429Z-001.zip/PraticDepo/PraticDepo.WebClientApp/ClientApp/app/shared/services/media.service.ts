﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { ConfigService } from '../utils/config.service';

import { Observable } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/Rx';

import { BaseService } from './base.service';

@Injectable()

export class MediaService extends BaseService {

    constructor(private http: Http, configService: ConfigService) {
        super(configService);
    }

    getMedia(mediaId: string) {
        return this.http
            .get(
            this.getBaseUrl() + '/media',
            {
                params: {
                    id: mediaId
                },
                headers: this.getBaseHttpHeaders()
            }).map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }

    getCollectionPhoto(collectionPhotoId: string) {
        return this.http
            .get(
                this.getBaseUrl() + '/media',
                {
                    params: {
                        collectionPhotoId: collectionPhotoId
                    },
                    headers: this.getBaseHttpHeaders()
                }).map(result => {
                    return result.json();
                })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }
}
