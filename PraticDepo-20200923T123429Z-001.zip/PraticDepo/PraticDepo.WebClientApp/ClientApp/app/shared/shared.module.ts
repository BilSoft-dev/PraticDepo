﻿import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from "../app-routes.module";
import { OverlayModule } from '@angular/cdk/overlay';
import { MatButtonModule, MatCheckboxModule, MatProgressSpinnerModule,  MatInputModule, MatIconModule, MatSelectModule, MatPaginatorModule, MatDialogModule, MatRadioModule } from '@angular/material';
import { OkDialogComponent } from './dialogs/ok-dialog/ok-dialog.component';
import { ConfigService } from './utils/config.service';
import { ComponentReloadService } from './services/component-reload.service'

@NgModule({
    imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatCheckboxModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatPaginatorModule,
        MatDialogModule,
        MatRadioModule,
        OverlayModule,
        MatProgressSpinnerModule,
        AppRoutingModule
    ],
    exports: [
        MatButtonModule,
        MatCheckboxModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatPaginatorModule,
        MatDialogModule,
        MatRadioModule,
        MatProgressSpinnerModule,
        AppRoutingModule
    ],
    declarations: [

        OkDialogComponent,
    ],
    providers: [
        { provide: ConfigService, useClass: ConfigService },
        { provide: ComponentReloadService, useClass: ComponentReloadService }
    ],
    entryComponents: [OkDialogComponent]
})
export class SharedModule { }

