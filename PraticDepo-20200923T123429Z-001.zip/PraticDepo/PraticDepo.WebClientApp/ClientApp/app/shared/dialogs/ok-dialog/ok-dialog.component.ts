﻿import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    templateUrl: './ok-dialog.component.html',
    selector: 'ok-dialog',
})
export class OkDialogComponent implements OnInit {
    constructor(public dialogRef: MatDialogRef<OkDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: string) {
    }
    ngOnInit() {
    }
    onOkConfirm() {
        this.dialogRef.close('Ok');
    }
}