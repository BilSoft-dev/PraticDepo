﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Admin.V2.Models.AccountManagement
{
    public class AccountPasswordViewModel : IValidatableObject
    {
        public string UserId { get; set; }

        [DataType(DataType.Password)]
        [StringLength(128, ErrorMessage = "Old password cannot be longer than 128 characters")]
        [Display(Name = "OldPassword")]
        public string OldPassword { get; set; }

        [DataType(DataType.Password)]
        [StringLength(128, ErrorMessage = "Password cannot be longer than 128 characters")]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (string.IsNullOrWhiteSpace(OldPassword) || string.IsNullOrWhiteSpace(Password) || string.IsNullOrWhiteSpace(Password))
            {
                yield return new ValidationResult("Passwords are required");
            }
            if (!string.IsNullOrWhiteSpace(Password) && Password.Length < 6)
            {
                yield return new ValidationResult("The password must be at least 6 characters long");
            }
        }
    }
}
