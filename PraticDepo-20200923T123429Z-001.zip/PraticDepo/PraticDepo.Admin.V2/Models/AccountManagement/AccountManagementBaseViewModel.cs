﻿namespace PraticDepo.Admin.V2.Models.AccountManagement
{
    public class AccountManagementBaseViewModel
    {
        public AccountManagementBaseViewModel(string userId)
        {
            UserId = userId;
        }

        public string UserId { get; set; }
    }
}
