﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Admin.V2.Models.AccountManagement
{
    public class TransferCollectionsViewModel
    {
        public string SourceUserId { get; set; }

        [StringLength(128, ErrorMessage = "Email cannot be longer than 128 characters.")]
        [EmailAddress(ErrorMessage = "The email format is invalid. Please enter a valid email")]
        [Display(Name = "TargetUserEmail")]
        public string TargetUserEmail { get; set; }

        public List<string> CollectionToTransferIds { get; set; }
        public string LocationToTransferId { get; set; }
    }
}
