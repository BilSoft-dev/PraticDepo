﻿using PraticDepo.BusinessLayer.V2.Models.Users;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace PraticDepo.Admin.V2.Models.AccountManagement
{
    public class AccountGeneralInfoViewModel : IValidatableObject
    {
        public string UserId { get; set; }

        [StringLength(128, ErrorMessage = "First name cannot be longer than 128 characters.")]
        [Display(Name = "First name")]
        public string FirstName { get; set; }

        [StringLength(128, ErrorMessage = "Last name cannot be longer than 128 characters.")]
        [Display(Name = "Last name")]
        public string LastName { get; set; }

        [StringLength(10, ErrorMessage = "Phone number must have 10 digits")]
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (!string.IsNullOrWhiteSpace(FirstName) && FirstName.Contains(" "))
            {
                yield return new ValidationResult("First Name must be only in 1 word");
            }
            if (!string.IsNullOrWhiteSpace(LastName) && LastName.Contains(" "))
            {
                yield return new ValidationResult("Last Name must be only in 1 word");
            }
            if ((!string.IsNullOrWhiteSpace(FirstName) && !FirstName.All(char.IsLetter)) || (!string.IsNullOrWhiteSpace(LastName) && !LastName.All(char.IsLetter)))
            {
                yield return new ValidationResult("You can't use numbers, spaces or special characters for first or last name");
            }
            if (!string.IsNullOrWhiteSpace(PhoneNumber) && !PhoneNumber.All(char.IsDigit))
            {
                yield return new ValidationResult("You can’t use characters other digits for a phone number");
            }
            if (!string.IsNullOrWhiteSpace(PhoneNumber) && PhoneNumber.Length != 10)
            {
                yield return new ValidationResult("Phone number must have at least 10 digits");
            }
        }
    }
}
