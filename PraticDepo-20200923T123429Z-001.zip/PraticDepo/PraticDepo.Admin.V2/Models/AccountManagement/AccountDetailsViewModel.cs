﻿using PraticDepo.BusinessLayer.V2.Models.Users;

namespace PraticDepo.Admin.V2.Models.AccountManagement
{
    public class AccountDetailsViewModel
    {
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public bool IsShedAdmin { get; set; }

        public AccountDetailsViewModel(User user, bool isShedAdmin)
        {
            UserId = user.Id;
            FirstName = user.FirstName;
            LastName = user.LastName;
            PhoneNumber = user.PhoneNumber;
            Email = user.Email;
            IsShedAdmin = isShedAdmin;
        }
    }
}
