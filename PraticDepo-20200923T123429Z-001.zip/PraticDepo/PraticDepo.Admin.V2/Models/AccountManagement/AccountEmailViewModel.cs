﻿using PraticDepo.BusinessLayer.V2.Models.Users;
using System.ComponentModel.DataAnnotations;

namespace PraticDepo.Admin.V2.Models.AccountManagement
{
    public class AccountEmailViewModel
    {
        public string UserId { get; set; }

        [Required]
        [StringLength(128, ErrorMessage = "Email cannot be longer than 128 characters.")]
        [EmailAddress(ErrorMessage = "Please use a valid e-mail address")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm email")]
        [Compare("Email", ErrorMessage = "The email and confirmation email do not match.")]
        public string ConfirmEmail { get; set; }
    }
}
