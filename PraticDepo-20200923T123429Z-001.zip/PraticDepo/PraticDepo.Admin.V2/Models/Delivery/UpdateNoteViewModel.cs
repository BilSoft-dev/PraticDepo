﻿namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class UpdateNoteViewModel
    {
        public string RequestId { get; set; }
        public string Note { get; set; }
    }
}
