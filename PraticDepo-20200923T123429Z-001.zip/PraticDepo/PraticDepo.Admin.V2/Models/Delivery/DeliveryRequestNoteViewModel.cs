﻿using PraticDepo.BusinessLayer.V2.Models.Delivery;

namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class DeliveryRequestNoteViewModel
    {
        public DeliveryRequestNoteViewModel(DeliveryRequestNoteModel blDeliveryRequestNote)
        {
            NoteId = blDeliveryRequestNote.Id.ToString();
            NoteText = blDeliveryRequestNote.Note;
        }

        public string NoteId { get; set; }
        public string NoteText { get; set; }
    }
}
