﻿namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class DeleteDeliveryRequestViewModel
    {
        public string RequestId { get; set; }
    }
}
