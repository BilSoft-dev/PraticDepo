﻿using PraticDepo.BusinessLayer.V2.Models.Delivery;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class DeliveryRequestViewModel
    {
        public DeliveryRequestViewModel(DeliveryRequestModel blDeliveryRequest, string dateFormat, IFormatProvider formatProvider, ref int initialIndex)
        {
            RequestId = blDeliveryRequest.RequestId.ToString();
            UserFirstName = blDeliveryRequest.UserFirstName;
            UserLastName = blDeliveryRequest.UserLastName;
            UserEmail = blDeliveryRequest.UserEmail;
            RequestStatus = blDeliveryRequest.Status;

            DeliveryRequestCollections = new List<DeliveryRequestCollectionViewModel>();
            foreach (var collection in blDeliveryRequest.Collections)
            {
                DeliveryRequestCollections.Add(new DeliveryRequestCollectionViewModel(collection, ref initialIndex));
                initialIndex++;
            }

            //DeliveryRequestCollections = new List<DeliveryRequestCollectionViewModel>(blDeliveryRequest.Collections.Select(drc => new DeliveryRequestCollectionViewModel(drc, ref initialIndex++)));
            CreatedDate = blDeliveryRequest.DateCreated.ToString(dateFormat, formatProvider);
            RequestNumber = blDeliveryRequest.RequestNumber;
            AdminNote = blDeliveryRequest.AdminNote;
            DeliveryRequestNotes = new List<DeliveryRequestNoteViewModel>(blDeliveryRequest.Notes.Select(drn => new DeliveryRequestNoteViewModel(drn)));
        }

        public string RequestId { get; set; }
        public string UserFirstName { get; set; }
        public string UserLastName { get; set; }
        public string UserEmail { get; set; }
        public int RequestStatus { get; set; }
        public string CreatedDate { get; set; }
        public string RequestNumber { get; set; }
        public string AdminNote { get; set; }
        public List<DeliveryRequestCollectionViewModel> DeliveryRequestCollections { get; set; }
        public List<DeliveryRequestNoteViewModel> DeliveryRequestNotes { get; set; }
    }
}
