﻿using PraticDepo.BusinessLayer.V2.Models.Delivery;
using System.Collections.Generic;

namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class DeliveryRequestCollectionViewModel
    {
        public DeliveryRequestCollectionViewModel(DeliveryRequestCollectionModel blDeliveryRequestCollection, ref int collectionIndex)
        {
            CollectionName = blDeliveryRequestCollection.CollectionName;
            CollectionBarcode = blDeliveryRequestCollection.Barcode;
            CollectionStatusId = blDeliveryRequestCollection.Status;
            Index = collectionIndex;
            RequestCollectionItems = new List<DeliveryRequestCollectionDetailsViewModel>();

            CollectionImageUrl = blDeliveryRequestCollection.ThumbnailUrl;
            CollectionImageLink = blDeliveryRequestCollection.WebClientAppUrl;

            if (string.IsNullOrWhiteSpace(blDeliveryRequestCollection.StorageLocation) || string.IsNullOrWhiteSpace(blDeliveryRequestCollection.BinNumber))
            {
                CollectionUnitNumber = string.Empty;
            }
            else
            {
                CollectionUnitNumber = $"{blDeliveryRequestCollection.BinNumber}{blDeliveryRequestCollection.StorageLocation}";
            }

            foreach (var collectionDetail in blDeliveryRequestCollection.Items)
            {
                ++collectionIndex;
                RequestCollectionItems.Add(new DeliveryRequestCollectionDetailsViewModel(collectionDetail, ref collectionIndex));
            }
        }

        public string CollectionName { get; set; }
        public string CollectionBarcode { get; set; }
        public int CollectionStatusId { get; set; }
        public int Index { get; set; }
        public string CollectionUnitNumber { get; set; }
        public string CollectionImageUrl { get; set; }
        public string CollectionImageLink { get; set; }
        public List<DeliveryRequestCollectionDetailsViewModel> RequestCollectionItems { get; set; }
    }
}
