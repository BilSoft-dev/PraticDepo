﻿namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class UpdateItemStatusViewModel
    {
        public string ItemId { get; set; }
        public int StatusId { get; set; }
        public string RequestId { get; set; }
    }
}
