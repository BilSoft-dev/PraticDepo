﻿namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class DeleteNoteViewModel
    {
        public string RequestId { get; set; }
    }
}
