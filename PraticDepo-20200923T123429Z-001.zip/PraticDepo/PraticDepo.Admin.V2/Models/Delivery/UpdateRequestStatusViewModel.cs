﻿namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class UpdateRequestStatusViewModel
    {
        public string RequestId { get; set; } 
        public int StatusId { get; set; }
    }
}
