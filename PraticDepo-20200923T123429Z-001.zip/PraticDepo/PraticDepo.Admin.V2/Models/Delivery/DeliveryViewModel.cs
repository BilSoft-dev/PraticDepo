﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace PraticDepo.Admin.V2.Models.Delivery
{
    public class DeliveryViewModel
    {
        public DeliveryViewModel(BusinessLayer.V2.Models.Delivery.DeliveryRequestModel blDeliveryRequest, string dateFormat, IFormatProvider formatProvider)
        {
            RequestId = blDeliveryRequest.RequestId.ToString();
            DateCreated = blDeliveryRequest.DateCreated.ToString(dateFormat, formatProvider);
            Status = blDeliveryRequest.Status;
            UserFirstName = blDeliveryRequest.UserFirstName;
            UserLastName = blDeliveryRequest.UserLastName;
            UserEmail = blDeliveryRequest.UserEmail;
            StatusName = blDeliveryRequest.StatusName;
            IsRequesterUserDeleted = blDeliveryRequest.IsUserDeleted;
            RequestNumber = blDeliveryRequest.RequestNumber;
            AdminNote = blDeliveryRequest.AdminNote;
            DeliveryRequestNotes = new List<DeliveryRequestNoteViewModel>(blDeliveryRequest.Notes.Select(drn => new DeliveryRequestNoteViewModel(drn)));
        }

        public string RequestId { get; set; }
        public string DateCreated { get; set; }
        public int Status { get; set; }
        public string UserFirstName { get; set; }
        public string UserLastName { get; set; }
        public string UserEmail { get; set; }
        public string StatusName { get; set; }
        public bool IsRequesterUserDeleted { get; set; }
        public string RequestNumber { get; set; }
        public string AdminNote { get; set; }
        public List<DeliveryRequestNoteViewModel> DeliveryRequestNotes { get; set; }
    }
}
