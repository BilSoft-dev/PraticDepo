﻿namespace PraticDepo.Admin.V2.Models.Users
{
    public class DeleteViewModel
    {
        public string UserId { get; set; }
    }
}
