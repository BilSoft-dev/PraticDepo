﻿using PraticDepo.BusinessLayer.V2.Models.Users;

namespace PraticDepo.Admin.V2.Models.Users
{
    public class UserEmailDataViewModel
    {
        public UserEmailDataViewModel() { }
        public UserEmailDataViewModel(User user)
        {
            FirstName = user.FirstName;
            LastName = user.LastName;
            Email = user.Email;
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}
