﻿using System;
using PraticDepo.BusinessLayer.V2.Models.Users;

namespace PraticDepo.Admin.V2.Models.Users
{
    public class UserViewModel
    {
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Role { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string CreatedAt { get; set; }
        public bool IsLocked { get; set; }
        public bool CanTransferCollections { get; set; }

        public UserViewModel(User user)
        {
            UserId = user.Id;
            FirstName = user.FirstName;
            LastName = user.LastName;
            Role = user.Role;
            PhoneNumber = user.PhoneNumber;
            Email = user.Email;
            CreatedAt = user.CreatedAtUtc.ToShortDateString();
            IsLocked = user.IsLocked;
            CanTransferCollections = user.CanTransferCollections;
        }
    }
}