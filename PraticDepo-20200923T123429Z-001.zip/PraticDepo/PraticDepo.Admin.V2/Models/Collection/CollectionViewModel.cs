﻿namespace PraticDepo.Admin.V2.Models.Collection
{
    public class CollectionViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int CollectionItemsCount { get; set; }
        public string OwnerFirstName { get; set; }
        public string OwnerLastName { get; set; }
        public string OwnerEmail { get; set; }
        public string CreatedAt { get; set; }

        public CollectionViewModel(BusinessLayer.V2.Models.Collections.Collection blCollection)
        {
            Id = blCollection.Id.ToString();
            Name = blCollection.Name;
            CollectionItemsCount = blCollection.Items.Count;
            OwnerFirstName = blCollection.CollectionOwner.FirstName;
            OwnerLastName = blCollection.CollectionOwner.LastName;
            OwnerEmail = blCollection.CollectionOwner.Email;
            CreatedAt = blCollection.CreateAt.ToShortDateString();
        }
    }
}
