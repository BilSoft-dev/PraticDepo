﻿using PraticDepo.BusinessLayer.V2.Models.Collections;
using System.Collections.Generic;
using System.Linq;

namespace PraticDepo.Admin.V2.Models.CollectionTransfer
{
    public class CollectionListViewModel
    {
        public CollectionListViewModel(List<BusinessLayer.V2.Models.Collections.Collection> collections)
        {
            Collections = collections.Select(c => new CollectionViewModel(c)).ToList();
        }

        public List<CollectionViewModel> Collections { get; set; }
    }
}
