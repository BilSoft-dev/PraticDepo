﻿using PraticDepo.BusinessLayer.V2.Models.Locations;

namespace PraticDepo.Admin.V2.Models.CollectionTransfer
{
    public class LocationViewModel
    {
        public string LocationId { get; set; }
        public string LocationName { get; set; }

        public LocationViewModel(Home location)
        {
            LocationId = location.Id;
            LocationName = location.Name;
        }
    }
}
