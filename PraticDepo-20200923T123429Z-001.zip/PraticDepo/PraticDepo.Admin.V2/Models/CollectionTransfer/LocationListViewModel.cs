﻿using PraticDepo.BusinessLayer.V2.Models.Locations;
using System.Collections.Generic;
using System.Linq;

namespace PraticDepo.Admin.V2.Models.CollectionTransfer
{
    public class LocationListViewModel
    {
        public LocationListViewModel(List<Home> locations)
        {
            Locations = locations.Select(l => new LocationViewModel(l)).ToList();
        }

        public List<LocationViewModel> Locations { get; set; }
    }
}
