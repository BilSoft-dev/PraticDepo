﻿namespace PraticDepo.Admin.V2.Models.CollectionTransfer
{
    public class CollectionViewModel
    {
        public string CollectionId { get; set; }
        public string CollectionName { get; set; }
        public string BelongsToLocationName { get; set; }
        public string BelongsToLocationId { get; set; }

        public CollectionViewModel(BusinessLayer.V2.Models.Collections.Collection collection)
        {
            CollectionId = collection.Id.ToString();
            CollectionName = collection.Name;
            BelongsToLocationName = collection.HomeName;
            BelongsToLocationId = collection.HomeId.ToString();
        }
    }
}
