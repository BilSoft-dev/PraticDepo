﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PraticDepo.Admin.V2.Models.Item;
using PraticDepo.Admin.V2.Models.Shared;
using PraticDepo.BusinessLayer.V2.Integration.Amazon;
using PraticDepo.BusinessLayer.V2.Models.Configs;
using PraticDepo.BusinessLayer.V2.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using PraticDepo.BusinessLayer.V2.Utils;

namespace PraticDepo.Admin.V2.Controllers
{
    [Authorize(Roles = "Admin")]
    [Authorize(Policy = "UserExists")]
    [Produces("application/json")]
    [Route("api/item")]
    public class ItemController : BaseController
    {
        private const int MAX_FILTER_LENGTH = 128;
        private const string DEFAULT_DATE_FORMAT = "MMM dd, yyyy hh:mm tt";

        private IItemService _itemService;
        private IAmazonS3Provider _amazonS3Provider;
        private readonly WebClientAppConfig _webClientAppConfig;
        private IFormatProvider _defaultFormatProvider;

        public ItemController(IUserService userService, IItemService itemService, IAmazonS3Provider amazonS3Provider, IOptions<WebClientAppConfig> webClientAppConfig) : base(userService)
        {
            _itemService = itemService;
            _amazonS3Provider = amazonS3Provider;
            _webClientAppConfig = webClientAppConfig.Value;
            _defaultFormatProvider = CultureInfo.InvariantCulture;
        }

        // GET api/item/list
        [HttpGet("list")]
        public IActionResult List(int pageIndex = 1, int pageSize = 10, string sortingField = "createDate", string pageSort = "desc", string filter = "")
        {
            try
            {
                if (filter?.Length > MAX_FILTER_LENGTH)
                {
                    return GenerateBadResult($"Search query cannot be longer than {MAX_FILTER_LENGTH} characters.");
                }

                var deliveryRequestsModels = new List<ItemViewModel>();
                filter = string.IsNullOrWhiteSpace(filter) ? string.Empty : filter;

                var deliveryRequestsList = _itemService.GetItems(pageIndex, pageSize, sortingField, pageSort, filter, _amazonS3Provider, _webClientAppConfig.Url);

                deliveryRequestsList.Entities.ForEach(x => deliveryRequestsModels.Add(new ItemViewModel(x, DEFAULT_DATE_FORMAT, _defaultFormatProvider)));
                int pageCount = (int)Math.Ceiling((double)deliveryRequestsList.TotalCount / pageSize);

                var model = new EntitiesListViewModel<ItemViewModel>
                {
                    Entities = deliveryRequestsModels,
                    Pager = new PagerViewModel(pageIndex, pageCount, deliveryRequestsList.TotalCount)
                };

                return GenerateOkResult(model);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult("Some error occurred");
            }
        }
    }
}
