﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PraticDepo.Admin.V2.Models.Collection;
using PraticDepo.Admin.V2.Models.Shared;
using PraticDepo.BusinessLayer.V2.Services;
using System;
using System.Collections.Generic;

namespace PraticDepo.Admin.V2.Controllers
{
    [Authorize(Roles = "Admin")]
    [Authorize(Policy = "UserExists")]
    [Produces("application/json")]
    [Route("api/collection")]
    public class CollectionController : BaseController
    {
        private readonly ICollectionService _collectionService;
        private const int MAX_FILTER_LENGTH = 128;

        public CollectionController(ICollectionService collectionService, IUserService userService) : base(userService)
        {
            _collectionService = collectionService;
        }

        // GET api/collection/list
        [HttpGet("list")]
        public IActionResult List(int pageIndex, int pageSize, string sortingField, string pageSort, string filter)
        {
            if (filter?.Length > MAX_FILTER_LENGTH)
            {
                return GenerateBadResult($"Search query cannot be longer than {MAX_FILTER_LENGTH} characters.");
            }

            var collectionModels = new List<CollectionViewModel>();
            filter = string.IsNullOrWhiteSpace(filter) ? string.Empty : filter;

            var collectionsList = _collectionService.GetCollections(pageIndex, pageSize, sortingField, pageSort, filter);

            collectionsList.Entities.ForEach(x => collectionModels.Add(new CollectionViewModel(x)));
            int pageCount = (int)Math.Ceiling((double)collectionsList.TotalCount / pageSize);

            var model = new EntitiesListViewModel<CollectionViewModel>
            {
                Entities = collectionModels,
                Pager = new PagerViewModel(pageIndex, pageCount, collectionsList.TotalCount)
            };

            return GenerateOkResult(model);
        }

        //// GET api/collection/getbyid
        //[HttpGet("getbyid")]
        //public IActionResult GetCollectionsById(string userId)
        //{
        //    if (string.IsNullOrWhiteSpace(userId))
        //    {
        //        return GenerateBadResult("Invalid identifier");
        //    }

        //    if (!IsUserExistInDatabaseById(userId, out string userMissingError))
        //    {
        //        return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
        //    }

        //    var collections = _collectionService.GetUserCollectionsById(userId);

        //    return GenerateOkResult(new CollectionListViewModel(collections));
        //}
    }
}
