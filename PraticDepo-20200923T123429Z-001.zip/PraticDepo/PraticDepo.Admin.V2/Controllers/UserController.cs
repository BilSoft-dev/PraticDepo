﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PraticDepo.Admin.V2.Models.Shared;
using PraticDepo.Admin.V2.Models.Users;
using PraticDepo.BusinessLayer.V2.Integration.CSV;
using PraticDepo.BusinessLayer.V2.Models.Configs;
using PraticDepo.BusinessLayer.V2.Services;

namespace PraticDepo.Admin.V2.Controllers
{
    [Authorize(Roles = "Admin")]
    [Authorize(Policy = "UserExists")]
    [Produces("application/json")]
    [Route("api/user")]
    public class UserController : BaseController
    {
        private const int MAX_FILTER_LENGTH = 128;
        private readonly IMediaService _mediaService;
        private readonly IEmailService _emailService;
        private readonly WebClientAppConfig _webClientAppConfig;
        private readonly IAllUserDataCSVGenerator _allUserDataCSVGenerator;

        public UserController(IUserService userService, IMediaService mediaService, IEmailService emailService, IOptions<WebClientAppConfig> webClientAppConfig, IAllUserDataCSVGenerator allUserDataCSVGenerator) : base(userService)
        {
            _mediaService = mediaService;
            _emailService = emailService;
            _webClientAppConfig = webClientAppConfig.Value;
            _allUserDataCSVGenerator = allUserDataCSVGenerator;
        }

        // GET api/user/list
        [HttpGet("list")]
        public IActionResult List(int pageIndex = 1, int pageSize = 10, string sortingField = "firstName", string pageSort = "asc", string filter = "")
        {
            if (filter?.Length > MAX_FILTER_LENGTH)
            {
                return GenerateBadResult($"Search query cannot be longer than {MAX_FILTER_LENGTH} characters.");
            }

            var userModels = new List<UserViewModel>();
            filter = string.IsNullOrWhiteSpace(filter) ? string.Empty : filter;
            var usersList = _userService.GetUsers(pageIndex, pageSize, sortingField, pageSort, filter);

            usersList.Entities.ForEach(x => userModels.Add(new UserViewModel(x)));
            int pageCount = (int)Math.Ceiling((double)usersList.TotalCount / pageSize);

            var model = new EntitiesListViewModel<UserViewModel>
            {
                Entities = userModels,
                Pager = new PagerViewModel(pageIndex, pageCount, usersList.TotalCount)
            };

            return GenerateOkResult(model);
        }

        // GET api/user/edit
        [HttpGet("edit")]
        public IActionResult Edit(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return GenerateBadResult("Incorrect identifier");
                }
                else
                {
                    var user = _userService.GetUserById(id);

                    if (user == null)
                    {
                        return GenerateBadResult("The user no longer exists in the database.");
                    }

                    var model = new UserManageViewModel(user)
                    {
                        AllRoles = GetAllRolesInternal()
                    };

                    return GenerateOkResult(model);
                }
            }
            catch (Exception ex)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        // GET api/user/roles
        [HttpGet("roles")]
        public IActionResult GetAllRoles()
        {
            var roles = GetAllRolesInternal();
            return GenerateOkResult(roles);
        }

        // POST api/user/edit
        [HttpPost("edit")]
        public IActionResult Edit([FromBody]UserManageViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return GenerateBadResult(ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage);
                }

                if (!IsUserExistInDatabaseById(model.UserId, out string userMissingError))
                {
                    return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
                }

                if (!TryPerfromAdditionalCreateEditValidations(model, out string validationMessage))
                {
                    return GenerateBadResult(validationMessage);
                }

                var userBLModel = new BusinessLayer.V2.Models.Users.User(model.Email, model.FirstName, model.LastName, model.PhoneNumber, model.Role)
                {
                    Id = model.UserId
                };

                _userService.EditUser(userBLModel);

                return GenerateOkResult(null);
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        // POST api/user/create
        [HttpPost("create")]
        public IActionResult Create([FromBody]UserManageViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return GenerateBadResult(ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage);
                }

                if (!TryPerfromAdditionalCreateEditValidations(model, out string validationMessage))
                {
                    return GenerateBadResult(validationMessage);
                }

                var password = model.IsAutoGeneratedPassword ? _userService.GeneratePassword() : model.Password;

                var userBLModel = new BusinessLayer.V2.Models.Users.User(model.Email.ToLower(), model.FirstName, model.LastName, model.PhoneNumber);
                var creationResult = _userService.TryCreateUser(userBLModel, password, out string userId, out IEnumerable<string> userCreationErrors);

                if (creationResult)
                {
                    _userService.AddUserToRole(userId, model.Role);
                    _emailService.SendUserCreatedEmail(model.Email, password);
                }
                else
                {
                    return GenerateBadResult(string.Join(",", userCreationErrors));
                }

                return GenerateOkResult(null);
            }
            catch (Exception ex)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        // POST api/user/create
        [HttpPost("reset")]
        public IActionResult Reset([FromBody]ResetUserViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return GenerateBadResult(ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage);
                }

                if (!IsUserExistInDatabaseByEmail(model.Email, out string userMissingError))
                {
                    return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
                }

                var user = _userService.GetUserByEmail(model.Email);

                if (user == null)
                {
                    return GenerateBadResult("The user no longer exists in the database.");
                }

                var token = _userService.GetPasswordResetToken(user.Id);
                var password = model.IsAutoGeneratedPassword ? _userService.GeneratePassword() : model.Password;

                var resetSucceeded = _userService.TryResetPassword(user.Id, token, password, out IEnumerable<string> passwordResetErrors);

                if (resetSucceeded)
                {
                    _emailService.SendUserResettedEmail(model.Email, password);
                }
                else
                {
                    return GenerateBadResult(string.Join(",", passwordResetErrors));
                }

                return GenerateOkResult(null);
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        //POST api/user/delete
        [HttpPost("delete")]
        public IActionResult Delete([FromBody]DeleteViewModel model)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(model.UserId))
                {
                    return GenerateBadResult("Invalid identifier");
                }

                if (!IsUserExistInDatabaseById(model.UserId, out string userMissingError))
                {
                    return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
                }

                var isDeleteSucceeded = _userService.DeleteUser(model.UserId, out IEnumerable<string> errors);

                if (isDeleteSucceeded)
                {
                    return GenerateOkResult(null);
                }
                else
                {
                    return GenerateBadResult(string.Join(",", errors));
                }
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        // POST api/user/unlock
        [HttpPost("setislocked")]
        public IActionResult SetUserIsLocked([FromBody]SetUserIsLockedViewModel viewModel)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(viewModel.UserId))
                {
                    return GenerateBadResult("Incorrect identifier");
                }

                if (!IsUserExistInDatabaseById(viewModel.UserId, out string userMissingError))
                {
                    return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
                }

                _userService.SetUserIsLocked(viewModel.UserId, viewModel.IsLocked);
                return GenerateOkResult(null);
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        [HttpGet("getuserdatacsv")]
        public IActionResult GetUserDataCsv(string id)
        {
            try
            {
                if (!IsUserExistInDatabaseById(id, out string userMissingError))
                {
                    return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
                }

                //var itemUrlTemplate = Url.Action("GetAmazonMediaUrl", "User", new { id = "itemMediaId" }, HttpContext.Request.Scheme);

                ////url workaround in order to hit frontend code
                ////link is converted
                ////from http://localhost:54165/api/user/getamazonmediaurl?id=91492c9059934349baf663aad58b0450
                ////to http://localhost:54165/users/user/getamazonmediaurl/91492c9059934349baf663aad58b0450
                //var apiSegment = new Uri(itemUrlTemplate).Segments[1];
                //itemUrlTemplate = itemUrlTemplate.Replace(apiSegment, "users/").Replace("?id=", "/");

                var baseUri = new Uri(_webClientAppConfig.Url);
                var itemUrlTemplate = new Uri(baseUri, "itemMediaId").ToString();

                return GenerateOkResult(new { fileData = _userService.GetStringifiedUserDataCsv(id, itemUrlTemplate), fileType = "text/csv", fileName = $"{id}.csv" });
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        [HttpGet("getamazonmediaurl")]
        [AllowAnonymous]
        public IActionResult GetAmazonMediaUrl(string id)
        {
            try
            {
                var baseUri = new Uri(_webClientAppConfig.Url);
                var itemUrl = new Uri(baseUri, id).ToString();

                return GenerateOkResult(itemUrl);
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        // GET api/user/emailData
        [HttpGet("emailData")]
        public IActionResult GetUserEmailData()
        {
            try
            {
                var blUsers = _userService.GetAllUsers();
                return GenerateOkResult(blUsers.Select(u => new UserEmailDataViewModel(u)).ToList());
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        // GET api/user/isexist
        [HttpGet("isexist")]
        public IActionResult IsUserExist(string id)
        {
            try
            {
                if (!IsUserExistInDatabaseById(id, out string userMissingError))
                {
                    return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
                }

                return GenerateOkResult(new { isUserMissing = false, errorMessage = string.Empty });
            }
            catch (Exception)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        // GET api/user/exportalluserdata
        [HttpGet("exportalluserdata")]
        public IActionResult ExportAllUserData()
        {
            try
            {
                var baseUri = new Uri(_webClientAppConfig.Url);
                var itemUrlTemplate = new Uri(baseUri, "itemMediaId").ToString();

                return GenerateOkResult(new { fileData = _allUserDataCSVGenerator.GetStringifiedAllUserDataCsv(itemUrlTemplate), fileType = "text/csv", fileName = $"all_user_data.csv" });
            }
            catch (Exception ex)
            {
                return GenerateBadResult("Some error occured");
            }
        }

        #region Private Methods

        private List<Models.Shared.RoleViewModel> GetAllRolesInternal()
        {
            var roles = new List<Models.Shared.RoleViewModel>();
            roles.Add(new Models.Shared.RoleViewModel { Id = "", Name = "" });
            foreach (var role in _userService.GetAllRoles(false))
            {
                roles.Add(new Models.Shared.RoleViewModel
                {
                    Id = role.Key,
                    Name = role.Value
                });
            }

            return roles;
        }

        private bool TryPerfromAdditionalCreateEditValidations(UserManageViewModel model, out string validationMessage)
        {
            if (_userService.GetUsersCountByEmail(model.Email, model.UserId) > 0)
            {
                validationMessage = "A user with such email already exists.";
                return false;
            }

            if (model.Role == _userService.GetRegularUserRoleName() && string.IsNullOrWhiteSpace(model.PhoneNumber))
            {
                validationMessage = "Phone number is required for regular users.";
                return false;
            }

            if (!string.IsNullOrWhiteSpace(model.PhoneNumber) && _userService.GetUsersCountByPhoneNumber(model.PhoneNumber, model.UserId) > 0)
            {
                validationMessage = "A user with such phone number already exists.";
                return false;
            }

            validationMessage = string.Empty;
            return true;
        }

        #endregion
    }
}