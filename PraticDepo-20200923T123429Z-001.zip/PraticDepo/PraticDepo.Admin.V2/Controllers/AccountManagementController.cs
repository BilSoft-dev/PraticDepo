﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PraticDepo.Admin.V2.Models.AccountManagement;
using PraticDepo.BusinessLayer.V2.Services;

namespace PraticDepo.Admin.V2.Controllers
{
    [Authorize(Roles = "Admin")]
    [Authorize(Policy = "UserExists")]
    [Produces("application/json")]
    [Route("api/account")]
    public class AccountManagementController : BaseController
    {
        private readonly IEmailService _emailService;

        public AccountManagementController(IUserService userService, IEmailService emailService) : base(userService)
        {
            _emailService = emailService;
        }

        // GET api/account/details
        [HttpGet("details")]
        public IActionResult GetAccountDetails(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return GenerateBadResult("Invalid identifier");
            }

            if (!IsUserExistInDatabaseById(id, out string userMissingError))
            {
                return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
            }

            var user = _userService.GetUserById(id);

            var isShedAdmin = _userService.IsShedAdmin(user.Id);

            var accountDetails = new AccountDetailsViewModel(user, isShedAdmin);

            return GenerateOkResult(accountDetails);
        }

        // POST api/account/editgeneral
        [HttpPost("editgeneral")]
        public IActionResult EditGeneralInfo([FromBody]AccountGeneralInfoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return GenerateBadResult(ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage);
            }

            if (!IsUserExistInDatabaseById(model.UserId, out string userMissingError))
            {
                return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
            }

            if (!TryPerfromAdditionalEditGeneralInfoValidations(model, out string validationMessage))
            {
                return GenerateBadResult(validationMessage);
            }

            var userBLModel = new BusinessLayer.V2.Models.Users.User(model.FirstName, model.LastName, model.PhoneNumber)
            {
                Id = model.UserId
            };

            _userService.EditUserGeneralInfo(userBLModel);

            return GenerateOkResult(null);
        }

        // POST api/account/editemail
        [HttpPost("editemail")]
        public IActionResult EditEmail([FromBody]AccountEmailViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return GenerateBadResult(ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage);
            }

            if (!IsUserExistInDatabaseById(model.UserId, out string userMissingError))
            {
                return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
            }

            if (!TryPerfromAdditionalEditEmailValidations(model, out string validationMessage))
            {
                return GenerateBadResult(validationMessage);
            }

            var userBLModel = new BusinessLayer.V2.Models.Users.User()
            {
                Id = model.UserId,
                Email = model.Email
            };

            _userService.EditUserEmail(userBLModel);
            _emailService.SendUserCreatedEmail(userBLModel.Email, string.Empty);

            return GenerateOkResult(null);
        }

        // POST api/account/editpassword
        [HttpPost("editpassword")]
        public IActionResult EditPassword([FromBody]AccountPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return GenerateBadResult(ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage);
            }

            if (!IsUserExistInDatabaseById(model.UserId, out string userMissingError))
            {
                return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
            }

            if (!TryPerfromAdditionalEditPasswordValidations(model, out string validationMessage))
            {
                return GenerateBadResult(validationMessage);
            }

            var isEditSuccessfull = _userService.EditUserPassword(model.UserId, model.Password, out IEnumerable<string> passwordEditErrors);

            if (isEditSuccessfull)
            {
                var user = _userService.GetUserById(model.UserId);
                _emailService.SendPasswordChangedEmail(user.Email);
                return GenerateOkResult(null);
            }
            else
            {
                return GenerateBadResult(string.Join(",", passwordEditErrors));
            }
        }

        #region Private Methods

        private bool TryPerfromAdditionalEditGeneralInfoValidations(AccountGeneralInfoViewModel model, out string validationMessage)
        {
            if (!string.IsNullOrWhiteSpace(model.PhoneNumber) && _userService.GetUsersCountByPhoneNumber(model.PhoneNumber, model.UserId) > 0)
            {
                validationMessage = "A user with such phone number already exists.";
                return false;
            }

            validationMessage = string.Empty;
            return true;
        }

        private bool TryPerfromAdditionalEditEmailValidations(AccountEmailViewModel model, out string validationMessage)
        {
            if (_userService.GetUsersCountByEmail(model.Email, model.UserId) > 0)
            {
                validationMessage = "A user with such email already exists.";
                return false;
            }

            validationMessage = string.Empty;
            return true;
        }

        private bool TryPerfromAdditionalEditPasswordValidations(AccountPasswordViewModel model, out string validationMessage)
        {
            if (!_userService.IsPasswordValid(model.UserId, model.OldPassword))
            {
                validationMessage = "Old password is not valid.";
                return false;
            }

            validationMessage = string.Empty;
            return true;
        }

        #endregion
    }
}
