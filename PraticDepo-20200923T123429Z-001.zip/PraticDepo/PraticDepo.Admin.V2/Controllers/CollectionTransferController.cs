﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PraticDepo.Admin.V2.Models.AccountManagement;
using PraticDepo.Admin.V2.Models.CollectionTransfer;
using PraticDepo.BusinessLayer.V2.Services;
using System.Collections.Generic;
using System.Linq;

namespace PraticDepo.Admin.V2.Controllers
{
    [Authorize(Roles = "Admin")]
    [Authorize(Policy = "UserExists")]
    [Produces("application/json")]
    [Route("api/collectiontransfer")]
    public class CollectionTransferController : BaseController
    {
        private readonly ICollectionService _collectionService;
        private readonly ILocationService _locationService;
        private const string USER_MISSING_ERROR_MESSAGE = "There is no user with the defined email in the database. Please enter an email of an existing user";

        public CollectionTransferController(ICollectionService collectionService, IUserService userService, ILocationService locationService) : base(userService)
        {
            _collectionService = collectionService;
            _locationService = locationService;
        }

        // GET api/collectiontransfer/collectionsbyid
        [HttpGet("collectionsbyid")]
        public IActionResult GetCollectionsById(string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
            {
                return GenerateBadResult("Invalid identifier");
            }

            if (!IsUserExistInDatabaseById(userId, out string userMissingError))
            {
                return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
            }

            var collections = _collectionService.GetUserCollectionsById(userId);

            return GenerateOkResult(new CollectionListViewModel(collections));
        }

        // GET api/collectiontransfer/locationsbyemail
        [HttpPost("locationsbyemail")]
        public IActionResult GetLocationsByEmail([FromBody]GetLocationsByEmailViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return GenerateBadResult(ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage);
            }

            if (!IsUserExistInDatabaseByEmail(model.Email, out string userMissingError))
            {
                return GenerateBadResult(USER_MISSING_ERROR_MESSAGE);
            }

            var locations = _locationService.GetUserLocationsByEmail(model.Email);

            return GenerateOkResult(new LocationListViewModel(locations));
        }

        // GET api/collectiontransfer/locationsbyid
        [HttpGet("locationsbyid")]
        public IActionResult GetLocationsById(string userId)
        {
            if (string.IsNullOrWhiteSpace(userId))
            {
                return GenerateBadResult("Invalid identifier");
            }

            if (!IsUserExistInDatabaseById(userId, out string userMissingError))
            {
                return GenerateBadResult(new { isUserMissing = true, errorMessage = userMissingError });
            }

            var lcoations = _locationService.GetUserLocationsById(userId);

            return GenerateOkResult(new LocationListViewModel(lcoations));
        }

        // GET api/collectiontransfer/transfer
        [HttpPost("transfer")]
        public IActionResult TransferCollections([FromBody]TransferCollectionsViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return GenerateBadResult(ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage);
            }

            if ((model.LocationToTransferId == null || !model.LocationToTransferId.Any())
                || (model.CollectionToTransferIds == null || !model.CollectionToTransferIds.Any()))
            {
                return GenerateBadResult("Collections cannot be transferred. Please check that there is at least one collection selected and that the target user has at least one location.");
            }

            if (!IsUserExistInDatabaseByEmail(model.TargetUserEmail, out string userMissingError))
            {
                return GenerateBadResult("Cannot transfer collections. Please check that the target user and location still exist in the database.");
            }

            var transferResult = _collectionService.TransferCollections(model.SourceUserId, model.TargetUserEmail, model.CollectionToTransferIds, model.LocationToTransferId, out List<string> errors);

            return transferResult ? GenerateOkResult(null) : GenerateBadResult(string.Join(",", errors));
        }
    }
}
