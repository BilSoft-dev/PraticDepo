﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PraticDepo.Admin.V2.Models.Delivery;
using PraticDepo.Admin.V2.Models.Shared;
using PraticDepo.BusinessLayer.V2.Enums;
using PraticDepo.BusinessLayer.V2.Integration.Amazon;
using PraticDepo.BusinessLayer.V2.Integration.CSV;
using PraticDepo.BusinessLayer.V2.Models.Configs;
using PraticDepo.BusinessLayer.V2.Services;
using System;
using System.Collections.Generic;
using PraticDepo.BusinessLayer.V2.Utils;
using System.Globalization;

namespace PraticDepo.Admin.V2.Controllers
{
    [Authorize(Roles = "Admin")]
    [Authorize(Policy = "UserExists")]
    [Produces("application/json")]
    [Route("api/delivery")]
    public class DeliveryController : BaseController
    {
        private const int MAX_FILTER_LENGTH = 128;
        private const string DEFAULT_DATE_FORMAT = "MMM dd, yyyy hh:mm tt";
        private const string CSV_DATE_FORMAT = "MMM dd yyyy hh:mm tt";
        private const int DELIVERY_REQUEST_NOTE_MAXIMUM_LENGTH = 1000;

        private readonly IDeliveryService _deliveryService;
        private readonly IAmazonS3Provider _amazonS3Provider;
        private readonly WebClientAppConfig _webClientAppConfig;
        private readonly IRequestDataCSVGenerator _requestDataCSVGenerator;
        private readonly IEmailService _emailService;
        private IFormatProvider _defaultFormatProvider;

        public DeliveryController(IUserService userService, IDeliveryService deliveryService, IAmazonS3Provider amazonS3Provider, 
                                  IOptions<WebClientAppConfig> webClientAppConfig, IRequestDataCSVGenerator requestDataCSVGenerator, IEmailService emailService) 
            : base(userService)
        {
            _deliveryService = deliveryService;
            _amazonS3Provider = amazonS3Provider;
            _webClientAppConfig = webClientAppConfig.Value;
            _requestDataCSVGenerator = requestDataCSVGenerator;
            _emailService = emailService;
            _defaultFormatProvider =  CultureInfo.InvariantCulture;
        }

        // GET api/delivery/list
        [HttpGet("list")]
        public IActionResult List(int pageIndex, int pageSize, string sortingField, string pageSort, string filter)
        {
            try
            {
                if (filter?.Length > MAX_FILTER_LENGTH)
                {
                    return GenerateBadResult($"Search query cannot be longer than {MAX_FILTER_LENGTH} characters.");
                }

                var deliveryRequestsModels = new List<DeliveryViewModel>();
                filter = string.IsNullOrWhiteSpace(filter) ? string.Empty : filter;

                var deliveryRequestsList = _deliveryService.GetDeliveryRequests(pageIndex, pageSize, sortingField, pageSort, filter);

                deliveryRequestsList.Entities.ForEach(x => deliveryRequestsModels.Add(new DeliveryViewModel(x, DEFAULT_DATE_FORMAT, _defaultFormatProvider)));
                int pageCount = (int)Math.Ceiling((double)deliveryRequestsList.TotalCount / pageSize);

                var model = new EntitiesListViewModel<DeliveryViewModel>
                {
                    Entities = deliveryRequestsModels,
                    Pager = new PagerViewModel(pageIndex, pageCount, deliveryRequestsList.TotalCount)
                };

                return GenerateOkResult(model);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult("Some error occurred");
            }

        }

        // GET api/delivery/request
        [HttpGet("request")]
        public IActionResult DeliveryRequest(string requestId)
        {
            try
            {
                var isRequestIdParsed = Guid.TryParse(requestId, out Guid guidRequestId);

                if (!isRequestIdParsed)
                {
                    return GenerateBadResult("Incorrect request id");
                }

                if (!_deliveryService.IsDeliveryRequestExists(guidRequestId))
                {
                    return GenerateBadResult(new { isRequestMissing = true });
                }

                var deliveryRequestDetails = _deliveryService.GetDeliveryRequestById(guidRequestId, _amazonS3Provider, _webClientAppConfig.Url);
                int initialIndex = 1;
                var deliveryRequestViewModel = new DeliveryRequestViewModel(deliveryRequestDetails, DEFAULT_DATE_FORMAT, _defaultFormatProvider, ref initialIndex);

                return GenerateOkResult(deliveryRequestViewModel);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult("Some error occurred");
            }

        }

        // POST api/delivery/updateitemstatus
        [HttpPost("updateitemstatus")]
        public IActionResult UpdateItemStatus([FromBody]UpdateItemStatusViewModel updateItemStatusModel)
        {
            try
            {
                var isItemIdParsed = Guid.TryParse(updateItemStatusModel.ItemId, out Guid guidId);

                if (!isItemIdParsed)
                {
                    return GenerateBadResult("Invalid itemid");
                }

                var isStatusParsed = Enum.TryParse(updateItemStatusModel.StatusId.ToString(), out DeliveryRequestItemStatus enumStatus);

                if (!isStatusParsed)
                {
                    return GenerateBadResult("Invalid status");
                }

                var isRequestIdParsed = Guid.TryParse(updateItemStatusModel.RequestId, out Guid guidRequestId);

                if (!isRequestIdParsed)
                {
                    return GenerateBadResult("Incorrect request id");
                }

                if (!_deliveryService.IsDeliveryRequestExists(guidRequestId))
                {
                    return GenerateBadResult(new { isRequestMissing = true });
                }

                _deliveryService.SetStatusToDeliveryRequestItem(guidId, enumStatus);

                return GenerateOkResult(null);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult("Some error occurred");
            }
        }

        // POST api/delivery/updaterequeststatus
        [HttpPost("updaterequeststatus")]
        public IActionResult UpdateRequestStatus([FromBody]UpdateRequestStatusViewModel updateRequestStatusModel)
        {
            try
            {
                var isRequestIdParsed = Guid.TryParse(updateRequestStatusModel.RequestId, out Guid guidRequestId);

                if (!isRequestIdParsed)
                {
                    return GenerateBadResult("Invalid requestid");
                }

                var isStatusParsed = Enum.TryParse(updateRequestStatusModel.StatusId.ToString(), out DeliveryRequestStatus enumStatus);

                if (!isStatusParsed)
                {
                    return GenerateBadResult("Invalid status");
                }

                if (!_deliveryService.IsDeliveryRequestExists(guidRequestId))
                {
                    return GenerateBadResult(new { isRequestMissing = true });
                }

                _deliveryService.SetStatusToDeliveryRequest(guidRequestId, enumStatus, _emailService, isAdministrationManagement: true);

                return GenerateOkResult(null);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult("Some error occurred");
            }

        }

        // GET api/delivery/deleterequest
        [HttpPost("deleterequest")]
        public IActionResult DeleteRequest([FromBody]DeleteDeliveryRequestViewModel deleteRequestModel)
        {
            try
            {
                var isRequestIdParsed = Guid.TryParse(deleteRequestModel.RequestId, out Guid guidRequestId);

                if (!isRequestIdParsed)
                {
                    return GenerateBadResult("Invalid requestid");
                }

                if (!_deliveryService.IsDeliveryRequestExists(guidRequestId))
                {
                    return GenerateBadResult(new { isRequestMissing = true });
                }

                _deliveryService.RemoveDeliveryRequest(guidRequestId, true);

                return GenerateOkResult(null);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult(ex.Message);
            }
        }

        // GET api/delivery/isrequestexists
        [HttpGet("isrequestexists")]
        public IActionResult IsRequestExists(string requestId)
        {
            try
            {
                var isRequestIdParsed = Guid.TryParse(requestId, out Guid guidRequestId);

                if (!isRequestIdParsed)
                {
                    return GenerateBadResult("Invalid requestid");
                }

                if (_deliveryService.IsDeliveryRequestExists(guidRequestId))
                {
                    return GenerateOkResult(new { isRequestMissing = false });
                }

                return GenerateOkResult(new { isRequestMissing = true });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult(ex.Message);
            }

        }

        [HttpGet("getrequestcsv")]
        public IActionResult GetRequestCsv(string requestId)
        {
            try
            {
                var baseUri = new Uri(_webClientAppConfig.Url);
                var itemUrlTemplate = new Uri(baseUri, "itemMediaId").ToString();

                return GenerateOkResult(new { fileData = _deliveryService.GetRequestDataCSV(requestId, itemUrlTemplate, _requestDataCSVGenerator, CSV_DATE_FORMAT, _defaultFormatProvider), fileType = "text/csv", fileName = $"{requestId}.csv" });
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult("Some error occured");
            }
        }

        // POST api/delivery/updatenote
        [HttpPost("updatenote")]
        public IActionResult UpdateNote([FromBody]UpdateNoteViewModel updateNoteModel)
        {
            try
            {
                var guidRequestId = Guid.TryParse(updateNoteModel.RequestId, out Guid guidId);

                if (!guidRequestId)
                {
                    return GenerateBadResult("Invalid itemid");
                }

                if (updateNoteModel.Note.Length > DELIVERY_REQUEST_NOTE_MAXIMUM_LENGTH)
                {
                    return GenerateBadResult($"The note can not be more than {DELIVERY_REQUEST_NOTE_MAXIMUM_LENGTH} characters");
                }

                if (!_deliveryService.IsDeliveryRequestExists(guidId))
                {
                    return GenerateBadResult(new { isRequestMissing = true });
                }

                _deliveryService.UpdateDeliveryRequestAdminNote(guidId, updateNoteModel.Note);

                return GenerateOkResult(null);
            }
            catch (Exception ex)
            {
                Logger.Instance.Error(ex.Message, ex);
                return GenerateBadResult("Some error occurred");
            }
        }
    }
}
