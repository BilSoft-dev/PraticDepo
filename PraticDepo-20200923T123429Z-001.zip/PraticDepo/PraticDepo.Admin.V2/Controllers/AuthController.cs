﻿using System;
using System.Linq;
using System.Threading.Tasks;
using PraticDepo.Admin.V2.Models.Account;
using PraticDepo.BusinessLayer.V2.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace PraticDepo.Admin.V2.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
    [AllowAnonymous]
    public class AuthController : BaseController
    {
        private readonly ITokenService _tokenService;

        public AuthController(ITokenService tokenService, IUserService userService) : base(userService)
        {
            _tokenService = tokenService;
        }

        // POST api/auth/login
        [HttpPost("login")]
        public async Task<IActionResult> Post([FromBody]LoginViewModel credentials)
        {
            if (!ModelState.IsValid)
            {
                return GenerateBadResult(new { errorMessage = ModelState.Values.SelectMany(e => e.Errors).FirstOrDefault()?.ErrorMessage });
            }

            string errorMessage;
            bool isErrorPopup;
            credentials.Email = credentials.Email.ToLower();
            var isValid = _userService.VerifyUser(credentials.Email, credentials.Password, out errorMessage, out isErrorPopup);

            if (!isValid)
            {
                return GenerateBadResult(new { isPopup = isErrorPopup, errorMessage });
            }

            try
            {
                var userToken = await _tokenService.GenerateUserToken(credentials.Email);
                return GenerateOkResult(userToken);
            }
            catch(Exception ex)
            {
                return GenerateBadResult(new { errorMessage = ex.Message });
            }
        }
    }
}
