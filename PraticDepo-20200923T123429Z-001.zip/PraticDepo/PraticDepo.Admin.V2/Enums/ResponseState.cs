﻿namespace PraticDepo.Admin.V2.Enums
{
    public enum ResponseState
    {
        Error = 0,
        Success = 1
    }
}