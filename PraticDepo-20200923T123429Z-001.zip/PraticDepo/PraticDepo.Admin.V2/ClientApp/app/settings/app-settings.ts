﻿import { Injectable } from '@angular/core';
import { Response } from '@angular/http';
//import { EnvironmentType } from '../enums/environment-type';
import 'rxjs/add/operator/map';

export interface ISetting {
    webApiUrl: string,
    //environment: EnvironmentType,
    serverUrl: string
}

@Injectable()
export class AppSettings {
    public configuration: ISetting = {
        //environment: EnvironmentType.Dev,
        webApiUrl: "",
        serverUrl: ""
    };

    constructor() { }

    load(): void {
        //var baseUrl = document.getElementsByTagName('base')[0].getAttribute('href').valueOf();
        //this.configuration.webApiUrl = window.location.origin + baseUrl + "api";
        //this.configuration.environment = process.env.ENV === 'production' ? EnvironmentType.Production : EnvironmentType.Dev;
        //this.configuration.serverUrl = window.location.origin + baseUrl.substring(0, baseUrl.charAt(baseUrl.length - 1) == '/' ? baseUrl.length - 1 : baseUrl.length);
    }
}
