import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard'

import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { UserManageComponent } from './components/users/user-manage/user-manage-main.component';
import { UserListItemComponent } from './components/users/user-list-item/user-list-item.component';
import { AddEditUserComponent } from './components/users/add-edit-user/add-edit-user.component';
import { ResetPasswordComponent } from './components/users/reset-password/reset-password.component';
import { GetAmazonMediaComponent } from './components/users/get-amazon-media/get-amazon-media.component';
import { TransferCollectionComponent } from './components/users/transfer-collection/transfer-collection.component';

import { myAccountMainComponent } from './components/my-account/my-account-main.component';
import { myAccountGeneralComponent } from './components/my-account/my-account-general/my-account-general.component';
import { myAccountEmailComponent } from './components/my-account/my-account-email/my-account-email.component';
import { myAccountPasswordComponent } from './components/my-account/my-account-password/my-account-password.component';

import { CollectionManageComponent } from './components/collections/collections-manage/collections-manage-main.component';
import { CollectionListItemComponent } from './components/collections/collections-list-item/collections-list-item.component';
import { EditCollectionComponent } from './components/collections/edit-collection/edit-collection.component';

import { DeliveryManagementMainComponent } from './components/delivery-management/delivery-management-main/delivery-management-main.component';
import { DeliveryManagemenListItemComponent } from './components/delivery-management/delivery-management-list-item/delivery-management-list-item.component';
import { DeliveryManagementDetailsComponent } from './components/delivery-management/delivery-management-details/delivery-management-details.component';

import { ItemsMainComponent } from './components/items/items-main/items-main.component';
import { ItemsListItemComponent } from './components/items/items-list-item/items-list-item.component';


const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    {path: 'users',component: UserManageComponent,canActivate: [AuthGuard]},
    { path: 'users/user/add', canActivate: [AuthGuard], component: AddEditUserComponent, data: { title: 'Add new user', isEditMode: false } },
    { path: 'users/user/:id/edit', canActivate: [AuthGuard], component: AddEditUserComponent, data: { title: 'Edit user', isEditMode: true } },
    { path: 'login', component: LoginComponent },
    { path: 'users/user/:id/reset-password', canActivate: [AuthGuard], component: ResetPasswordComponent },
    { path: 'users/user/getamazonmediaurl/:id', component: GetAmazonMediaComponent },
    { path: 'my-account', canActivate: [AuthGuard], component: myAccountMainComponent },
    { path: 'users/user/:id/transfer-collection', canActivate: [AuthGuard], component: TransferCollectionComponent },
    { path: 'collections', component: CollectionManageComponent, canActivate: [AuthGuard] },
    { path: 'collections/collection/:id/edit', canActivate: [AuthGuard], component: EditCollectionComponent, data: { title: 'Delivery requests', isEditMode: true } },
    { path: 'delivery-requests', component: DeliveryManagementMainComponent, canActivate: [AuthGuard] },
    { path: 'delivery-requests/request/:id', canActivate: [AuthGuard], component: DeliveryManagementDetailsComponent, data: { title: 'Delivery request', isEditMode: true } },
    { path: 'items', component: ItemsMainComponent, canActivate: [AuthGuard] },
    { path: '**', redirectTo: 'home' }
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ]
})

export class AppRoutingModule { } 