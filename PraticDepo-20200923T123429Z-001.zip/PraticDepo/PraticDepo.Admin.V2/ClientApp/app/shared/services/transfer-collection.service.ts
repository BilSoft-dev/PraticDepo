﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { ConfigService } from '../utils/config.service';

import { Observable } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/Rx';

import { BaseService } from './base.service';

@Injectable()

export class TransferCollectionService extends BaseService{
    serviceUrl: string = '';

    constructor(private http: Http, configService: ConfigService) {
        super(configService);

        this.serviceUrl = this.getBaseUrl() + '/collectiontransfer';
    }

    getUserCollectionsById(userId: string) {
        return this.http
            .get(
            this.serviceUrl + '/collectionsbyid',
            {
                params: {
                    userId: userId
                },
                headers: this.getBaseHttpHeaders()
            }).map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }

    getUserLocationsById(userId: string) {
        return this.http
            .get(
            this.serviceUrl + '/locationsbyid',
            {
                params: {
                    userId: userId
                },
                headers: this.getBaseHttpHeaders()
            }).map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }

    getUserLocationsByEmail(email: string) {
        return this.http
            .post(
            this.serviceUrl + '/locationsbyemail',
            JSON.stringify({
                email
            }), { headers: this.getBaseHttpHeaders() })
            .map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }

    transferUserCollections(sourceUserId: string, targetUserEmail: string, collectionToTransferIds: string[], locationToTransferId: string) {
        return this.http
            .post(
            this.serviceUrl + '/transfer',
            JSON.stringify({
                sourceUserId, targetUserEmail, collectionToTransferIds, locationToTransferId
            }), { headers: this.getBaseHttpHeaders() }
            )
            .map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }
}