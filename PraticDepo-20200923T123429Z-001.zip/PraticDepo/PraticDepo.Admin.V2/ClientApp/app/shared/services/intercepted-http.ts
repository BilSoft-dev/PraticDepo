﻿/*
import { Injectable, Injector } from "@angular/core";
import { HttpHandler, HttpInterceptor, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from "rxjs/Rx";
import { AppSettings } from "../../settings/app-settings";
import { AuthService } from "./auth-service";

@Injectable()
export class InterceptedHttp implements HttpInterceptor {

    readonly authenticationConstants: any = {
        ACCESS_TOKEN: "AccessToken",
        REFRESH_TOKEN: "RefreshToken",
        TOKEN_TYPE: "TokenType",
        INVALID_TOKEN: "InvalidToken",
        EXPAIRED_ACCESS_TOKEN: "ExpairedAccessToken"
    }

    private authService: AuthService;
    constructor(private appSettings: AppSettings, private injector: Injector) {

    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        request = this.getRequest(request);

        return next.handle(request).catch((initError) => {
            if (initError.status === 401 && initError.statusText === this.authenticationConstants.EXPAIRED_ACCESS_TOKEN) {
                return this.refreshToken().flatMap((data: Response) => {
                    if (data !== null) {
                        this.updateTokenInfo(data);
                        request = this.getRequest(request);
                        return next.handle(request);
                    }
                    return Observable.throw(initError);
                });
            } else {
                if (initError.status === 401) {
                    window.location.href = (location.hostname === "localhost" || location.hostname === "127.0.0.1" ? "/Admin/Account/Logout" : "/Admin/Logout");
                }
            }
        });
    }

    private getRequest(request: HttpRequest<any>): HttpRequest<any> {
        let accessToken = window.localStorage.getItem(this.authenticationConstants.ACCESS_TOKEN);
        let tokenType = window.localStorage.getItem(this.authenticationConstants.TOKEN_TYPE);

        return request.clone({
            setHeaders: {
                Authorization: `${tokenType} ${accessToken}`
            }
        });
    }


    private refreshToken(): Observable<any> {
        let authService = this.injector.get(AuthService);
        return authService.refreshToken(this.authenticationConstants.REFRESH_TOKEN);
    }

    private updateTokenInfo(tokenInfo: any): void {
        let localStorage = window.localStorage;

        localStorage.setItem(this.authenticationConstants.ACCESS_TOKEN, tokenInfo.AccessToken);
        localStorage.setItem(this.authenticationConstants.REFRESH_TOKEN, tokenInfo.RefreshToken);
        localStorage.setItem(this.authenticationConstants.TOKEN_TYPE, tokenInfo.TokenType);
    }
}
*/