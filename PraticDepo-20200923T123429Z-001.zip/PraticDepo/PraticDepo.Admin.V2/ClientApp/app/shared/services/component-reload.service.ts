﻿
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class ComponentReloadService {

    private notification: Subject<any> = new Subject();

    onReloadRequire(): Subject<any> {
        return this.notification;
    }

    requestReload() {
        this.notification.next();
    }
}
