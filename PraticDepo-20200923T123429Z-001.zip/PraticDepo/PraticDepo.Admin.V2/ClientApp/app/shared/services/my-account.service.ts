﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { ConfigService } from '../utils/config.service';

import { Observable } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/Rx';

import { BaseService } from './base.service';

@Injectable()

export class MyAccountService extends BaseService {

    serviceUrl: string = '';

    constructor(private http: Http, configService: ConfigService) {
        super(configService);

        this.serviceUrl = this.getBaseUrl() + '/account';
    }

    getAccountDetails(userId: string) {
        return this.http
            .get(
            this.serviceUrl + '/details',
            {
                params: {
                    id: userId
                }
            }).map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }

    editGeneralUserInfo(userId: string, firstName: string, lastName: string, phoneNumber: string) {
        return this.http
            .post(
            this.serviceUrl + '/editgeneral',
            JSON.stringify({
                firstName, lastName, phoneNumber, userId
            }), { headers: this.getBaseHttpHeaders() }
            )
            .map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }

    editUserEmail(userId: string, email: string, confirmEmail: string) {
        return this.http
            .post(
            this.serviceUrl + '/editemail',
            JSON.stringify({
                email, confirmEmail, userId
            }), { headers: this.getBaseHttpHeaders() }
            )
            .map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }

    editUserPassword(userId: string, oldPassword: string, password: string, confirmPassword: string) {
        return this.http
            .post(
            this.serviceUrl + '/editpassword',
            JSON.stringify({
                oldPassword, password, confirmPassword, userId
            }), { headers: this.getBaseHttpHeaders() }
            )
            .map(result => {
                return result.json();
            })
            .map(result => {
                if (result.status === 1) {
                    return { success: true, data: result.data };
                }
                else {
                    return { success: false, data: result.data };
                }
            });
    }
}