﻿import { AbstractControl } from '@angular/forms';

export class ValidationMessages {

    static RequiredShort(): string {
        return 'required';
    }

    static Required(fieldName: string): string {
        return `${fieldName} is required`;
    }

    static EmailFormat(fieldName: string): string {
        return `${fieldName} has incorrect format`;
    }

    static ValidateEqual(fieldName: string): string {
        return `${fieldName} mismatch`;
    }

    static minLength(fieldName: string, control: AbstractControl): string {
        if (control && control.errors && control.errors['minlength']) {
            return `${fieldName} must be at least ${control.errors['minlength'].requiredLength} characters long`;
        }

        return '';
    }

    static maxLength(fieldName: string, control: AbstractControl): string {
        if (control && control.errors && control.errors['maxlength']) {
            return `${fieldName} should not be more than ${control.errors['maxlength'].requiredLength} characters long`;
        }

        return '';
    }

    static maxLengthMessage(fieldName: string, maxLength: number): string {
        return `${fieldName} should not be more than ${maxLength} characters long`;
    }

    static minLengthMessage(fieldName: string, minLength: number): string {
        return `${fieldName} must be at least ${minLength} characters long`;
    }

    static alphaNumeric(fieldName: string): string {
        return `${fieldName} must be alpha-numeric characters`;
    }

    static minimumValue(fieldName: string, val:any): string {
        return `${fieldName} should be ${val} or more`;
    }

    static maximumValue(fieldName: string, val:any): string {
        return `${fieldName} should be ${val} or less`;
    }

    static invalidFormat(fieldName: string) {
        return `${fieldName} has incorrect format`;
    }

    static invalidFormatShort() {
        return `incorect format`;
    }

    static existEmail() {
        return `Email address already exists`;
    }
}