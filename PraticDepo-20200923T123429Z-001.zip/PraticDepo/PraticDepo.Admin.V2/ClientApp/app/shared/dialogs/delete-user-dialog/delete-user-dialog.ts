﻿import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    templateUrl: './delete-user-dialog.html',
    selector: 'delete-user-dialog',
})
export class DeleteUserDialogComponent implements OnInit {
    constructor(public dialogRef: MatDialogRef<DeleteUserDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: string) {
    }
    ngOnInit() {
    }
    onDeleteConfirm() {
        this.dialogRef.close('Delete');
    }
    onCloseCancel() {
        this.dialogRef.close('Cancel');
    }
}