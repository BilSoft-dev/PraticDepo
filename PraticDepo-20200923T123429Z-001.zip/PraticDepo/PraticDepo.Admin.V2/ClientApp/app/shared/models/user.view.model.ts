﻿import { RoleViewModel } from './role.view.model'
import { ApiResponse } from './api.response.model'

export class UserViewModel {
    userId: string;
    firstName: string;
    lastName: string;
    role: string;
    email: string;
    phoneNumber: string;
    allRoles: RoleViewModel[];
    createdAt: string;

    constructor() {
        this.userId = '';
        this.firstName = '';
        this.lastName = '';
        this.role = '';
        this.email = '';
        this.phoneNumber = '';
        this.createdAt = '';
    }
}