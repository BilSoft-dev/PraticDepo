﻿export class ApiResponse {
    data: any;
    status: any;

    constructor(data: any, status: string) {
        this.data = data;
        this.status = status;
    }
}