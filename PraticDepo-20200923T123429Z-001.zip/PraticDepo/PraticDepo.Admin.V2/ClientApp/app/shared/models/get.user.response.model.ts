﻿import { UserViewModel } from './user.view.model'
import { ApiResponse } from './api.response.model'

export class GetUserApiResponse extends ApiResponse {
    constructor(userViewModel: UserViewModel, status: any) {
        super(userViewModel, status)
    }
}