﻿import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppSettings } from '../settings/app-settings';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from "../app-routes.module";
import { OverlayModule } from '@angular/cdk/overlay';
import { MatButtonModule, MatCheckboxModule, MatProgressSpinnerModule,  MatInputModule, MatIconModule, MatSelectModule, MatPaginatorModule, MatDialogModule, MatRadioModule } from '@angular/material';
import { OkCancelDialogComponent } from './dialogs/ok-cancel-dialog/ok-cancel-dialog.component';
import { OkDialogComponent } from './dialogs/ok-dialog/ok-dialog.component';
import { YesNoDialogComponent } from './dialogs/yes-no-dialog/yes-no-dialog.component';
import { DeleteUserDialogComponent } from './dialogs/delete-user-dialog/delete-user-dialog';
import { ConfigService } from './utils/config.service';
import { CommonService } from './utils/common.service'
import { ComponentReloadService } from './services/component-reload.service'

@NgModule({
    imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatButtonModule,
        MatCheckboxModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatPaginatorModule,
        MatDialogModule,
        MatRadioModule,
        OverlayModule,
        MatProgressSpinnerModule,
        AppRoutingModule
    ],
    exports: [
        MatButtonModule,
        MatCheckboxModule,
        MatInputModule,
        MatIconModule,
        MatSelectModule,
        MatPaginatorModule,
        MatDialogModule,
        MatRadioModule,
        MatProgressSpinnerModule,
        AppRoutingModule
    ],
    declarations: [

        OkCancelDialogComponent,
        OkDialogComponent,
        YesNoDialogComponent,
        DeleteUserDialogComponent,
    ],
    providers: [
        { provide: AppSettings, useClass: AppSettings },
        { provide: ConfigService, useClass: ConfigService },
        { provide: CommonService, useClass: CommonService },
        { provide: ComponentReloadService, useClass: ComponentReloadService }
    ],
    entryComponents: [OkCancelDialogComponent, OkDialogComponent, YesNoDialogComponent, DeleteUserDialogComponent]

})
export class SharedModule { }

