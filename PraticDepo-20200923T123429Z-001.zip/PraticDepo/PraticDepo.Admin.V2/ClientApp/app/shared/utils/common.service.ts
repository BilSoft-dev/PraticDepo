﻿import { Injectable } from '@angular/core';

@Injectable()
export class CommonService {

    downloadFile(data: any) {
        var dispositionHeader = data.headers.get('content-disposition');
        var filename = '';

        var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
        var matches = filenameRegex.exec(dispositionHeader);
        if (matches != null && matches[1]) {
            filename = matches[1].replace(/['"]/g, '');
        }

        var blob = new Blob([data._body], { type: 'text/csv' });

        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = filename;
        link.click();
    }
}
