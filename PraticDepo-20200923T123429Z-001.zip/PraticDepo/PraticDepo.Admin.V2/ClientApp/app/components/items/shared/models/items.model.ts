﻿export class ItemsModel {
    itemImageUrl: string;
    itemImageLink: string;
    itemBarcode: string;
    itemOwners: ItemOwnerModel[];
    itemOwnerEmail: string;
    itemCreator: string;
    itemCreatorEmail: string;
    itemName: string;
    itemStatus: number;
    itemVolume: string;
    itemCreatedDate: string;
    collectionBarcode: string;
    collectionUnitNumber: string;
    collectionName: string;
    collectionVolume: string;
    collectionCreatedDate: string;
    collectionNotes: string;
    collectionLocationName: string;
    collectionRoomName: string;
    collectionRoomPartName: string;
    collectionPhotoLink: string;

    constructor() {
        this.itemImageUrl = '';
        this.itemImageLink = '';
        this.itemBarcode = '';
        this.itemOwners = [];
        this.itemOwnerEmail = '';
        this.itemCreator = '';
        this.itemCreatorEmail = '';
        this.itemName = '';
        this.itemStatus = -1;
        this.itemVolume = '';
        this.itemCreatedDate = '';
        this.collectionBarcode = '';
        this.collectionUnitNumber = '';
        this.collectionName = '';
        this.collectionVolume = '';
        this.collectionCreatedDate ='';
        this.collectionNotes = '';
        this.collectionLocationName = '';
        this.collectionRoomName = '';
        this.collectionRoomPartName = '';
        this.collectionPhotoLink = '';
    }
}

export class ItemOwnerModel {
    itemOwnerEmail: string;
    itemOwnerFirstName: string;
    itemOwnerLastName: string;

    constructor() {
        this.itemOwnerEmail = '';
        this.itemOwnerFirstName = '';
        this.itemOwnerLastName = '';
    }
}