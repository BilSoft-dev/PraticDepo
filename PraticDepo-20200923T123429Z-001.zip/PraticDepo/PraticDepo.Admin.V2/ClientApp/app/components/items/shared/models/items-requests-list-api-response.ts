﻿import { ItemsRequestsListViewModel } from './items-requests-list-view-model'
import { ApiResponse } from '../../../../shared/models/api.response.model'

export class ItemsRequestsListApiResponse extends ApiResponse {
    constructor(itemsRequestsList: ItemsRequestsListViewModel, status: any) {
        super(itemsRequestsList, status)
    }
}