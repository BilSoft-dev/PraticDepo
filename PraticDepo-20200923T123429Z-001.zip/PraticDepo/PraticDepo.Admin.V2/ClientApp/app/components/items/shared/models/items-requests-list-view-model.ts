﻿import { PagerModel } from '../../../../shared/models/pager.model'
import { ItemsModel } from "./items.model";

export class ItemsRequestsListViewModel {
    pager: PagerModel;
    itemsRequests: ItemsModel[];

    constructor(pager: PagerModel, itemsRequests: ItemsModel[]) {
        this.pager = pager;
        this.itemsRequests = itemsRequests;
    }
}