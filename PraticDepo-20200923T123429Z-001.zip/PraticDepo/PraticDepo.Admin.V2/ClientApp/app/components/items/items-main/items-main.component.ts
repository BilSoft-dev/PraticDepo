﻿import { Component, Output, EventEmitter } from '@angular/core';
import { ItemsModel } from "../shared/models";
import { ItemsService } from '../../../shared/services/items.service'
import { UserListApiResponse } from '../../../shared/models/userlist.response.model'
import { OkCancelDialogComponent } from '../../../shared/dialogs/ok-cancel-dialog/ok-cancel-dialog.component'

@Component({
    selector: 'items-main',
    templateUrl: './items-main.component.html'
})


export class ItemsMainComponent {
    search: string;
    //names: any;
    acsendings: any;
    selectedValue: string;
    totalElements: number;
    selectedValueAcsending: string;
    selectedValueFilter: string;
    length: number;
    pageIndex: number;
    pageSize: number;
    private defaultOrder: string;
    private defaultFilter: string;
    private userSubmittedFilter: string;
    private defaultPageIndex: number;
    serverError: any;
    itemsRequestsList: ItemsModel[];
    itemStatuses: any;
    itemNotPickedStatus: number;
    itemPickedStatus: number;
    itemReturnedStatus: number;
    itemCancelledStatus: number;
    itemNotSubmittedStatus: number;

    constructor(private itemsService: ItemsService) {
        this.defaultOrder = 'desc';
        this.defaultFilter = 'created';
        this.userSubmittedFilter = '';
        this.defaultPageIndex = 0;
        this.itemNotSubmittedStatus = 0;
        this.itemNotPickedStatus = 1;
        this.itemPickedStatus = 2;
        this.itemReturnedStatus = 3;
        this.itemCancelledStatus = 4;
    }

    ngOnInit() {
        this.pageSize = 40;
        this.pageIndex = this.defaultPageIndex;

        let localSelectedFilter = sessionStorage.getItem('selectedValueFilter');

        if (localSelectedFilter !== null && localSelectedFilter !== '') {
            this.selectedValueFilter = localSelectedFilter;
        }
        else {
            sessionStorage.setItem('selectedValueFilter', this.defaultFilter);
            this.selectedValueFilter = this.defaultFilter;
        }

        let localSelectedAcsending = sessionStorage.getItem('selectedValueAcsending');

        if (localSelectedAcsending !== null && localSelectedAcsending !== '') {
            this.selectedValueAcsending = localSelectedAcsending;
        }
        else {
            sessionStorage.setItem('selectedValueAcsending', this.defaultOrder);
            this.selectedValueAcsending = this.defaultOrder;
        }

        this.acsendings = [
            { value: 'asc', viewValue: 'Ascending' },
            { value: 'desc', viewValue: 'Descending' }
        ];

        this.itemStatuses = [
            { value: this.itemNotPickedStatus, viewValue: 'Not Picked' },
            { value: this.itemPickedStatus, viewValue: 'Picked' },
            { value: this.itemReturnedStatus, viewValue: 'Returned' },
            { value: this.itemCancelledStatus, viewValue: 'Cancelled' },
            { value: this.itemNotSubmittedStatus, viewValue: 'Not Submitted' }
        ];

        this.getItemsRequests(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);       
    }

    orderChanged() {        
        sessionStorage.setItem('selectedValueAcsending', this.selectedValueAcsending);
        this.getItemsRequests(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);
    }

    sortFieldChanged() {     
        sessionStorage.setItem('selectedValueFilter', this.selectedValueFilter);
        this.getItemsRequests(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);
    }

    getItemsRequests(pageIndex: number, pageSize: number, sortingField: string, pageSort: string, filter: string) {

        this.itemsService.getItemsRequests(pageIndex, pageSize, sortingField, pageSort, filter).subscribe(
            result => {
                if (result.status === 1) {
                    this.itemsRequestsList = result.data.entities;
                    console.log(result.data.entities);

                    this.length = result.data.pager.totalCount;
                    this.serverError = '';
                }
                else {
                    this.serverError = result.data;
                }
            },
            error => {
                this.serverError = 'Some error occured.'
            });
    }

    pagerChanged(event: any) {
      
        this.length = event.length;
        this.pageIndex = event.pageIndex;
        this.pageSize = event.pageSize;

        this.getItemsRequests(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);
    }

    filterChanged() {
        this.userSubmittedFilter = this.search;
        this.pageIndex = this.defaultPageIndex;
        this.getItemsRequests(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);
    }

    clearSearch() {
        this.search = '';
        this.userSubmittedFilter = '';
        this.getItemsRequests(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);
    }

    reloadDeliveryRequests() {
        this.getItemsRequests(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);
    }

    checkClass() {

    }

    showError(error: any) {
        this.serverError = error;
    }
}
