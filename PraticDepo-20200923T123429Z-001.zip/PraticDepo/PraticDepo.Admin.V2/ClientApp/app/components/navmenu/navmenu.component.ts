import { Component } from '@angular/core';
import { AuthService } from '../../shared/services/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Subject';

@Component({
    selector: 'nav-menu',
    templateUrl: './navmenu.component.html'
})
export class NavMenuComponent {
    loggedIn: any;
    public static UpdateUserStatus: Subject<boolean> = new Subject();

    constructor(private authService: AuthService, private router: Router) {
        NavMenuComponent.UpdateUserStatus.subscribe(res => {
            this.loggedIn = false;
        })
    }

    ngOnInit() {
        this.loggedIn = localStorage.getItem('auth_token');
    }

    isLogout() {
        this.authService.logout();
        this.loggedIn = this.authService.isLoggedIn();
    }
}

