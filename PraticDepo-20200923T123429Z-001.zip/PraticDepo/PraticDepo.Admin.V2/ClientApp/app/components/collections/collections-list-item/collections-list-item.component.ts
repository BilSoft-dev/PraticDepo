﻿import { Router } from '@angular/router';
import { Component, Input, OnInit, Inject } from '@angular/core';
import { CollectionModel } from "../shared/models";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OkDialogComponent } from '../../../shared/dialogs/ok-dialog/ok-dialog.component'
import { OkCancelDialogComponent } from '../../../shared/dialogs/ok-cancel-dialog/ok-cancel-dialog.component'
import { UserService } from '../../../shared/services/users.service'
import { DeleteUserDialogComponent } from '../../../shared/dialogs/delete-user-dialog/delete-user-dialog'

@Component({
    selector: 'collections-list-item',
    templateUrl: './collections-list-item.component.html'
})


export class CollectionListItemComponent {
    @Input() collection: CollectionModel;

    constructor(private router: Router, private userService: UserService, private dialog: MatDialog) { }

    ngOnInit() {
        
    }
  

    deleteClicked() {
        //var userFirstName = this.user.firstName === null ? '' : this.user.firstName + ' ';
        //var userLastName = this.user.lastName === null ? '' : this.user.lastName + ' ';

        //let dialogRef = this.dialog.open(DeleteUserDialogComponent, {
        //    data: 'Are you sure you want to delete user ' + userFirstName
        //        + userLastName + '(' + this.user.email + ')?'
        //});

        //dialogRef.afterClosed()
        //    .pipe(name => name)
        //    .subscribe(name => {
        //        if (name === 'Delete') {
        //            this.deleteUser();
        //        }
        //    });
    }

    deleteUser() {
        //this.userService.deleteUser(this.user.userId).subscribe(result => {
        //    if (result.success) {
        //        window.open('/users', '_self');
        //        this.router.navigate(['/users']);
        //    }
        //    else {
        //        var dialogRef;

        //        if (result.data.isUserMissing) {
        //            dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
        //            dialogRef.afterClosed().subscribe(x => {
        //                this.router.navigate(['/users']);
        //            })
        //        }
        //        else {
        //            dialogRef = this.dialog.open(OkDialogComponent, { data: result.data });
        //        }
        //    }
        //},
        //    error => {
        //        let dialogRef = this.dialog.open(OkDialogComponent, { data: 'Some error occured.' });
        //    })
    }

    exportToCSVClicked() {
        //this.userService.getUserDataCSV(this.user.userId).subscribe(
        //    result => {
        //        if (result.success) {
        //            var blob = new Blob([result.data.fileData], { type: result.data.fileType });

        //            var link = document.createElement('a');
        //            link.href = window.URL.createObjectURL(blob);
        //            link.download = result.data.fileName;
        //            let csvContainer = document.getElementById('csvContainer');
        //            if (csvContainer != null) {
        //                csvContainer.appendChild(link)
        //            }
        //            link.click();

        //            this.downloadFile(result)
        //        }
        //        else {
        //            var dialogRef;

        //            if (result.data.isUserMissing) {
        //                dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
        //                dialogRef.afterClosed().subscribe(x => { this.router.navigate(['/users']); })
        //            }
        //            else {
        //                dialogRef = this.dialog.open(OkDialogComponent, { data: result.data })
        //            }
        //        }
        //    },
        //    error => {
        //        let dialogRef = this.dialog.open(OkDialogComponent, { data: 'Some error occured.' });
        //    });
    }

    downloadFile(data: any) {
        //var test = data.headers.get('content-disposition');
        //var filename = '';

        //var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
        //var matches = filenameRegex.exec(test);
        //if (matches != null && matches[1]) {
        //    filename = matches[1].replace(/['"]/g, '');
        //}

        //var blob = new Blob([data._body], { type: 'text/csv' });

        //var link = document.createElement('a');
        //link.href = window.URL.createObjectURL(blob);
        //link.download = filename;
        //link.click();
    }
}
