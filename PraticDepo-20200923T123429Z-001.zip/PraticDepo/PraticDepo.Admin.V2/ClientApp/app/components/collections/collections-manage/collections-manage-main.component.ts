﻿import { Component } from '@angular/core';
import { CollectionModel } from "../shared/models";
import { UserService } from '../../../shared/services/users.service'
import { UserListApiResponse } from '../../../shared/models/userlist.response.model'
import { OkCancelDialogComponent } from '../../../shared/dialogs/ok-cancel-dialog/ok-cancel-dialog.component'

@Component({
    selector: 'collection-manage',
    templateUrl: './collections-manage-main.component.html'
})


export class CollectionManageComponent {
    search: string;
    names: any;
    acsendings: any;
    selectedValue: string;
    totalElements: number;
    selectedValueAcsending: string;
    selectedValueFilter: string;
    length: number;
    pageIndex: number;
    pageSize: number;
    private defaultOrder: string;
    private defaultFilter: string;
    private userSubmittedFilter: string;
    private defaultPageIndex: number;
    serverError: any;
    collectionList: CollectionModel[];

    constructor(private userService: UserService) {
        this.defaultOrder = 'asc';
        this.defaultFilter = 'firstName';
        this.userSubmittedFilter = '';
        this.defaultPageIndex = 0;
    }

    ngOnInit() {
        this.pageSize = 40;
        this.pageIndex = this.defaultPageIndex;

        let localSelectedFilter = sessionStorage.getItem('selectedValueFilter');

        if (localSelectedFilter !== null && localSelectedFilter !== '') {
            this.selectedValueFilter = localSelectedFilter;
        }
        else {
            sessionStorage.setItem('selectedValueFilter', this.defaultFilter);
            this.selectedValueFilter = this.defaultFilter;
        }

        let localSelectedAcsending = sessionStorage.getItem('selectedValueAcsending');

        if (localSelectedAcsending !== null && localSelectedAcsending !== '') {
            this.selectedValueAcsending = localSelectedAcsending;
        }
        else {
            sessionStorage.setItem('selectedValueAcsending', this.defaultOrder);
            this.selectedValueAcsending = this.defaultOrder;
        }

        this.names = [
            { value: 'firstName', viewValue: 'First Name' },
            { value: 'lastName', viewValue: 'Last Name' },
            { value: 'email', viewValue: 'Email' },
            { value: 'CreatedAt', viewValue: 'Date Created' }
        ];
        this.acsendings = [
            { value: 'asc', viewValue: 'Ascending' },
            { value: 'desc', viewValue: 'Descending' }
        ];

        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);
    }
    orderChanged() {        
        sessionStorage.setItem('selectedValueAcsending', this.selectedValueAcsending);
        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.userSubmittedFilter);
    }

    sortFieldChanged() {     
        sessionStorage.setItem('selectedValueFilter', this.selectedValueFilter);
        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.userSubmittedFilter);
    }

    getUsers(pageIndex: number, pageSize: number, sortingField: string, pageSort: string, filter: string) {
        this.collectionList = [
            { collectionId: '123456789', collectionName: 'collectionName', collectionItemsCount: 1, ownerFirstName: 'ownerFirstName', ownerLastName: 'ownerLastName', ownerEmail: 'ownerEmail', locationName: 'locationName', collectionDateCreated: '12.12.2018', collectionSelected:true },
            { collectionId: '123456789', collectionName: 'collectionName', collectionItemsCount: 2, ownerFirstName: 'ownerFirstName', ownerLastName: 'ownerLastName', ownerEmail: 'ownerEmail', locationName: 'locationName', collectionDateCreated: '12.12.2018', collectionSelected: true },
            { collectionId: '123456789', collectionName: 'collectionName', collectionItemsCount: 3, ownerFirstName: 'ownerFirstName', ownerLastName: 'ownerLastName', ownerEmail: 'ownerEmail', locationName: 'locationName', collectionDateCreated: '12.12.2018', collectionSelected: true },
            { collectionId: '123456789', collectionName: 'collectionName', collectionItemsCount: 10, ownerFirstName: 'ownerFirstName', ownerLastName: 'ownerLastName', ownerEmail: 'ownerEmail', locationName: 'locationName', collectionDateCreated: '12.12.2018', collectionSelected: true },
            { collectionId: '123456789', collectionName: 'collectionName', collectionItemsCount: 23, ownerFirstName: 'ownerFirstName', ownerLastName: 'ownerLastName', ownerEmail: 'ownerEmail', locationName: 'locationName', collectionDateCreated: '12.12.2018', collectionSelected: true },
            { collectionId: '123456789', collectionName: 'collectionName', collectionItemsCount: 23, ownerFirstName: 'ownerFirstName', ownerLastName: 'ownerLastName', ownerEmail: 'ownerEmail', locationName: 'locationName', collectionDateCreated: '12.12.2018', collectionSelected: true },
            { collectionId: '123456789', collectionName: 'collectionName', collectionItemsCount: 23, ownerFirstName: 'ownerFirstName', ownerLastName: 'ownerLastName', ownerEmail: 'ownerEmail', locationName: 'locationName', collectionDateCreated: '12.12.2018', collectionSelected: true }
        ]

    }

    pagerChanged(event: any) {
      
        this.length = event.length;
        this.pageIndex = event.pageIndex;
        this.pageSize = event.pageSize;

        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.userSubmittedFilter);
    }

    filterChanged() {
        this.userSubmittedFilter = this.search;
        this.pageIndex = this.defaultPageIndex;
        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.userSubmittedFilter);
    }

    clearSearch() {
        this.search = '';
        this.userSubmittedFilter = '';
        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.userSubmittedFilter);
    }

    checkClass() {

    }
}
