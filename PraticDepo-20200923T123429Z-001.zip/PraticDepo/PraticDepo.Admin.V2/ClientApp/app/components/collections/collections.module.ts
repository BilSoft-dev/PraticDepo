﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { CollectionManageComponent } from './collections-manage/collections-manage-main.component';
import { CollectionListItemComponent } from './collections-list-item/collections-list-item.component';
import { EditCollectionComponent } from './edit-collection/edit-collection.component';

import { SharedModule } from "../../shared/shared.module";
import { UserService } from '../../shared/services/users.service';
import { AuthenticatedHttpService } from '../../AuthenticatedHttpService'
import { Http } from '@angular/http';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        BrowserModule,
        SharedModule
    ],    
    declarations: [
        CollectionManageComponent,
        CollectionListItemComponent,
        EditCollectionComponent
    ],
    exports: [
        CollectionManageComponent,
        CollectionListItemComponent,
        EditCollectionComponent
    ],
    providers: [
        UserService,
        { provide: Http, useClass: AuthenticatedHttpService }
    ],
})

export class CollectionsModule {
}