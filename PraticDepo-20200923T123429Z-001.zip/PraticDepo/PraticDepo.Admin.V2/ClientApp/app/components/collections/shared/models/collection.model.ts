﻿export class CollectionModel {
    collectionId: string;
    collectionName: string;
    collectionItemsCount: number;
    ownerFirstName: string;
    ownerLastName: string;
    ownerEmail: string;
    locationName: string;
    collectionDateCreated: string;
    collectionSelected: boolean;

    constructor() {
        this.collectionId = '';
        this.collectionName = '';
        this.collectionItemsCount = 0;
        this.ownerFirstName = '';
        this.ownerLastName = '';
        this.ownerEmail = '';
        this.locationName = '';
        this.collectionDateCreated = '';
        this.collectionSelected = true;
    }
}