﻿import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MainFormComponent } from "../../../shared/components/forms-component/main-form.component";
import { ValidationMessages } from "../../../shared/custom-validators/validation-messages";
import { Router, ActivatedRoute, Data, ParamMap } from '@angular/router';
import { forEach } from '@angular/router/src/utils/collection';
import 'rxjs/add/operator/switchMap';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OkDialogComponent } from '../../../shared/dialogs/ok-dialog/ok-dialog.component'
import { YesNoDialogComponent } from '../../../shared/dialogs/yes-no-dialog/yes-no-dialog.component'

@Component({
    selector: 'edit-collection',
    templateUrl: './edit-collection.component.html'
})
export class EditCollectionComponent extends MainFormComponent {
    title: any;
    collection: any;
    serverError: any;
    ownerInfo: any;
    private userId: any;
    isPhoneNumberDisabled: boolean = false;


    constructor(private router: Router, private activatedRoute: ActivatedRoute, private dialog: MatDialog) {
        super();

        this.collection = {
            collectionId: '123456789',
            collectionName: 'collectionName',
            ownerFirstName: 'ownerFirstName',
            ownerLastName: 'ownerLastName',
            ownerEmail: 'ownerEmail',
            locationName: 'locationName',
            room: 'room',
            roomPart: 'roomPart',
            barcode: '123456890',
            volume: '70',
            notes: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ',
            callaborators:[]
        }
        this.collection.callaborators.push({ firstName: 'FirstName', lastName: 'LastName', email: 'email@email' });
        this.collection.callaborators.push({ firstName: 'FirstName', lastName: 'LastName', email: 'email@email' });
        this.collection.callaborators.push({ firstName: 'FirstName', lastName: 'LastName', email: 'email@email' });
        this.ownerInfo = this.collection.ownerFirstName + ' ' + this.collection.ownerLastName + ' (' + this.collection.ownerEmail + ')';

        console.log(this.collection.callaborators);
    }

    ngOnInit() {
        this.title = this.activatedRoute.snapshot.data['title'];

        this.buildEditCollectionForm();
    }

    private buildEditCollectionForm(): void {
        this.mainFormGroup = new FormGroup({
            'collectionName': new FormControl(''),
            'locationName': new FormControl({ value: '', disabled: true }),
            'room': new FormControl({ value: '', disabled: true }),
            'roomPart': new FormControl({ value: '', disabled: true }),
            'barcode': new FormControl(''),
            'volume': new FormControl(''),
            'notes': new FormControl(''),
            'ownerInfo': new FormControl({ value:this.ownerInfo, disabled: true }),
        });
    }

    onEditFormSubmit(): void {

        if (this.mainFormGroup.invalid) {
            this.markFormElementsAsDirty(this.mainFormGroup, this.formErrors);
            this.collectErrorsForFormControl(this.mainFormGroup, this.formErrors);
            return;
        }

            this.editUser();
    }


    editUser(): void {
        //this.userService.editUser(this.userId, this.user.email, this.user.firstName,
        //    this.user.lastName, this.selectedRole, this.user.phoneNumber).subscribe(result => {
        //        var dialogRef;

        //        if (result.success) {
        //            dialogRef = this.dialog.open(OkDialogComponent, {
        //                data: 'The user has been successfully edited.'
        //            });

        //            dialogRef.afterClosed()
        //                .subscribe(x => {
        //                    this.router.navigate(['/users']);
        //                })
        //        }
        //        else {
        //            if (result.data.isUserMissing) {
        //                dialogRef = this.dialog.open(OkDialogComponent, {
        //                    data: result.data.errorMessage
        //                });

        //                dialogRef.afterClosed()
        //                    .subscribe(x => {
        //                        this.router.navigate(['/users']);
        //                    })
        //            }
        //            else {
        //                this.serverError = result.data
        //            }
        //        }
        //    },
        //    error => {
        //        this.serverError = 'Some error occured.'
        //    });
    }


    onCancelClick(): void{
        if (this.mainFormGroup.touched) {
            let dialogRef = this.dialog.open(YesNoDialogComponent, {
                data: 'Are you sure you want to leave the current page without saving?'
            });

            dialogRef.afterClosed()
                .pipe(name => name)
                .subscribe(name => {
                    if (name === 'Yes') {
                        this.router.navigate(['/collections']);
                    }
                })
        } else {
            this.router.navigate(['/collections']);
        }
    }
}