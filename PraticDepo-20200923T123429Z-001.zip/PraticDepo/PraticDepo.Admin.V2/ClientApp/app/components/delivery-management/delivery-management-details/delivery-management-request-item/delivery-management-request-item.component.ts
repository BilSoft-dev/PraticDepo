﻿import { Router } from '@angular/router';
import { Component, Input, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { DeliveryManagementDetailsModel, CollectionModel, ItemModel } from "../../shared/models";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DeliveryService } from '../../../../shared/services/delivery.service';

@Component({
    selector: 'delivery-management-request-item',
    templateUrl: './delivery-management-request-item.component.html'
})


export class DeliveryManagementRequestItemComponent {
    @Input() collection: CollectionModel;
    @Input() requestId: string;
    @Input() isRequestStatusFinal: boolean;
    @Input() requestStatusId: number;
    @Output('itemStatusChangedEvent') itemStatChangedEvent = new EventEmitter();

    @Input() itemStatuses: any;
    defaulStatus: any;
    @Input() requestStatusIdToItemStatusNameMap: any;
    @Input() collectionStatuses: any;

    constructor(private router: Router, private deliveryService: DeliveryService) { }

    ngOnInit() {
        this.defaulStatus = this.collection.collectionStatusId;
    }

    itemStatusChanged(event: any, itemId: string) {
        this.deliveryService.updateItemStatus(itemId, event.value, this.requestId).subscribe(
            result => {
                if (result.success) {
                    this.itemStatChangedEvent.emit();
                }
                else {
                    if (result.data.isRequestMissing) {
                        this.router.navigate(['/delivery-requests']);
                    }
                }
            });
    }
}
