﻿import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MainFormComponent } from "../../../shared/components/forms-component/main-form.component";
import { ValidationMessages } from "../../../shared/custom-validators/validation-messages";
import { Router, ActivatedRoute, Data, ParamMap } from '@angular/router';
import { forEach } from '@angular/router/src/utils/collection';
import 'rxjs/add/operator/switchMap';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OkDialogComponent } from '../../../shared/dialogs/ok-dialog/ok-dialog.component'
import { YesNoDialogComponent } from '../../../shared/dialogs/yes-no-dialog/yes-no-dialog.component'
import { DeliveryManagementDetailsModel, CollectionModel, ItemModel  } from "../shared/models";
import { DeliveryService } from '../../../shared/services/delivery.service';
import { OkCancelDialogComponent } from '../../../shared/dialogs/ok-cancel-dialog/ok-cancel-dialog.component'

@Component({
    selector: 'delivery-management-details',
    templateUrl: './delivery-management-details.component.html'
})
export class DeliveryManagementDetailsComponent extends MainFormComponent {
    title: any;
    collection: any;
    serverError: any;
    ownerInfo: any;
    statuses: any;
    selectedValueStatus: string = "";
    defaulStatus: any;
    deliveryRequestDetails: DeliveryManagementDetailsModel = new DeliveryManagementDetailsModel;
    isDeliveryRequestStatusFinal: boolean;
    requestOnDeliveryStatus: number;
    requestDeliveredStatus: number;
    requestCancelledStatus: number;
    currentRequestStatus: string = "";
    collectionNotPickedStatus: number;
    collectionPickedStatus: number;
    itemStatuses: any;
    requestStatusIdToItemStatusNameMap: any;
    collectionStatuses: any;
    itemNotPickedStatus: number;
    itemPickedStatus: number;
    collectionReturnedStatus: number;
    collectionCancelledStatus: number;
    requestSubmittedStatus: number;
    isRequestStatusSelectDisabled: boolean;
    adminNote: string;
    createdDate: string;

    constructor(private router: Router, private activatedRoute: ActivatedRoute, private dialog: MatDialog, private deliveryService: DeliveryService) {
        super();

        this.requestOnDeliveryStatus = 1;
        this.requestDeliveredStatus = 2;
        this.requestCancelledStatus = 3;
        this.requestSubmittedStatus = 4;

        this.statuses = [
            { value: this.requestSubmittedStatus, viewValue: 'Submitted' },
            { value: this.requestOnDeliveryStatus, viewValue: 'On delivery' },
            { value: this.requestDeliveredStatus, viewValue: 'Delivered' },
            { value: this.requestCancelledStatus, viewValue: 'Cancelled' },
        ];

        this.requestStatusIdToItemStatusNameMap = [
            { value: this.requestOnDeliveryStatus, viewValue: 'Picked', icon: 'local_shipping' },
            { value: this.requestDeliveredStatus, viewValue: 'Returned', icon: 'check' },
            { value: this.requestCancelledStatus, viewValue: 'Cancelled', icon: 'close' }
        ]

        this.itemNotPickedStatus = 1;
        this.itemPickedStatus = 2;

        this.itemStatuses = [
            { value: this.itemNotPickedStatus, viewValue: 'Not Picked ', icon: 'remove_circle' },
            { value: this.itemPickedStatus, viewValue: 'Picked', icon: 'local_shipping' },
        ];

        this.collectionNotPickedStatus = 1;
        this.collectionPickedStatus = 2;
        this.collectionReturnedStatus = 3;
        this.collectionCancelledStatus = 4;

        this.collectionStatuses = [
            { value: this.collectionNotPickedStatus, viewValue: 'Not Picked', icon: 'remove_circle' },
            { value: this.collectionPickedStatus, viewValue: 'Picked', icon: 'local_shipping' },
            { value: this.collectionReturnedStatus, viewValue: 'Returned', icon: 'check' },
            { value: this.collectionCancelledStatus, viewValue: 'Cancelled', icon: 'close' }
        ];

        this.title = this.activatedRoute.snapshot.data['title'];
        this.isDeliveryRequestStatusFinal = false;
        
        this.defaulStatus = 4;
        this.isRequestStatusSelectDisabled = false;
    }

    ngOnInit() {
        var requestId = this.activatedRoute.snapshot.paramMap.get('id');
        this.selectedValueStatus = this.defaulStatus;

        if (requestId != null) {
            this.deliveryService.getDeliveryRequest(requestId).subscribe(
                result => {
                    if (result.status === 1) {
                        this.selectedValueStatus = result.data.requestStatus;
                        this.setIsDeliveryRequestStatusFinal(result.data.requestStatus);
                        this.currentRequestStatus = result.data.requestStatus;
                        this.deliveryRequestDetails = result.data;
                        this.adminNote = this.deliveryRequestDetails.adminNote;
                        this.serverError = '';
                        this.isRequestStatusSelectDisabled = result.data.requestStatus == this.requestCancelledStatus || result.data.requestStatus == this.requestDeliveredStatus;
                        this.createdDate = result.data.createdDate
                    }
                    else {
                        this.serverError = result.data;
                    }

                },
                error => {
                    this.serverError = 'Some error occured.'
                });

        }
    }

    onCancelClick(): void {
            this.router.navigate(['/delivery-requests']);
    }

    deliveryRequestStatusChanged(event: any) {
        switch (event.value) {
            case this.requestCancelledStatus:
                {
                    let dialogRef = this.dialog.open(YesNoDialogComponent, {
                        data: 'Cancel delivery request ' + this.deliveryRequestDetails.requestNumber + '?'
                    });

                    dialogRef.afterClosed()
                        .pipe(name => name)
                        .subscribe(name => {
                            if (name === 'Yes') {
                                this.deliveryRequestStatusChangedCommonRoutine(event.value);
                                this.isRequestStatusSelectDisabled = true;
                            }
                            else {
                                this.selectedValueStatus = this.currentRequestStatus;
                            }
                        });
                }
                break;
            case this.requestDeliveredStatus:
                {
                    let dialogRef = this.dialog.open(OkCancelDialogComponent, {
                        data: 'This will mark the request ' + this.deliveryRequestDetails.requestNumber + ' as completed. '
                            + 'You will not be able to change the status of a completed request. Do you want to continue?'
                    });

                    dialogRef.afterClosed()
                        .pipe(name => name)
                        .subscribe(name => {
                            if (name === 'Ok') {
                                this.deliveryRequestStatusChangedCommonRoutine(event.value);
                                this.isRequestStatusSelectDisabled = true;
                            }
                            else {
                                this.selectedValueStatus = this.currentRequestStatus;
                            }
                        });
                }
                break;
            case this.requestOnDeliveryStatus:
                var areAllItemsPicked = this.areAllRequestCollectionItemsPicked();

                if (areAllItemsPicked) {
                    this.deliveryRequestStatusChangedCommonRoutine(event.value);

                }
                else {
                    let dialogRef = this.dialog.open(OkDialogComponent, {
                        data: 'All items have to be picked before the request status can be changed to On delivery'
                    });

                    dialogRef.afterClosed()
                        .pipe(name => name)
                        .subscribe(name => {
                            this.selectedValueStatus = this.currentRequestStatus;
                        });
                }

                break;
            default:
                this.deliveryRequestStatusChangedCommonRoutine(event.value);
                break;
        }
    }

    deliveryRequestStatusChangedCommonRoutine(status: any) {
        this.updateRequestStatusInternal(status);
        this.setIsDeliveryRequestStatusFinal(status);
        this.currentRequestStatus = status;
    }

    updateRequestStatusInternal(status: string) {
        this.deliveryService.updateRequestStatus(this.deliveryRequestDetails.requestId, status).subscribe(
            result => {
                if (result.success) {
                    this.deliveryRequestDetails.deliveryRequestCollections.forEach(drc => {
                        if (status == this.requestCancelledStatus.toString()) {
                            drc.collectionStatusId = this.collectionCancelledStatus;
                        }
                        if (status == this.requestDeliveredStatus.toString()) {
                            drc.collectionStatusId = this.collectionReturnedStatus;
                        }
                    })
                }
                else {
                    if (result.data.isRequestMissing) {
                        this.router.navigate(['/delivery-requests']);

                    }
                }
            });
    }

    setIsDeliveryRequestStatusFinal(requestStatusId: number) {
        if (requestStatusId == this.requestOnDeliveryStatus || requestStatusId == this.requestDeliveredStatus || requestStatusId == this.requestCancelledStatus) {
            this.isDeliveryRequestStatusFinal = true;
        }
        else {
            this.isDeliveryRequestStatusFinal = false;
        }
    }

    printRequestClicked() { 
        var areAllItemsPicked = this.areAllRequestCollectionItemsPicked();

        if (areAllItemsPicked) {
            window.print();
            //this.printRequestCSV();
        }
        else {
            let dialogRef = this.dialog.open(OkCancelDialogComponent, {
                data: 'Some of the items in the list have not been picked yet. Print anyway?'
            });

            dialogRef.afterClosed()
                .pipe(name => name)
                .subscribe(name => {
                    if (name === 'Ok') {
                        window.print();
                        //this.printRequestCSV();
                    }
                });
        }
    }

    printRequestCSV() {
        this.deliveryService.getRequestCsv(this.deliveryRequestDetails.requestId).subscribe(
            result => {
                if (result.success) {
                    var blob = new Blob([result.data.fileData]);
                    const blobUrl = URL.createObjectURL(blob);
                    const iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    iframe.src = blobUrl;
                    document.body.appendChild(iframe);
                    iframe.contentWindow.print();
                }
            },
            error => {
                let dialogRef = this.dialog.open(OkDialogComponent, { data: 'Some error occured.' });
            });
    }

    itemStatusChanged() {
        this.deliveryRequestDetails.deliveryRequestCollections.forEach(drc => {
            drc.requestCollectionItems.forEach(rci => {
                if (rci.itemStatusId == this.itemNotPickedStatus) {
                    drc.collectionStatusId = this.collectionNotPickedStatus;
                    return;
                }
            })

            if (drc.requestCollectionItems.every(ci => ci.itemStatusId == this.itemPickedStatus)) {
                drc.collectionStatusId = this.collectionPickedStatus;
            }
        })
    }

    areAllRequestCollectionItemsPicked() {
        return this.deliveryRequestDetails.deliveryRequestCollections.every(dr => {
            return dr.requestCollectionItems.every(ci => ci.itemStatusId == this.itemPickedStatus)
        });
    }

    saveAdminNote() {
        this.deliveryService.updateDeliveryRequestNote(this.deliveryRequestDetails.requestId, this.adminNote).subscribe(
            result => {
                if (result.success) {
                    let dialogRef = this.dialog.open(OkDialogComponent, {
                        data: 'The note has been successfully saved'
                    });
                }
                else {
                    if (result.data.isRequestMissing) {
                        this.router.navigate(['/delivery-requests']);

                    }
                    else {
                        let dialogRef = this.dialog.open(OkDialogComponent, {
                            data: result.data
                        });
                    }
                }
            });
    }

    clearAdminNote() {
        let dialogRef = this.dialog.open(OkCancelDialogComponent, {
            data: 'Are you sure you want to delete the note?'
        });

        dialogRef.afterClosed()
            .pipe(name => name)
            .subscribe(name => {
                if (name === 'Ok') {
                    var adminNoteValue = '';
                    this.adminNote = adminNoteValue;

                    this.deliveryService.updateDeliveryRequestNote(this.deliveryRequestDetails.requestId, adminNoteValue).subscribe(result => {
                        if (result.success) {

                        }
                        else {
                            let dialogRef = this.dialog.open(OkDialogComponent, {
                                data: 'Unable to delete the note due to server issues. Please try again later.'
                            });
                        }
                    });
                }
            });
    }
}