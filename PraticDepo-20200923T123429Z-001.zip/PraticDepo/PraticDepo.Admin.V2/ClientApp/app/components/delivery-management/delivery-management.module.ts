﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { DeliveryManagementMainComponent } from './delivery-management-main/delivery-management-main.component';
import { DeliveryManagemenListItemComponent } from './delivery-management-list-item/delivery-management-list-item.component';
import { DeliveryManagementDetailsComponent } from './delivery-management-details/delivery-management-details.component';
import { DeliveryManagementRequestItemComponent } from './delivery-management-details/delivery-management-request-item/delivery-management-request-item.component';

import { SharedModule } from "../../shared/shared.module";
import { DeliveryService } from '../../shared/services/delivery.service';
import { AuthenticatedHttpService } from '../../AuthenticatedHttpService'
import { Http } from '@angular/http';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        BrowserModule,
        SharedModule
    ],    
    declarations: [
        DeliveryManagementMainComponent,
        DeliveryManagemenListItemComponent,
        DeliveryManagementDetailsComponent,
        DeliveryManagementRequestItemComponent
    ],
    exports: [
        DeliveryManagementMainComponent,
        DeliveryManagemenListItemComponent,
        DeliveryManagementDetailsComponent,
        DeliveryManagementRequestItemComponent
    ],
    providers: [
        DeliveryService,
        { provide: Http, useClass: AuthenticatedHttpService }
    ],
})

export class DeliveryManagementModule {
}