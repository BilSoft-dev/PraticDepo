﻿
export class DeliveryManagementDetailsModel {
    requestId: any;
    userFirstName: string;
    userLastName: string;
    userEmail: string;
    requestStatus: number;
    createdDate: string;
    deliveryRequestCollections: CollectionModel[];
    requestNumber: string;
    adminNote: string;
    deliveryRequestNotes: NoteModel[];

    constructor() {
        this.requestNumber = '';
        this.requestId = '';
        this.userFirstName = '';
        this.userLastName = '';
        this.userEmail = '';
        this.requestStatus = 0;
        this.createdDate = '';
        this.deliveryRequestCollections = [];
        this.deliveryRequestCollections.push(new CollectionModel());
        this.adminNote = '';
        this.deliveryRequestNotes = [];
        this.deliveryRequestNotes.push(new NoteModel());
    }
}

export class CollectionModel {
    collectionName: string;
    collectionBarcode: string;
    collectionStatusId: number;
    collectionUnitNumber: string;
    collectionImageLink: string;
    collectionImageUrl: string;
    requestCollectionItems: ItemModel[];
    index: number;

    constructor() {
        this.collectionName = '';
        this.collectionBarcode = '';
        this.collectionStatusId = 0;
        this.requestCollectionItems = [];
        this.collectionUnitNumber = '';
        this.collectionImageLink = '';
        this.collectionImageUrl = '';
        this.requestCollectionItems.push(new ItemModel())
        this.index = 0;
    }
}

export class ItemModel {
    itemId: string;
    itemName: string;
    itemBarcode: string;
    itemStatusId: number;
    itemImageUrl: string;
    itemImageLink: string;
    index: number;

    constructor() {
        this.itemId = '';
        this.itemName = '';
        this.itemBarcode = '';
        this.itemStatusId = 0;
        this.itemImageUrl = '';
        this.itemImageLink = '';
        this.index = 0;
    }
}

export class NoteModel {
    noteId: string;
    noteText: string;

    constructor() {
        this.noteId = '';
        this.noteText = '';
    }
}