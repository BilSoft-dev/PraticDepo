﻿import { ApiResponse } from '../../../../shared/models/api.response.model'
import { DeliveryManagementDetailsModel } from './delivery-management-details.model';

export class DeliveryRequestApiResponse extends ApiResponse {
    constructor(deliveryManagementDetails: DeliveryManagementDetailsModel, status: any) {
        super(deliveryManagementDetails, status)
    }
}