﻿export class DeliveryManagementModel {
    requestId:any;
    userFirstName: string;
    userLastName: string;
    userEmail: string;
    statusName: string;
    dateCreated: string;
    isRequesterUserDeleted: boolean;
    requestNumber: string;
    adminNote: string;
    deliveryRequestNotes: NoteModel[];

    constructor() {
        this.requestId = '';
        this.userFirstName = '';
        this.userLastName = '';
        this.userEmail = '';
        this.statusName = '';
        this.dateCreated = '';
        this.isRequesterUserDeleted = false;
        this.requestNumber = '';
        this.adminNote = '';
        this.deliveryRequestNotes = [];
        this.deliveryRequestNotes.push(new NoteModel());
    }
}

export class NoteModel {
    noteId: string;
    noteText: string;

    constructor() {
        this.noteId = '';
        this.noteText = '';
    }
}