﻿import { PagerModel } from '../../../../shared/models/pager.model'
import { DeliveryManagementModel } from './delivery-management.model'

export class DeliveryRequestsListViewModel {
    pager: PagerModel;
    deliveryRequests: DeliveryManagementModel[];

    constructor(pager: PagerModel, deliveryRequests: DeliveryManagementModel[]) {
        this.pager = pager;
        this.deliveryRequests = deliveryRequests;
    }
}