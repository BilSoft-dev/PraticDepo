﻿import { Component, Output } from '@angular/core';
import { UserModel } from "../shared/models";
import { UserService } from '../../../shared/services/users.service'
import { UserListApiResponse } from '../../../shared/models/userlist.response.model'
import { OkCancelDialogComponent } from '../../../shared/dialogs/ok-cancel-dialog/ok-cancel-dialog.component'
import { OkDialogComponent } from '../../../shared/dialogs/ok-dialog/ok-dialog.component'
import { CommonService } from '../../../shared/utils/common.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    selector: 'user-manage',
    templateUrl: './user-manage-main.component.html'
})


export class UserManageComponent {
    search: string;
    names: any;
    acsendings: any;
    selectedValue: string;
    totalElements: number;
    selectedValueAcsending: string;
    selectedValueFilter: string;
    length: number;
    pageIndex: number;
    pageSize: number;
    private defaultOrder: string;
    private defaultFilter: string;
    private userSubmittedFilter: string;
    private defaultPageIndex: number;
    serverError: any;
    userList: UserModel[];

    //@Output('reloadRequestReceivedEvent')

    constructor(private userService: UserService, private dialog: MatDialog, private commonService: CommonService) {
        this.defaultOrder = 'desc';
        this.defaultFilter = 'firstName';
        this.userSubmittedFilter = '';
        this.defaultPageIndex = 0;
    }

    ngOnInit() {
        this.pageSize = 10;
        this.pageIndex = this.defaultPageIndex;

        let localSelectedFilter = sessionStorage.getItem('selectedValueFilter');

        if (localSelectedFilter !== null && localSelectedFilter !== '') {
            this.selectedValueFilter = localSelectedFilter;
        }
        else {
            sessionStorage.setItem('selectedValueFilter', this.defaultFilter);
            this.selectedValueFilter = this.defaultFilter;
        }

        let localSelectedAcsending = sessionStorage.getItem('selectedValueAcsending');

        if (localSelectedAcsending !== null && localSelectedAcsending !== '') {
            this.selectedValueAcsending = localSelectedAcsending;
        }
        else {
            sessionStorage.setItem('selectedValueAcsending', this.defaultOrder);
            this.selectedValueAcsending = this.defaultOrder;
        }

        this.names = [
            { value: 'firstName', viewValue: 'First Name' },
            { value: 'lastName', viewValue: 'Last Name' },
            { value: 'email', viewValue: 'Email' },
            { value: 'CreatedAt', viewValue: 'Date Created' }
        ];
        this.acsendings = [
            { value: 'asc', viewValue: 'Ascending' },
            { value: 'desc', viewValue: 'Descending' }
        ];

        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.search);
    }

    checkClass() {
        //let isClass = document.getElementsByClassName("cdk-overlay-container")[0].classList.contains('pagination');
        //let overlayContainer = document.getElementsByClassName("cdk-overlay-container")[0];

        //if (isClass) {
        //    overlayContainer.classList.remove('pagination')
        //} 
    }

    exportAllUserData() {
        this.userService.exportAllUserData().subscribe(
            result => {
                if (result.success) {
                    var blob = new Blob([result.data.fileData], { type: result.data.fileType });

                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = result.data.fileName;
                    let csvContainer = document.getElementById('csvContainer');
                    if (csvContainer != null) {
                        csvContainer.appendChild(link)
                    }
                    link.click();

                    this.commonService.downloadFile(result)
                }
                else {
                    var dialogRef = this.dialog.open(OkDialogComponent, { data: result.data });

                    //if (result.data.isUserMissing) {
                    //    dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
                    //    dialogRef.afterClosed().subscribe(x => { this.router.navigate(['/users']); })
                    //}
                    //else {
                    //    dialogRef = this.dialog.open(OkDialogComponent, { data: result.data })
                    //}
                }
            },
            error => {
                let dialogRef = this.dialog.open(OkDialogComponent, { data: 'Some error occured.' });
            });
    }

    orderChanged() {        
        sessionStorage.setItem('selectedValueAcsending', this.selectedValueAcsending);
        this.reloadUsersList();
    }

    sortFieldChanged() {     
        sessionStorage.setItem('selectedValueFilter', this.selectedValueFilter);
        this.reloadUsersList();
    }

    getUsers(pageIndex: number, pageSize: number, sortingField: string, pageSort: string, filter: string) {
        this.userService.getUsers(pageIndex, pageSize, sortingField, pageSort, filter).subscribe(
            result => {
                if (result.status === 1) {
                    this.userList = result.data.entities;
                    this.length = result.data.pager.totalCount;
                    this.serverError = '';
                }
                else {
                    this.serverError = result.data;
                }
            },
            error => {
                this.serverError = 'Some error occured.'
            });
    }

    pagerChanged(event: any) {
        //let isClass = document.getElementsByClassName("cdk-overlay-container")[0].classList.contains('pagination');
        //let overlayContainer = document.getElementsByClassName("cdk-overlay-container")[0];

        //if (!isClass) {
        //    overlayContainer.classList.add('pagination')
        //}  
      
        this.length = event.length;
        this.pageIndex = event.pageIndex;
        this.pageSize = event.pageSize;

        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.userSubmittedFilter);
    }

    filterChanged() {
        this.userSubmittedFilter = this.search;
        this.pageIndex = this.defaultPageIndex;
        this.reloadUsersList();
    }

    clearSearch() {
        this.search = '';
        this.userSubmittedFilter = '';
        this.reloadUsersList();
    }

    reloadUsersList() {
        this.getUsers(this.pageIndex, this.pageSize, this.selectedValueFilter, this.selectedValueAcsending, this.userSubmittedFilter);
    }
}
