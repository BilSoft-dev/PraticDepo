﻿import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MainFormComponent } from "../../../shared/components/forms-component/main-form.component";
import { ValidationMessages } from "../../../shared/custom-validators/validation-messages";
import { Router, ActivatedRoute, Data } from '@angular/router';
import { UserService } from '../../../shared/services/users.service'
import { OkDialogComponent } from '../../../shared/dialogs/ok-dialog/ok-dialog.component'
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
    selector: 'reset-password',
    templateUrl: './reset-password.component.html'
})
export class ResetPasswordComponent extends MainFormComponent {
    user: any;
    roles: any;
    hide: boolean = true;
    userId: any;
    serverError: string;
    shouldDisableEmail: boolean = false;
    shouldDisablePasswordInputs: boolean = false;

    constructor(private router: Router, private activatedRoute: ActivatedRoute, private userService: UserService, private dialog: MatDialog) {
        super();

        this.buildResetPasswordForm();
        this.user = {
            email: '',
            password: '',
            confirmPassword: '',
            isRandomPassword: true
        }
    }

    ngOnInit() {
        this.userId = this.activatedRoute.snapshot.paramMap.get('id');

        this.userService.getUser(this.userId).subscribe(
            result => {
                this.user = {
                    email: result.data.email,
                    isRandomPassword: true
                };

                this.shouldDisableEmail = true;
                this.disablePasswordFields();
            },
            error => {
            });
    }

    private buildResetPasswordForm(): void {
        this.mainFormGroup = new FormGroup({
            'email': new FormControl({ disabled: true }),
            'password': new FormControl(''),
            'confirmPassword': new FormControl(''),
            'isRandomPassword': new FormControl({checked:true})
        });

        this.validationMessages = {
            'email': {
                'required': ValidationMessages.Required("Email")
            }
        };

        this.formErrors = {
            'email': '',
        };
    }

    onResetPasswordFormSubmit(): void {
        if (this.mainFormGroup.invalid) {
            this.markFormElementsAsDirty(this.mainFormGroup, this.formErrors);
            this.collectErrorsForFormControl(this.mainFormGroup, this.formErrors);
            return;
        }

        this.userService.resetUser(this.user.email, this.user.password, this.user.confirmPassword, this.user.isRandomPassword).subscribe(result => {
            var dialogRef;

            if (result.success) {
                dialogRef = this.dialog.open(OkDialogComponent, {
                    data: 'The password has been reset successfully.'
                });

                dialogRef.afterClosed()
                    .subscribe(x => {
                        this.router.navigate(['/users']);
                    })
            }
            else {
                if (result.data.isUserMissing) {
                    dialogRef = this.dialog.open(OkDialogComponent, {
                        data: result.data.errorMessage
                    });

                    dialogRef.afterClosed()
                        .subscribe(x => {
                            this.router.navigate(['/users']);
                        })
                }
                else {
                    this.serverError = result.data
                }
            }
        },
            error => {
                this.serverError = 'Some error occured.'
            });
    }

    generateRandomChanged(changedEvent: any): void {
        if (changedEvent.checked === true) {
            this.disablePasswordFields();
            this.user.isRandomPassword = true;
            this.user.password = '';
            this.user.confirmPassword = '';
        }
        else {
            this.enablePasswordFields();
            this.user.isRandomPassword = false;
        }
    }

    disablePasswordFields(): void {
        this.shouldDisablePasswordInputs = true;
    }

    enablePasswordFields(): void {
        this.shouldDisablePasswordInputs = false;
    }
}
