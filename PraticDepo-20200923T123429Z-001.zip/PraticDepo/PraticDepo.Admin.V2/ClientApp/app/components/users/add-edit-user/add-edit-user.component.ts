﻿import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MainFormComponent } from "../../../shared/components/forms-component/main-form.component";
import { ValidationMessages } from "../../../shared/custom-validators/validation-messages";
import { Router, ActivatedRoute, Data, ParamMap } from '@angular/router';
import { UserService } from '../../../shared/services/users.service'
import { UserViewModel } from '../../../shared/models/user.view.model'
import { RoleViewModel } from '../../../shared/models/role.view.model'
import { forEach } from '@angular/router/src/utils/collection';
import 'rxjs/add/operator/switchMap';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OkDialogComponent } from '../../../shared/dialogs/ok-dialog/ok-dialog.component'
import { YesNoDialogComponent } from '../../../shared/dialogs/yes-no-dialog/yes-no-dialog.component'

@Component({
    selector: 'add-edit-user',
    templateUrl: './add-edit-user.component.html'
})
export class AddEditUserComponent extends MainFormComponent {
    title: any;
    user: any;
    roles: any;
    hide: boolean = true;
    selectedRole: any;
    serverError: any;
    private userId: any;
    private isEditMode: boolean = false;

    userRolesMap: { [key: string]: { value: string } } = {};

    isPhoneNumberDisabled: boolean = false;
    shouldDisablePasswordInputs: boolean = false;
    shouldDisabledPasswordGeneration: boolean = false;
    isRoleInputDisabled: boolean = false;

    constructor(private router: Router, private activatedRoute: ActivatedRoute, private userService: UserService, private dialog: MatDialog) {
        super();
        this.roles = [];

        this.userRolesMap["RegularUserKey"] = { value: "RegularUser" };
        this.userRolesMap["ShedUserKey"] = { value: "ShedUser" };
        this.userRolesMap["AdministratorKey"] = { value: "Admin" };

        this.user = {
            firstName: '',
            lastName: '',
            email: '',
            phoneNumber: '',
            password: '',
            confirmPassword: '',
            isRandomPassword: false //STUB because for some reason ngModel binding doesn't work :(
        }
    }

    ngOnInit() {
        this.title = this.activatedRoute.snapshot.data['title'];
        this.isEditMode = this.activatedRoute.snapshot.data['isEditMode'];

        if (this.isEditMode) {
            this.initializeEditMode();
        }
        else {
            this.initializeAddMode();
        }

        this.buildAddEditForm();
    }

    private buildAddEditForm(): void {
        this.mainFormGroup = new FormGroup({
            'firstName': new FormControl(''),
            'lastName': new FormControl(''),
            'phoneNumber': new FormControl(''),
            'email': new FormControl('', [Validators.required]),
            'password': new FormControl(''),
            'confirmPassword': new FormControl(''),
            'isRandomPassword': new FormControl('')
        });

        this.validationMessages = {
            'email': {
                'required': ValidationMessages.Required("Email")
            }
        };

        this.formErrors = {
            'email': ''
        };    
    }

    onAddEditFormSubmit(): void {

        if (this.mainFormGroup.invalid) {
            this.markFormElementsAsDirty(this.mainFormGroup, this.formErrors);
            this.collectErrorsForFormControl(this.mainFormGroup, this.formErrors);
            return;
        }

        if (this.isEditMode) {
            this.editUser();
        }
        else {
            this.addUser();
        }
    }

    initializeEditMode() {
        this.userId = this.activatedRoute.snapshot.paramMap.get('id');

        this.userService.getUser(this.userId).subscribe(
            result => {
                let parsedData = result.data as UserViewModel;

                this.user = {
                    firstName: parsedData.firstName,
                    lastName: parsedData.lastName,
                    email: parsedData.email,
                    phoneNumber: parsedData.phoneNumber,
                }

                for (var i = 0; i < parsedData.allRoles.length; i++) {
                    this.roles.push({ value: parsedData.allRoles[i].id, viewValue: parsedData.allRoles[i].name });

                    if (parsedData.role === parsedData.allRoles[i].id) {
                        this.selectedRole = parsedData.role;
                    }
                }

                this.applyIsRegularUserChanges();
                this.disablePasswordFields();
                this.shouldDisabledPasswordGeneration = true;
                this.isRoleInputDisabled = true;
            },
            error => {
            });
    }

    initializeAddMode() {
        this.userService.getUserRoles().subscribe(
            result => {
                if (result.success) {

                    for (var i = 0; i < result.data.length; i++) {
                        this.roles.push({ value: result.data[i].id, viewValue: result.data[i].name });
                    }

                    this.selectedRole = result.data[0].id;
                }
                else {
                    this.serverError = result.data;
                }

                this.isRoleInputDisabled = false;
            },
            error => {
                this.serverError = 'Some error occured.'

            });
    }

    editUser(): void {
        this.userService.editUser(this.userId, this.user.email, this.user.firstName,
            this.user.lastName, this.selectedRole, this.user.phoneNumber).subscribe(result => {
                var dialogRef;

                if (result.success) {
                    dialogRef = this.dialog.open(OkDialogComponent, {
                        data: 'The user has been successfully edited.'
                    });

                    dialogRef.afterClosed()
                        .subscribe(x => {
                            this.router.navigate(['/users']);
                        })
                }
                else {
                    if (result.data.isUserMissing) {
                        dialogRef = this.dialog.open(OkDialogComponent, {
                            data: result.data.errorMessage
                        });

                        dialogRef.afterClosed()
                            .subscribe(x => {
                                this.router.navigate(['/users']);
                            })
                    }
                    else {
                        this.serverError = result.data
                    }
                }
            },
            error => {
                this.serverError = 'Some error occured.'
            });
    }

    addUser(): void {
        this.userService.addUser(this.user.email, this.user.firstName, this.user.lastName, this.selectedRole,
            this.user.phoneNumber, this.user.isRandomPassword, this.user.password,
            this.user.confirmPassword).subscribe(result => {
                var dialogRef;

                if (result.success) {
                    dialogRef = this.dialog.open(OkDialogComponent, {
                        data: 'The user has been successfully created. A confirmation email has been sent to the defined email address.'
                    });

                    dialogRef.afterClosed().subscribe(x => { this.router.navigate(['/users']); })
                }
                else {
                    if (result.data.isUserMissing) {
                        dialogRef = this.dialog.open(OkDialogComponent, {
                            data: result.data.errorMessage
                        });

                        dialogRef.afterClosed().subscribe(x => { this.router.navigate(['/users']); })
                    }
                    else {
                        this.serverError = result.data
                    }
                }
            },
            error => {
                this.serverError = 'Some error occured.'
            });
    }

    roleFieldChanged(): void {
        this.applyIsRegularUserChanges();
    }

    applyIsRegularUserChanges(): void {
        if (this.selectedRole === this.userRolesMap["ShedUserKey"].value) {
            this.disablePhoneNumber();
        }
        else {
            this.enablePhoneNumber();
        }
    }

    disablePhoneNumber(): void{
        this.isPhoneNumberDisabled = true;
        this.user.phoneNumber = '';
    }

    enablePhoneNumber(): void {
        this.isPhoneNumberDisabled = false;
    }

    disablePasswordFields(): void {
        this.shouldDisablePasswordInputs = true;
    }

    enablePasswordFields(): void {
        this.shouldDisablePasswordInputs = false;
    }

    generateRandomChanged(changedEvent: any): void {
        if (changedEvent.checked === true) {
            this.disablePasswordFields();
            this.user.password = '';
            this.user.confirmPassword = '';
            this.user.isRandomPassword = true;
        }
        else {
            this.enablePasswordFields();
            this.user.isRandomPassword = false;
        }
    }

    onCancelClick(): void{
        let dialogRef = this.dialog.open(YesNoDialogComponent, {
            data: 'Are you sure you want to leave the current page without saving?'
        });

        dialogRef.afterClosed()
            .pipe(name => name)
            .subscribe(name => {
                if (name === 'Yes') {
                    this.router.navigate(['/users']);
                }
            })
    }
}