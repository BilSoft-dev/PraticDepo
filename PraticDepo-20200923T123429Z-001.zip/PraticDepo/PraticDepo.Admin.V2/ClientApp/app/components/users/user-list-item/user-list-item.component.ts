﻿import { Router } from '@angular/router';
import { Component, Input, OnInit, Inject, Output, EventEmitter } from '@angular/core';
import { UserModel } from "../shared/models";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OkDialogComponent } from '../../../shared/dialogs/ok-dialog/ok-dialog.component'
import { OkCancelDialogComponent } from '../../../shared/dialogs/ok-cancel-dialog/ok-cancel-dialog.component'
import { UserService } from '../../../shared/services/users.service'
import { DeleteUserDialogComponent } from '../../../shared/dialogs/delete-user-dialog/delete-user-dialog'
import { CommonService } from '../../../shared/utils/common.service';

@Component({
    selector: 'user-list-item',
    templateUrl: './user-list-item.component.html'
})


export class UserListItemComponent {
    @Input() user: UserModel;

    @Output('reloadRequestReceivedEvent')
    reloadRequestReceivedEventEmitter = new EventEmitter();

    constructor(private router: Router, private userService: UserService, private dialog: MatDialog, private commonService: CommonService) { }

    ngOnInit() {
        
    }

    userResetPasswordClicked() {
        this.checkIsUserExist(() => {
            this.router.navigate(['/users/user/', this.user.userId, 'reset-password']);
        });
    };

    userTransferCollectionsClicked() {
        this.checkIsUserExist(() => {
            this.router.navigate(['/users/user/', this.user.userId, 'transfer-collection']);
        });
    };

    lockClicked() {
        let dialogRef = this.dialog.open(OkCancelDialogComponent, {
            data: 'Are you sure you want to lock user ' + this.user.email + '?'
        });

        dialogRef.afterClosed()
            .pipe(name => name)
            .subscribe(name => {
                if (name === 'Ok') {
                    this.sendLockRequest();
                }
            });
    }

    unlockClicked() {
        let dialogRef = this.dialog.open(OkCancelDialogComponent, {
            data: 'Are you sure you want to unlock user ' + this.user.email + '?'
        });

        dialogRef.afterClosed()
            .pipe(name => name)
            .subscribe(name => {
                if (name === 'Ok') {
                    this.sendUnlockRequest();
                }
            });
    }

    sendLockRequest() {
        this.setUserIsLocked(true);
    }

    sendUnlockRequest() {
        this.setUserIsLocked(false);
    }

    setUserIsLocked(isLocked: boolean) {
        this.userService.setUserIsLocked(this.user.userId, isLocked).subscribe(result => {
            if (result.success) {
                this.user.isLocked = !!isLocked;
            }
            else {
                var dialogRef;

                if (result.data.isUserMissing) {
                    dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
                    dialogRef.afterClosed().subscribe(x => { this.router.navigate(['/users']); })
                }
                else {
                    dialogRef = this.dialog.open(OkDialogComponent, { data: result.data });
                }
            }
        },
            error => {
                let dialogRef = this.dialog.open(OkDialogComponent, { data: 'Some error occured.' });
            })
    }

    deleteClicked() {
        var userFirstName = this.user.firstName === null ? '' : this.user.firstName + ' ';
        var userLastName = this.user.lastName === null ? '' : this.user.lastName + ' ';

        let dialogRef = this.dialog.open(DeleteUserDialogComponent, {
            data: 'Are you sure you want to delete user ' + userFirstName
                + userLastName + '(' + this.user.email + ')?'
        });

        dialogRef.afterClosed()
            .pipe(name => name)
            .subscribe(name => {
                if (name === 'Delete') {
                    this.deleteUser();
                }
            });
    }

    deleteUser() {
        this.userService.deleteUser(this.user.userId).subscribe(result => {
            if (result.success) {
                this.reloadRequestReceivedEventEmitter.emit();
                //window.open('/users', '_self');
                //this.router.navigate(['/users']);
            }
            else {
                var dialogRef;

                if (result.data.isUserMissing) {
                    dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
                    dialogRef.afterClosed().subscribe(x => {
                        this.router.navigate(['/users']);
                    })
                }
                else {
                    dialogRef = this.dialog.open(OkDialogComponent, { data: result.data });
                }
            }
        },
            error => {
                let dialogRef = this.dialog.open(OkDialogComponent, { data: 'Some error occured.' });
            })
    }

    exportToCSVClicked() {
        this.userService.getUserDataCSV(this.user.userId).subscribe(
            result => {
                if (result.success) {
                    var blob = new Blob([result.data.fileData], { type: result.data.fileType });

                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = result.data.fileName;
                    let csvContainer = document.getElementById('csvContainer');
                    if (csvContainer != null) {
                        csvContainer.appendChild(link)
                    }
                    link.click();

                    this.commonService.downloadFile(result)
                }
                else {
                    var dialogRef;

                    if (result.data.isUserMissing) {
                        dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
                        dialogRef.afterClosed().subscribe(x => { this.router.navigate(['/users']); })
                    }
                    else {
                        dialogRef = this.dialog.open(OkDialogComponent, { data: result.data })
                    }
                }
            },
            error => {
                let dialogRef = this.dialog.open(OkDialogComponent, { data: 'Some error occured.' });
            });
    }

    checkIsUserExist(callback: any) {
        this.userService.isUserExist(this.user.userId).subscribe(result => {
            var dialogRef;

            if (result.success) {
                callback();
            }
            else {
                if (result.data.isUserMissing) {
                    dialogRef = this.dialog.open(OkDialogComponent, {
                        data: result.data.errorMessage
                    });
                }
                else {
                    dialogRef = this.dialog.open(OkDialogComponent, {
                        data: result.data
                    });
                }
            }
        });
    }

    editUserClicked() {
        this.checkIsUserExist(() => {
            this.router.navigate(['/users/user/', this.user.userId, 'edit']);
        });
    }
}
