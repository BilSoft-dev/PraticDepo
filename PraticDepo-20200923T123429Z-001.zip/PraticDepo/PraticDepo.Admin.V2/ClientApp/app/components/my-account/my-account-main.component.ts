import { Injectable, NgModule, Output, EventEmitter } from '@angular/core';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OkDialogComponent } from '../../shared/dialogs/ok-dialog/ok-dialog.component'
import { MyAccountService } from '../../shared/services/my-account.service'
import { ConfigService } from '../../shared/utils/config.service'

@Component({
    selector: 'my-account',
    templateUrl: './my-account-main.component.html'

})

export class myAccountMainComponent {
    user: any;
    userId: string = '';
    serverError: string = '';

    @Output('errorReceivedEvent')
    errReceivedEvent = new EventEmitter<string>();

    constructor(
        private router: Router,
        private dialog: MatDialog,
        private activatedRoute: ActivatedRoute,
        private accountService: MyAccountService,
        private configService: ConfigService) {
    }

    ngOnInit() {
        this.user = {
            userId: '',
            passwordConfirm: '',
            passwordOld: '',
            passwordNew: '',
            firstName: '',
            lastName: '',
            email: '',
            phoneNumber: '',
            isShedAdmin: false
        }

        var tokenData = this.configService.parseJwt(localStorage['auth_token']);

        this.accountService.getAccountDetails(tokenData.id).subscribe(result => {
            if (result.success) {
                this.user = {
                    userId: tokenData.id,
                    firstName: result.data.firstName,
                    lastName: result.data.lastName,
                    email: result.data.email,
                    phoneNumber: result.data.phoneNumber,
                    isShedAdmin: result.data.isShedAdmin
                }
            }
            else {
                var dialogRef;

                if (result.data.isUserMissing) {
                    dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
                    dialogRef.afterClosed().subscribe(x => { this.router.navigate(['/users']); })
                }
                else {
                    this.errReceivedEvent.emit(result.data);
                }
            }
        },
            error => {
                this.serverError = 'Some error occured.';
            })

    }

    showError(error: any) {
        this.serverError = error;
    }
}
