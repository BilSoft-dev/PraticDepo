import { Injectable, NgModule, Input, Output, EventEmitter } from '@angular/core';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MainFormComponent } from "../../../shared/components/forms-component/main-form.component";
import { ValidationMessages } from "../../../shared/custom-validators/validation-messages";
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { OkDialogComponent } from '../../../shared/dialogs/ok-dialog/ok-dialog.component'
import { MyAccountService } from '../../../shared/services/my-account.service'

@Component({
    selector: 'my-account-general',
    templateUrl: './my-account-general.component.html'

})

export class myAccountGeneralComponent extends MainFormComponent {
    @Input() user: any;

    @Output('errorReceivedEvent')
    errReceivedEvent = new EventEmitter<string>();

    constructor(
        private router: Router,
        private dialog: MatDialog,
        private route: ActivatedRoute,
        private myAccountService: MyAccountService) {
        super();
    }

    ngOnInit() {
        this.user = {
            userId: '',
            firstName: '',
            lastName: '',
            phoneNumber: ''
        }

        this.buildMyAccountGeneralForm();
        super.ngOnInit();
    }

    private buildMyAccountGeneralForm(): void {
        this.mainFormGroup = new FormGroup({
            'firstName': new FormControl(''),
            'lastName': new FormControl(''),
            'phoneNumber': new FormControl(''),
        });

        this.formErrors = {
            'firstName': '',
            'lastName': '',
            'phoneNumber': ''
        };
    }
    onMyAccountGeneralFormSubmit(): void {
        this.myAccountService.editGeneralUserInfo(this.user.userId, this.user.firstName, this.user.lastName, this.user.phoneNumber).subscribe(result => {
            if (result.success) {
                dialogRef = this.dialog.open(OkDialogComponent, {
                    data: 'Your account details have been changed successfully.' });
            }
            else {
                var dialogRef;

                if (result.data.isUserMissing) {
                    dialogRef = this.dialog.open(OkDialogComponent, { data: result.data.errorMessage });
                    dialogRef.afterClosed().subscribe(x => { this.router.navigate(['/']); })
                }
                else {
                    this.errReceivedEvent.emit(result.data);
                }
            }
        },
            error => {
                this.errReceivedEvent.emit('Some error occured.');
            })
    }
}
