﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { myAccountMainComponent } from './my-account-main.component';
import { myAccountGeneralComponent } from './my-account-general/my-account-general.component';
import { myAccountEmailComponent } from './my-account-email/my-account-email.component';
import { myAccountPasswordComponent } from './my-account-password/my-account-password.component';

import { SharedModule } from "../../shared/shared.module";
import { MyAccountService } from '../../shared/services/my-account.service'

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        BrowserModule,
        SharedModule
    ],    
    declarations: [
        myAccountMainComponent,
        myAccountGeneralComponent,
        myAccountEmailComponent,
        myAccountPasswordComponent
    ],
    exports: [
        myAccountMainComponent,
        myAccountGeneralComponent,
        myAccountEmailComponent,
        myAccountPasswordComponent
    ],
    providers: [
        MyAccountService
    ],
})

export class MyAccountModule {
}