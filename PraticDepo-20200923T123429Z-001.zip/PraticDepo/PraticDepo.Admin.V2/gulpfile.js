const gulp = require('gulp');
const sass = require('gulp-sass');
const concat = require('gulp-concat');
const clean = require('gulp-clean');
const del = require('del');
const sourcemaps = require('gulp-sourcemaps');
const uglify = require('gulp-uglify-es').default;
const pump = require('pump');
const autoprefixer = require('gulp-autoprefixer');
const hash = require('gulp-hash');
const fs = require("fs");

gulp.task('sass:prod', ['sass-compressed'], function () {
    del(['css']);
});

gulp.task('sass:dev', ['sass'], function () {
    del(['css']);
});

gulp.task('sass', function () {
    return gulp.src('./ClientApp/styles/app.scss')
        .pipe(sourcemaps.init())
        .pipe(sass().on('error', sass.logError))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest('./wwwroot/dist'));
});

gulp.task('sass-compressed', function () {
    return gulp.src('./ClientApp/styles/app.scss')
        .pipe(sass({ outputStyle: 'compressed' })).on('error', sass.logError)
        .pipe(gulp.dest('./wwwroot/dist'))
});

gulp.task('sass:watch', function () {
    gulp.watch('./ClientApp/**/*.scss', ['sass:dev']);
});

gulp.task('compress', function (cb) {
    pump([
        gulp.src('./prod/*.js'),
        uglify(),
        gulp.dest('prod')
    ],
        cb
    );
});

gulp.task('del-temp', function () {
    del(['css']);
});
