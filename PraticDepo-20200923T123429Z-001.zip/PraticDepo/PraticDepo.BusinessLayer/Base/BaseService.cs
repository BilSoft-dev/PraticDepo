﻿using System;
using System.Collections.Generic;
using System.Linq;
using PraticDepo.DAL.Configs;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Repository;

namespace PraticDepo.BusinessLayer.Base
{
    public abstract class BaseService
    {
        public bool IsShedLocation(Guid id)
        {
            return GetShedLocationIds().Contains(id);
        }

        protected Guid ShedLocationId
        {
            get { return GetShedLocationIds().First(); }
        }

        private List<Guid> GetShedLocationIds()
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                return locationRepo.GetBy(h => h.OwnerId == AdminConfig.Id && h.ParentId == null)
                                   .Select(h => h.Id)
                                   .ToList();
            }
        }

        protected Location GetShedLocation()
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                return locationRepo.GetBy(h => h.OwnerId == AdminConfig.Id && h.ParentId == null).First();
            }
        }

        public bool ContainsAdminUserRole(string userId)
        {
            return ContainsRole(userId, ShedRoleConfig.ADMIN_ROLE);
        }

        public bool ContainsShedUserRole(IEnumerable<string> roles)
        {
            return roles.Contains(ShedRoleConfig.SHEDUSER_ROLE);
        }

        public bool ContainsShedUserRole(string userId)
        {
            return ContainsRole(userId, ShedRoleConfig.SHEDUSER_ROLE);
        }

        public bool ContainsRegularUserRole(IEnumerable<string> roles)
        {
            return roles.Contains(ShedRoleConfig.REGULARUSER_ROLE);
        }

        public bool ContainsRegularUserRole(string userId)
        {
            return ContainsRole(userId, ShedRoleConfig.REGULARUSER_ROLE);
        }

        #region Auxiliry methods

        private bool ContainsRole(string userId, string role)
        {
            using (var usersRepo = new UsersRepository())
            {
                var user = usersRepo.GetById(userId);
                var roleDbId = ShedRoleConfig.GetRoleInfo(role).DbId;
                return user.Roles.Any(r => r.RoleId == roleDbId);
            }
        }

        #endregion

        protected bool IsShedCollection(Guid collectionId)
        {
            using (var collectionsRepo = new BaseRepository<Collection>())
            {
                var dbCollection = collectionsRepo.GetById(collectionId);
                if (dbCollection != null)
                {
                    return IsShedCollection(dbCollection);
                }

                return false;
            }
        }

        protected bool IsShedCollection(Collection collection)
        {
            return collection.Home.OwnerId == AdminConfig.Id;
        }
    }
}