﻿using System;
using System.Configuration;
using System.Threading.Tasks;

namespace PraticDepo.BusinessLayer.Facebook
{
    public interface IFacebookService
    {
        Task<FacebookAccount> GetFacebookAccountAsync(string accessToken);
    }
    public class FacebookService : IFacebookService
    {
        private readonly IFacebookClient _facebookClient;

        public FacebookService(IFacebookClient facebookClient)
        {
            _facebookClient = facebookClient;
        }

        public async Task<FacebookAccount> GetFacebookAccountAsync(string accessToken)
        {
            var result = await _facebookClient.GetAsync<dynamic>(accessToken, "me", $"fields=id");
            var account = new FacebookAccount
            {
                Id = result.id
            };
            return account;
        }
    }
}
