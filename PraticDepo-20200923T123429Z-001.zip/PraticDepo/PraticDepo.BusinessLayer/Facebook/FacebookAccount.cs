﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraticDepo.BusinessLayer.Facebook
{
    public class FacebookAccount
    {
        public string Id { get; set; }
    }
}
