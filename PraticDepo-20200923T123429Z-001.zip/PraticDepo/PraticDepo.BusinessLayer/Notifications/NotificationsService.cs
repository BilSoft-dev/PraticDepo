﻿using PraticDepo.BusinessLayer.Item;
using PraticDepo.BusinessLayer.Users;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Repository;
using PushSharp;
using PushSharp.Apple;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;

namespace PraticDepo.BusinessLayer.Notifications
{
    public class NotificationsService
    {
        private readonly string notificationSetting;
        public const string ACTION = "action";
        public const string NO_ACTION = "no_action";
        public NotificationsService()
        {
            notificationSetting = ConfigurationManager.AppSettings["NotificationPush"];
        }

        public class Notification
        {
            public Guid Id { get; set; }
            public Guid? CollectionId { get; set; }
            public string UserId { get; set; }
            public string UserName { get; set; }
            public string Text { get; set; }
            public DateTime CreateAt { get; set; }
            public string Address { get; set; }
            public bool IsRead { get; set; }
            public string NotificationType { get; set; }
            public Guid? RequestId { get; set; }
            public string RequestNumber { get; set; }
            public int? RequestStatus { get; set; }
        }

        public void AddNotification(DAL.AuthContext context, string userId, string text, Guid collectionId, string notificationType)
        {
            context.Notifications.Add(new DAL.Models.Notification
            {
                CreateAt = DateTime.Now,
                Id = Guid.NewGuid(),
                IsReaded = false,
                Text = text,
                UserId = userId,
                CollectionId = collectionId,
                NotificationType = notificationType
            });
        }

        public void AddNotification(string userId, string text, Guid collectionId, string notificationType)
        {
            using (var notificationsRepo = new BaseRepository<DAL.Models.Notification>())
            {
                notificationsRepo.Add(new DAL.Models.Notification
                {
                    CreateAt = DateTime.Now,
                    Id = Guid.NewGuid(),
                    IsReaded = false,
                    Text = text,
                    UserId = userId,
                    CollectionId = collectionId,
                    NotificationType = notificationType
                });
            }

            PushNotification(userId, text);
        }

        public void NotifyItemDeleted(string actorUserId, string collectionOwnerUserId, ICollection<Collaborator> collaborators, Guid collectionId, string itemName, string collectionName)
        {
            var actor = new UsersService().GetUserById(actorUserId);
            string formatString = "<b>{0}</b> deleted item '{1}' from <b>{2}</b>";
            foreach (var collaborator in collaborators.Where(x => x.UserId != actorUserId))
            {
                AddNotification(
                    collaborator.UserId,
                    string.Format(formatString, actor.DisplayName, itemName, collectionName), collectionId, ACTION);
            }
            if (actorUserId != collectionOwnerUserId)
            {
                AddNotification(
                    collectionOwnerUserId,
                    string.Format(formatString, actor.DisplayName, itemName, collectionName), collectionId, ACTION);
            }
        }

        public void NotifyCollectionRenaimed(string actorUserId, string collectionOwnerUserId, ICollection<Collaborator> collaborators, Guid collectionId, string oldName, string newName)
        {
            var actor = new UsersService().GetUserById(actorUserId);
            string formatString = "<b>{0}</b> renamed collection <b>{1}</b> to <b>{2}</b>";
            foreach (var collaborator in collaborators.Where(x => x.UserId != actorUserId))
            {
                AddNotification(collaborator.UserId, string.Format(formatString, actor.DisplayName, oldName, newName), collectionId, ACTION);
            }
            if (actorUserId != collectionOwnerUserId)
            {
                AddNotification(collectionOwnerUserId, string.Format(formatString, actor.DisplayName, oldName, newName), collectionId, ACTION);
            }
        }

        public void NotifyItemRenaimed(string actorUserId, string collectionOwnerUserId, ICollection<Collaborator> collaborators, Guid collectionId, string collectionName, string oldItemName, string newItemName)
        {
            var actor = new UsersService().GetUserById(actorUserId);
            string formatString = "<b>{0}</b> renamed item '{1}' to '{2}' in the collection <b>{3}</b>";
            foreach (var collaborator in collaborators.Where(x => x.UserId != actorUserId))
            {
                AddNotification(collaborator.UserId, string.Format(formatString, actor.DisplayName, oldItemName, newItemName, collectionName), collectionId, ACTION);
            }
            if (actorUserId != collectionOwnerUserId)
            {
                AddNotification(collectionOwnerUserId, string.Format(formatString, actor.DisplayName, oldItemName, newItemName, collectionName), collectionId, ACTION);
            }
        }

        public void NotifyItemAdded(string actorUserId, string collectionOwnerUserId, ICollection<Collaborator> collaborators, Guid collectionId, string itemName, string collectionName)
        {
            var actor = new UsersService().GetUserById(actorUserId);
            string formatString = "<b>{0}</b> added item '{1}' to collection <b>{2}</b>";
            foreach (var collaborator in collaborators.Where(x => x.UserId != actorUserId))
            {
                AddNotification(collaborator.UserId, string.Format(formatString, actor.DisplayName, itemName, collectionName), collectionId, ACTION);
            }
            if (actorUserId != collectionOwnerUserId)
            {
                AddNotification(collectionOwnerUserId, string.Format(formatString, actor.DisplayName, itemName, collectionName), collectionId, ACTION);
            }
        }

        public void MaskAsRead(Guid id, string userId)
        {
            using (var notificationsRepo = new BaseRepository<DAL.Models.Notification>())
            {
                var notification = notificationsRepo.GetById(id);
                if (notification == null)
                    throw new Exception("Notification not found");

                if (notification.UserId != userId)
                    throw new Exception("You don't have permissions for mark this notification as readed");

                notification.IsReaded = true;

                notificationsRepo.Update(notification);
            }
        }

        public ICollection<Notification> GetUserNotifications(string userId)
        {
            List<Notification> list;
            using (var notificationsRepo = new BaseRepository<DAL.Models.Notification>())
            {
                var tst = notificationsRepo.GetBy(x => x.UserId == userId);
                list = notificationsRepo.GetBy(x => x.UserId == userId).Select(x => new Notification
                {
                    CollectionId = x.CollectionId,
                    CreateAt = x.CreateAt,
                    Id = x.Id,
                    IsRead = x.IsReaded,
                    Text = x.Text,
                    UserId = x.UserId,
                    NotificationType = x.NotificationType,
                    RequestId = x.RequestId
                    //Address = x.Collection != null ? (x.Collection.Items != null && x.Collection.Items.Any() ? x.Collection.Items.First().Address : string.Empty) : string.Empty
                }).ToList();
            }

            using (UsersRepository usersRepository = new UsersRepository())
            {
                using (var collectionRepository = new BaseRepository<Collection>())
                {
                    using (var deliveryRequestsRepository = new BaseRepository<DeliveryRequest>())
                    {
                        foreach (var notification in list)
                        {
                            if (notification.CollectionId.HasValue && notification.CollectionId != Guid.Empty)
                            {
                                var collection = collectionRepository.GetById(notification.CollectionId.Value);

                                if (collection != null)
                                {
                                    notification.Address = LocationService.getCollectionAddress(collection);
                                }
                            }

                            if (notification.RequestId.HasValue && notification.RequestId != Guid.Empty)
                            {
                                var deliveryRequest = deliveryRequestsRepository.GetById(notification.RequestId.Value);
                                if (deliveryRequest != null)
                                {
                                    notification.RequestNumber = deliveryRequest.RequestNumber;
                                    notification.RequestStatus = deliveryRequest.Status;
                                }
                            }

                            if (!string.IsNullOrEmpty(notification.UserId))
                            {
                                var userName = usersRepository.GetUserName(notification.UserId);
                                if (string.IsNullOrEmpty(userName.Trim()))
                                {
                                    userName = usersRepository.GetUserEmail(notification.UserId);
                                }
                                notification.UserName = userName;
                            }
                        }
                    }
                }
            }

            return list.ToList();
        }



        /*public IQueryable<Notification> GetCollectionNotifications(Guid collectionId)
        {
            return notificationsRepo.GetBy(x => x.CollectionId == collectionId).Select(x => new Notification
            {
                CollectionId = x.CollectionId,
                CreateAt = x.CreateAt,
                Id = x.Id,
                IsRead = x.IsReaded,
                Text = x.Text,
                UserId = x.UserId,
                Address = x.Collection != null ? LocationService.getCollectionAddress(x.Collection) : string.Empty
            }); ;
        }*/

        public void RemoveNotification(Guid id, string userId)
        {
            using (var notificationsRepo = new BaseRepository<DAL.Models.Notification>())
            {
                var notification = notificationsRepo.GetById(id);

                if (notification.UserId != userId)
                    throw new Exception("You don't have permissions for delete notification");

                notificationsRepo.Delete(id);
            }
        }

        private void PushNotification(string userId, string text)
        {
            string token;
            using (var usersRepository = new UsersRepository())
            {
                var user = usersRepository.GetById(userId);
                if (user == null)
                {
                    throw new ArgumentException("User not found");
                }
                else
                {
                    token = user.PushToken;
                }
            }

            if (!string.IsNullOrWhiteSpace(token))
            {
                var push = new PushBroker();
                var appleCert = File.ReadAllBytes(HttpContext.Current.Server.MapPath("/cert/pratikPushes.p12"));

                push.OnNotificationSent += push_OnNotificationSent;
                push.OnNotificationFailed += push_OnNotificationFailed;

                push.RegisterAppleService(new PushSharp.Apple.ApplePushChannelSettings(appleCert, notificationSetting));
                push.QueueNotification(new AppleNotification()
                    .ForDeviceToken(token)
                    .WithAlert(text));
            }
        }

        void push_OnNotificationFailed(object sender, PushSharp.Core.INotification notification, Exception error)
        {
            var log = System.IO.File.AppendText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "/logs/pushes.log"));
            //var log = System.IO.File.AppendText(HttpContext.Current.Server.MapPath("/logs/pushes.log"));
            log.WriteLine(string.Format("[{0}] - Notification fail. Details: {4}. Tag: '{2}'. Queued count: {1}. Is valid Device registration: {3}.", DateTime.Now.ToString("dd.MM.YYYY hh:mm:ss"), notification.QueuedCount, notification.Tag, notification.IsValidDeviceRegistrationId(), error.ToString()));
            log.Flush();
        }

        void push_OnNotificationSent(object sender, PushSharp.Core.INotification notification)
        {
#if DEBUG
            //var log = System.IO.File.AppendText(HttpContext.Current.Server.MapPath("/logs/pushes.log"));
            var log = System.IO.File.AppendText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "/logs/pushes.log"));
            log.WriteLine(string.Format("[{0}] - Notification sent. Tag: '{2}'. Queued count: {1}. Is valid Device registration: {3}.", DateTime.Now.ToString("dd.MM.YYYY hh:mm:ss"), notification.QueuedCount, notification.Tag, notification.IsValidDeviceRegistrationId()));
            log.Flush();
#endif
        }
    }
}