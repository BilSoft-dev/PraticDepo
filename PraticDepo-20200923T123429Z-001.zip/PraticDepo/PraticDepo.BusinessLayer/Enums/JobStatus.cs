﻿namespace PraticDepo.BusinessLayer.Enums
{
    public enum JobStatus
    {
        NotStarted = 0,
        InProgress = 1,
        Finished = 2,
        Cancelled = 3
    }
}
