﻿using PraticDepo.BusinessLayer.Notifications;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using PraticDepo.BusinessLayer.Users;
using PraticDepo.DAL.Configs;
using PraticDepo.BusinessLayer.Enums;

namespace PraticDepo.BusinessLayer.Item
{
    public class ItemsService : Base.BaseService
    {
        public class CollectionItemNote
        {
            //public Guid Id { get; set; }
            public string Text { get; set; }
        }

        public class Home
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public double Latitude { get; set; }
            public double Longitude { get; set; }
            public int ItemsCount { get; set; }
        }

        public class CollectionItem
        {
            public Guid Id {get;set;}
            public string Name {get;set;}
            public List<MediaService.MediaModel> Media {get;set;} 
            public Guid? CollectionId { get; set; }
            public DateTime CreateDate { get; set; }
            public string Barcode { get; set; }
            public decimal? Volume { get; set; }
            public int Status { get; set; }
            public bool? IsLoaded { get; set; }
        }

        public class Collection
        {
            public Guid Id { get; set; }
            public string UserId { get; set; }
            public string OwnerFirstName { get; set; }
            public string OwnerLastName { get; set; }
            public DateTime CreateAt { get; set; }
            public string Name { get; set; }
            public List<CollectionItem> Items { get; set; }
            public string Address { get; set; }
            public string City { get; set; }
            public Guid HomeId { get; set; }
            public string HomeName { get; set; }
            public double HomeLatitude { get; set; }
            public double HomeLongitude { get; set; }
            public Guid? RoomId { get; set; }
            public string RoomName { get; set; }
            public Guid? RoomPartId { get; set; }
            public string RoomPartName { get; set; }
            public string Notes { get; set; }
            public string Barcode { get; set; }
            public decimal? Volume { get; set; }
            public bool IsShedCollection { get; set; }
            public int LocationLevelPermissions { get; set; }
            public int Status { get; set; }
            public string StorageLocation { get; set; }
            public string BinNumber { get; set; }
            public string PhotoFileName { get; set; }
            public bool? IsLoaded { get; set; }

            public List<UsersService.UserCollaborator> Collaborators { get; set; }
        }
        
        public void EnsureCanAddItem(string userId, string role, Guid collectionId)
        {
            var collection = GetCollection(userId, role, collectionId);
            if (!Permissions.CollectionLevel.CanAddMoreItems(role, collection.UserId != userId, collection.IsShedCollection))
            {
                throw new Exception("A user doesn't have permission to add more items to this collection.");
            }
        }

        public void EnsureCanCreateWithBarcodeVolume(string role, string barcode, decimal? volume)
        {
            if (!string.IsNullOrEmpty(barcode) || (volume.HasValue && volume.Value != 0))
            {
                if (!Permissions.UserLevel.CanCreateWithBarcodeVolume(role))
                {
                    throw new Exception("A user doesn't have permission to create with Barcode and Volume.");
                }
            }
        }

        public void EnsureCanCreateWithUnitNumber(string role, string storageLocation, string binNumber)
        {
            if (!string.IsNullOrEmpty(storageLocation) || !string.IsNullOrEmpty(binNumber))
            {
                if (!Permissions.UserLevel.CanCreateWithBarcodeVolume(role))
                {
                    throw new Exception("A user doesn't have permission to create with storage location and bin number.");
                }
            }
        }

        public Guid AddItem(Guid mediaId, Guid collectionId, string name, string userId, string barcode, decimal? volume, string role)
        {
            EnsureCanCreateWithBarcodeVolume(role, barcode, volume);

            using (var itemRepository = new BaseRepository<DAL.Models.Item>())
            {
                var id = itemRepository.Add(new DAL.Models.Item
                {
                    CreateDate = DateTime.Now,
                    Id = Guid.NewGuid(),
                    Name = name,
                    UserId = userId,
                    CollectionId = collectionId,
                    Barcode = barcode,
                    Volume = volume
                });


                if (id != null && id != Guid.Empty && mediaId != null && mediaId != Guid.Empty)
                {
                    using (var mediaRepository = new BaseRepository<DAL.Models.Media>())
                    {
                        var media = mediaRepository.GetById(mediaId);
                        if (media != null)
                        {
                            if (!media.ItemId.HasValue)
                            {
                                media.ItemId = id;
                                mediaRepository.Update(media);
                            }
                        }
                    }
                }

                var item = itemRepository.GetById(id);
                if (collectionId != Guid.Empty)
                {
                    using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
                    {
                        var collection = collectionsRepo.GetById(collectionId);
                        if (collection == null)
                        {
                            var collectionItem = new DAL.Models.Collection
                            {
                                Id = Guid.NewGuid(),
                                Name = "New collection",
                                Items = new List<PraticDepo.DAL.Models.Item>(),
                                UserId = userId,
                                CreateAt = DateTime.Now
                            };
                            //collectionItem.Items.Add(item);
                            var colId = collectionsRepo.Add(collectionItem);

                            item.CollectionId = colId;
                            itemRepository.Update(item);
                        }
                        else
                        {
                            item.CollectionId = collection.Id;
                            itemRepository.Update(item);

                            // moved to controller 
                            /*if(collection.Collaborators != null && collection.Collaborators.Any())
                        {
                            var notificationsService = new NotificationsService();
                            foreach(var collaborator in collection.Collaborators)
                            {
                                notificationsService.AddNotification(collaborator.UserId, string.Format("Added item '{0}' to collection {1}", name, collection.Name), collectionId);
                            }
                        }*/
                        }

                        if(collection.Collaborators != null && collection.Collaborators.Any())
                        {
                            new NotificationsService().NotifyItemAdded(userId, collection.UserId, collection.Collaborators.ToList(), collection.Id, name, collection.Name);
                        }

                    }
                }
                
                using (var userJobsRepo = new BaseRepository<DAL.Models.UserJob>())
                {
                    var startedUserJob = userJobsRepo.GetBy(uj => uj.UserId == userId && uj.Status == (int)JobStatus.InProgress).FirstOrDefault();

                    if (startedUserJob != null)
                    {
                        var currentDateTime = DateTime.Now;
                        foreach (var userJob in startedUserJob.Job.UserJobs)
                        {
                            userJob.DatePackingActualFinish = currentDateTime;
                            userJobsRepo.Update(userJob);
                        }
                    }
                }

                return id;
            }
        }

        public Collection AddCollection(string name, string userId, Guid homeId, Guid? roomId, Guid? roomPartId, string note, string barcode, decimal? volume, string role, string storageLocation, string binNumber)
        {
            EnsureCanCreateWithBarcodeVolume(role, barcode, volume);
            EnsureCanCreateWithUnitNumber(role, storageLocation, binNumber);
            EnsureUserCanAddCollection(userId, role);

            Collection resultCollection = null;

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var dbCollection = new DAL.Models.Collection
                {
                    CreateAt = DateTime.Now,
                    Id = Guid.NewGuid(),
                    Name = name,
                    HomeId = homeId,
                    RoomId = roomId,
                    RoomPartId = roomPartId,
                    UserId = userId,
                    Note = note,
                    Barcode = barcode,
                    Volume = volume,
                    BinNumber = binNumber,
                    StorageLocation = storageLocation
                };
                var collectioId = collectionsRepo.Add(dbCollection);
                if (collectioId != Guid.Empty)
                {
                    resultCollection = GetCollection(userId, role, collectioId);
                }
            }

            using (var userJobsRepo = new BaseRepository<DAL.Models.UserJob>())
            {
                var startedUserJob = userJobsRepo.GetBy(uj => uj.UserId == userId && uj.Status == (int)JobStatus.InProgress).FirstOrDefault();

                if (startedUserJob != null)
                {
                    using (var jobCollectionsRepo = new BaseRepository<DAL.Models.JobCollection>())
                    {
                        jobCollectionsRepo.Add(new JobCollection
                        {
                            Id = Guid.NewGuid(),
                            CollectionId = resultCollection.Id.ToString(),
                            JobId = startedUserJob.JobId
                        });
                    }

                    var jobRelatedUserIds = startedUserJob.Job.UserJobs.Where(uj => uj.UserId != userId && uj.Status == (int)JobStatus.InProgress).Select(uj => uj.UserId).ToList();
                    var userService = new UsersService();

                    foreach (var id in jobRelatedUserIds)
                    {
                        userService.AddCollaborator(userId, id, resultCollection.Id, false);
                    }

                    var client = userService.GetUserByEmail(startedUserJob.Job.ClientEmail);
                    if (client != null)
                    {
                        userService.AddCollaborator(userId, client.Id, resultCollection.Id, false);
                    }
                }
            }

            return resultCollection;
        }

        private Guid GetCollaboratorByUserId(string userId)
        {
            Guid collaboratorId;
            using (var collaboratorRepo = new BaseRepository<Collaborator>())
            {
                var collaborator = collaboratorRepo.GetSingleBy(x => x.UserId == userId);
                if (collaborator == null)
                {
                    using (var usersRepo = new UsersRepository())
                    {
                        var user = usersRepo.GetById(userId);
                        if (user != null)
                        {
                            collaboratorId = collaboratorRepo.Add(new Collaborator
                            {
                                Id = Guid.NewGuid(),
                                UserId = userId,
                                Email = user.Email,
                                Name = string.Format("{0} {1}", user.FirstName, user.LastName).Trim()
                            });
                        }
                        else
                        {
                            throw new Exception("User not found");
                        }
                    }
                }
                else
                {
                    collaboratorId = collaborator.Id;
                }
            }

            return collaboratorId;
        }

        /*public void AttachItemToRoomPart(Guid roomPart, Guid itemId)
        {
            var item = itemRepository.GetById(itemId);
            if (item != null)
            {
                item.LocationId = roomPart;
                itemRepository.Update(item);
            }
        }*/

        public ICollection<CollectionItem> GetItemsByUser(string userId)
        {
            if (string.IsNullOrEmpty(userId))
                throw new ArgumentException("Some authorization error. UserId can't be null or empty");
            using (var itemRepository = new BaseRepository<DAL.Models.Item>())
            {
                return itemRepository.GetBy(x => x.UserId == userId).Select(item => new CollectionItem
                {

                    Id = item.Id,
                    Name = item.Name,
                    Media = item.Media.Select(media => new MediaService.MediaModel()
                    {
                        Id = media.Id,
                        FilePath = media.FileName,
                        Type = (MediaService.MediaType)media.Type,
                        Duration = Math.Round(media.Duration, 2),
                    }).ToList(),
                    Barcode = item.Barcode,
                    Volume = item.Volume
                }).ToList();
            }
        }

        public Collection GetCollectionById(Guid collectionId)
        {
            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var dbCollection = collectionsRepo.GetById(collectionId);
                if (dbCollection == null)
                {
                    throw new Exception("Collection not found");
                }
                var result = new Collection()
                {
                    Id = dbCollection.Id,
                    Name = dbCollection.Name,
                    CreateAt = dbCollection.CreateAt,
                    HomeId = dbCollection.HomeId,
                    RoomId = dbCollection.RoomId,
                    Barcode = dbCollection.Barcode,
                    Volume = dbCollection.Volume
                };
                return result;
            }
            
        }

        public CollectionItem GetItem(Guid itemId)
        {
            CollectionItem result = null;
            using (var itemsRepo = new BaseRepository<DAL.Models.Item>())
            {
                var item = itemsRepo.GetById(itemId);

                if (item == null)
                {
                    throw new Exception("The item no longer exists.");
                }

                result = new CollectionItem()
                {
                    CollectionId = item.CollectionId,
                    Name = item.Name,
                    CreateDate = item.CreateDate,
                    Id = item.Id,
                    Media = item.Media.Select(media => new MediaService.MediaModel()
                    {
                        Id = media.Id,
                        FilePath = media.FileName,
                        Type = (MediaService.MediaType)media.Type,
                        Duration = Math.Round(media.Duration, 2)
                    }).ToList(),
                    Barcode = item.Barcode,
                    Volume = item.Volume,
                    Status = GetDeliveryStatus(item.Status)
                };
            }
            if (result != null)
            {
                if (result.Media.Any(m => m.Type == MediaService.MediaType.VIDEO))
                {
                    foreach (var media in result.Media.Where(m => m.Type == MediaService.MediaType.VIDEO))
                    {
                        media.Chapters = GetVideoChapters(media.Id).ToList();
                    }
                }
            }
            return result;
        }

        #region GetCollection functionality
        
        public List<Collection> GetUserCollections(string userId, string role, Guid collectionToExclude)
        {
            var result = new List<Collection>();

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var dbCollections = collectionsRepo.GetBy(x => x.Id != collectionToExclude && collectionToExclude != Guid.Empty && (x.UserId == userId || x.Collaborators.Any(c => c.UserId == userId)));
                if (!dbCollections.Any())
                {
                    throw new Exception("Collection not found or you are not authorized to work with this collection");
                }

                foreach (var collection in dbCollections)
                {
                    result.Add(GetCollection(userId, role, collection));
                }
            }

            return result;
        }

        public Collection GetCollection(string userId, string role, Guid collectionId)
        {
            if (collectionId == Guid.Empty)
                throw new ArgumentException("CollectionId can't be null or empty");
            
            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var dbCollection = collectionsRepo.GetSingleBy(x => x.Id == collectionId);

                if (dbCollection == null)
                {
                    throw new Exception("The collection no longer exists.");
                }

                dbCollection = collectionsRepo.GetSingleBy(x => x.Id == collectionId && (x.UserId == userId || x.Collaborators.Any(c => c.UserId == userId)));
                if (dbCollection == null)
                {
                    throw new Exception("You are not authorized to work with this collection");
                }

                return GetCollection(userId, role, dbCollection);
            }
        }

        private Collection GetCollection(string userId, string role, DAL.Models.Collection dbCollection)
        {
            var result = new Collection
            {
                Items = dbCollection.Items.ToList().Select(item => new CollectionItem
                {
                    Id = item.Id,
                    Name = item.Name,
                    CollectionId = item.CollectionId,
                    CreateDate = item.CreateDate,
                    Barcode = item.Barcode,
                    Volume = item.Volume,
                    Media = item.Media.Select(media => new MediaService.MediaModel()
                    {
                        Id = media.Id,
                        FilePath = media.FileName,
                        Type = (MediaService.MediaType)media.Type,
                        Duration = Math.Round(media.Duration, 2),

                    }).ToList(),
                    Status = GetDeliveryStatus(item.Status),
                    IsLoaded = item.IsLoaded
                }).OrderBy(x => x.CreateDate).ToList(),
                Name = dbCollection.Name,
                Notes = dbCollection.Note,
                Collaborators = dbCollection.Collaborators.Select(collaborator => new UsersService.UserCollaborator
                {
                    Id = collaborator.Id,
                    UserId = collaborator.UserId,
                    Name = collaborator.Name,
                    Email = collaborator.Email,
                    CollectionId = dbCollection.Id
                }).ToList(),
                Id = dbCollection.Id,
                UserId = dbCollection.UserId,
                OwnerFirstName = dbCollection.User.FirstName,
                OwnerLastName = dbCollection.User.LastName,
                CreateAt = dbCollection.CreateAt,
                City = dbCollection.Home.City,
                HomeId = dbCollection.HomeId,
                HomeName = dbCollection.Home.Name,
                HomeLatitude = dbCollection.Home.Latitude,
                HomeLongitude = dbCollection.Home.Longitude,
                RoomId = dbCollection.RoomId,
                RoomName = dbCollection.RoomId != null ? dbCollection.Room.Name : string.Empty,
                RoomPartId = dbCollection.RoomPartId,
                RoomPartName = dbCollection.RoomPartId != null ? dbCollection.RoomPart.Name : string.Empty,
                Barcode = dbCollection.Barcode,
                Volume = dbCollection.Volume,
                IsShedCollection = IsShedCollection(dbCollection),
                LocationLevelPermissions = new LocationService().GetLocationPermissionsMaskForHome(userId, role, dbCollection.Home),
                Status = GetDeliveryStatus(dbCollection.Status),
                BinNumber = dbCollection.BinNumber,
                StorageLocation = dbCollection.StorageLocation,
                PhotoFileName = dbCollection.Photos.FirstOrDefault()?.FileName ?? string.Empty,
                IsLoaded = dbCollection.IsLoaded
            };
            result.Address = LocationService.getCollectionAddress(result);
            foreach (CollectionItem item in result.Items)
            {
                if (item.Media.Any(m => m.Type == MediaService.MediaType.VIDEO))
                {
                    foreach (var media in item.Media.Where(m => m.Type == MediaService.MediaType.VIDEO))
                    {
                        media.Chapters = GetVideoChapters(media.Id).ToList();
                    }
                }
            }
            return result;
        }

        public int GetDeliveryStatus(int? dbStatus)
        {
            if (!dbStatus.HasValue) return 0; // collection/item isn't added to a request

            if (dbStatus.Value == 3) return 2; // Delivered. Collection/item is delivered
            if (dbStatus.Value == 4) return 3; // Cancelled. Collection/item request is cancelled
            if (dbStatus.Value == 1) return 4; // Submitted. Collection/item is not picked
            if (dbStatus.Value == 2) return 5; // On Delivery. Collection/item is picked

            return 1; // collection/item is added to a request
        }

        #endregion

        public ICollection<Collection> GetJobCollections(string userId, string role, Guid jobId)
        {
            var collectionIds = new List<Guid>();
            using (var jobCollectionRepo = new BaseRepository<DAL.Models.JobCollection>())
            {
                var collectionIdsAsString = jobCollectionRepo.GetBy(jc => jc.JobId == jobId, true).Select(c => c.CollectionId).ToList();
                foreach (var idAsString in collectionIdsAsString)
                {
                    collectionIds.Add(Guid.Parse(idAsString));
                }
            }

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var collections = collectionsRepo.GetBy(x => collectionIds.Contains(x.Id) && x.Items.Any(), true).ToList();
                var list = new List<Collection>();
                foreach (var c in collections)
                {
                    var collection = GetCollection(userId, role, c);
                    list.Add(collection);
                }

                return list.OrderByDescending(x => x.CreateAt).ToList();
            }
        }

        public ICollection<Collection> GetUserJobCollections(string userId, string role)
        {
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentException("UserId can't be null or empty");
            }

            var collectionIds = new List<Guid>();
            using (var jobUserRepo = new BaseRepository<DAL.Models.UserJob>())
            {
                var userJob = jobUserRepo.GetBy(ju => ju.UserId == userId && ju.Status == (int)JobStatus.InProgress, true).FirstOrDefault();
                using (var jobCollectionRepo = new BaseRepository<DAL.Models.JobCollection>())
                {
                    var collectionIdsAsString = jobCollectionRepo.GetBy(jc => jc.JobId == userJob.JobId, true).Select(c => c.CollectionId).ToList();
                    foreach (var idAsString in collectionIdsAsString)
                    {
                        collectionIds.Add(Guid.Parse(idAsString));
                    }
                }
            }

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var collections = collectionsRepo.GetBy(x => collectionIds.Contains(x.Id)).ToList();
                var list = new List<Collection>();
                foreach (var c in collections)
                {
                    var collection = GetCollection(userId, role, c);
                    list.Add(collection);
                }

                return list.OrderByDescending(x => x.CreateAt).ToList();
            }
        }

        public ICollection<Collection> GetUserCollections(string UserId, string role)
        {
            if (string.IsNullOrEmpty(UserId))
            {
                throw new ArgumentException("UserId can't be null or empty");
            }

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var collections = collectionsRepo.GetBy(x => (x.UserId == UserId || x.Collaborators.Any(c => c.UserId == UserId)) && x.Items.Any(), true).ToList();
                var list = new List<Collection>();
                foreach (var c in collections)
                {
                    using (var jobCollectionRepo = new BaseRepository<DAL.Models.JobCollection>())
                    {
                        var jobsByCollectionId = jobCollectionRepo.GetBy(jc => jc.CollectionId == c.Id.ToString(), true).ToList();
                        if (jobsByCollectionId != null && jobsByCollectionId.Any(x => x.Job.Status == (int)JobStatus.InProgress))
                        {
                            continue;
                        }

                        var collection = GetCollection(UserId, role, c);
                        if (Permissions.CollectionLevel.CanSeeCollection(role, collection.UserId != UserId, collection.IsShedCollection))
                        {
                            list.Add(collection);
                        }
                    }

                }

                return list.OrderByDescending(x => x.CreateAt).ToList();
            }
        }
        
        public void UpdateItemsCollection(string userId, string role, List<Guid> item, Guid newCollectionId)
        {
            using(var itemRepository = new BaseRepository<DAL.Models.Item>())
            {
                using(var dbContextTransaction = itemRepository.Context.Database.BeginTransaction())
                {
                    try
                    {
                        var dbCollection = GetCollection(userId, role, newCollectionId);
                        if (dbCollection == null)
                            throw new Exception("Collection not found");
                        
                        foreach (var itemId in item)
                        {
                            var itemModel = itemRepository.GetById(itemId, true);
                            if (itemModel == null)
                                throw new Exception("item not found");

                            itemModel.CollectionId = newCollectionId;
                            itemRepository.Update(itemModel);
                        }
                        dbContextTransaction.Commit();

                    }
                    catch (Exception)
                    {
                        dbContextTransaction.Rollback();
                    }
                }
            }
        }

        public void EnsureCanDeleteItem(string userId, string role, Guid collectionId)
        {
            var collection = GetCollection(userId, role, collectionId);
            if (!Permissions.CollectionLevel.CanDeleteItem(role, collection.UserId != userId, collection.IsShedCollection))
            {
                throw new Exception("A user doesn't have permissions to remove items.");
            }
        }

        public void DeleteItem(string userId, string role, Guid itemId)
        {
            using (var itemRepository = new BaseRepository<DAL.Models.Item>())
            {
                using (var deliveryRequestItemRepo = new BaseRepository<DAL.Models.DeliveryRequestCollectionItem>())
                {
                    var drItems = deliveryRequestItemRepo.GetBy(x => x.ItemId == itemId).ToList();
                    if (drItems.Any())
                    {
                        deliveryRequestItemRepo.Delete(drItems);
                    }
                }

                var item = itemRepository.GetById(itemId, true);

                if (item == null)
                {
                    throw new Exception("The item no longer exists.");
                }

                IEnumerable<Collaborator> collaborators = null;
                string collectionOwnerId = string.Empty;
                Guid collectionId = Guid.Empty;
                string collectionName = string.Empty;
                if (item.Collection != null && item.Collection.Collaborators != null && item.Collection.Collaborators.Any())
                {
                    collectionId = item.CollectionId;
                    collectionName = item.Collection.Name;
                    collectionOwnerId = item.Collection.UserId;
                    collaborators = item.Collection.Collaborators;
                }

                if (item.Media != null && item.Media.Any())
                {
                    var mediaService = new MediaService();
                    foreach (var media in item.Media)
                        mediaService.DeleteItem(media.Id);
                }

                itemRepository.Delete(itemId);

                if (collaborators != null)
                {
                    new NotificationsService().NotifyItemDeleted(userId, collectionOwnerId, collaborators.ToList(), collectionId, item.Name, collectionName);
                    //var actor = new UsersService().GetUserById(userId);
                    //var notificationsService = new NotificationsService();
                    //string formatString = "<b>{0}</b> deleted item '{1}' from <b>{2}</b>";
                    //foreach (var collaborator in collaborators.Where(x => x.UserId != userId))
                    //{
                    //    notificationsService.AddNotification(
                    //        collaborator.UserId,
                    //        string.Format(formatString, actor.DisplayName, item.Name, collectionName), collectionId, NotificationsService.ACTION);
                    //}
                    //if(userId != collectionOwnerId)
                    //{
                    //    notificationsService.AddNotification(
                    //        userId,
                    //        string.Format(formatString, actor.DisplayName, item.Name, collectionName), collectionId, NotificationsService.ACTION);
                    //}
                }

                var collection = GetCollection(userId, role, item.CollectionId);
                if (!collection.Items.Any())
                {
                    RemoveCollection(userId, role, collection.Id);
                }
            }
        }

        public void AttachMediaToItem(Guid mediaId, Guid itemId)
        {
            if (mediaId == null || mediaId == Guid.Empty)
                throw new ArgumentException("'MediaId' can't be null or empty");
            if (itemId == null || itemId == Guid.Empty)
                throw new ArgumentException("'ItemId' can't be null or empty");

            using (var itemRepository = new BaseRepository<DAL.Models.Item>())
            {
                var item = itemRepository.GetById(itemId);
                if (item == null)
                    throw new Exception("Item not found");
            }
            using (var mediaRepository = new BaseRepository<Media>())
            {
                var media = mediaRepository.GetById(mediaId);
                media.ItemId = itemId;
                mediaRepository.Update(media);
            }
        }

        public Guid RenameCollection(Guid collectionId, string newName, string userId)
        {
            string oldName = string.Empty;
            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {

                var collection = collectionsRepo.GetById(collectionId);
                if (collection == null)
                {
                    throw new Exception("Collection not found");
                }
                else
                {
                    oldName = collection.Name;
                    collection.Name = newName;
                    collectionsRepo.Update(collection);

                    if (collection.Collaborators != null && collection.Collaborators.Any())
                    {
                        new NotificationsService().NotifyCollectionRenaimed(userId, collection.UserId, collection.Collaborators.ToList(), collectionId, oldName, newName);
                        //var actor = new UsersService().GetUserById(userId);
                        //foreach (var collaborator in collection.Collaborators)
                        //{
                        //    new NotificationsService().AddNotification(collaborator.UserId,
                        //        string.Format("<b>{0}</b> renamed collection <b>{1}</b> to <b>{2}</b>", actor.DisplayName, oldName, newName), collectionId, NotificationsService.ACTION);
                        //}
                    }
                    return collectionId;
                }
            }
        }

        public void EnsureCanRemoveCollection(string role, bool isCollaborator, bool isShedCollection)
        {
            if (!Permissions.CollectionLevel.CanDeleteCollection(role, isCollaborator, isShedCollection))
            {
                throw new Exception("Regular User Collaborator can't remove collections from Shed Storage.");
            }
        }

        public void RemoveCollection(string userId, string role, Guid collectionId)
        {
            using (var deliveryRequestCollectionRepo = new BaseRepository<DAL.Models.DeliveryRequestCollection>())
            {
                var drCollections = deliveryRequestCollectionRepo.GetBy(x => x.CollectionId == collectionId).ToList();
                if (drCollections.Any())
                {
                    deliveryRequestCollectionRepo.Delete(drCollections);
                }
            }

            var items = GetCollection(userId, role, collectionId).Items;
            if (items != null)
            {
                var mediaService = new MediaService();
                foreach (var item in items)
                {
                    if (item.Media != null && item.Media.Any())
                    {
                        foreach (var media in item.Media)
                            mediaService.DeleteItem(media.Id);
                    }
                    using (var itemsRepo = new BaseRepository<DAL.Models.Item>())
                    {
                        itemsRepo.Delete(item.Id);
                    }
                }
            }
            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                collectionsRepo.Delete(collectionId);
            }
        }

        public void RenameCollectionItem(string userId, string role, Guid itemId, string name)
        {
            using (var itemRepository = new BaseRepository<DAL.Models.Item>())
            {
                var item = itemRepository.GetById(itemId);
                if (item == null)
                    throw new Exception("Item not found");
                
                if (!string.IsNullOrEmpty(name) && name != item.Name)
                {
                    if (!Permissions.CollectionLevel.CanEditItemNames(role, item.Collection.UserId != userId, IsShedCollection(item.Collection)))
                    {
                        throw new Exception("A user doesn't have permission to edit item name.");
                    }

                    string oldName = item.Name;
                    item.Name = name;
                    itemRepository.Update(item);

                    if (item.Collection != null && item.Collection.Collaborators != null && item.Collection.Collaborators.Any())
                    {
                        new NotificationsService().NotifyItemRenaimed(userId, item.Collection.UserId, item.Collection.Collaborators.ToList(), item.CollectionId, item.Collection.Name, oldName, name);
                    }
                }
            }
        }

        public void UpdateCollectionItemInfo(string userId, string role, Guid itemId, string name, string barcode, decimal? volume)
        {
            RenameCollectionItem(userId, role, itemId, name);
            using (var itemRepository = new BaseRepository<DAL.Models.Item>())
            {
                var item = itemRepository.GetById(itemId);
                if (item == null)
                    throw new Exception("Item not found");

                if (barcode != item.Barcode && !ExistBarcode(barcode))
                {
                    if (!Permissions.CollectionLevel.CanEditBarcodeVolumeUnit(role, item.Collection.UserId != userId, IsShedCollection(item.Collection)))
                    {
                        throw new Exception("A user doesn't have permission to edit item barcode.");
                    }

                    item.Barcode = barcode;
                    item.IsLoaded = false;
                    itemRepository.Update(item);
                }

                if (volume != item.Volume)
                {
                    if (!Permissions.CollectionLevel.CanEditBarcodeVolumeUnit(role, item.Collection.UserId != userId, IsShedCollection(item.Collection)))
                    {
                        throw new Exception("A user doesn't have permission to edit item volume.");
                    }

                    item.Volume = volume;
                    itemRepository.Update(item);
                }
            }
        }

        public ICollection<MediaService.Chapter> GetVideoChapters(Guid videoId)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                return chaptersRepo.GetBy(ch => ch.VideoId == videoId).ToList().Select(c => new MediaService.Chapter
                {
                    Cover = c.Cover != null ? c.Cover.FileName : string.Empty,
                    Id = c.Id,
                    Name = c.Name,
                    Time = c.Time,
                    Barcode = c.Barcode,
                    Volume = c.Volume,
                    Status = GetDeliveryStatus(c.Status)
                }).ToList();
            }
        }

        public ICollection<Collection> GetCollectionsOnRoomPart(Guid roomPartId)
        {
            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var result =
                    collectionsRepo.GetBy(x => x.RoomPartId.Value == roomPartId).Select(dbCollection => new Collection
                    {
                        Items = dbCollection.Items.Select(item => new CollectionItem
                        {
                            Id = item.Id,
                            Name = item.Name,
                            Media = item.Media.Select(media => new MediaService.MediaModel()
                            {
                                Id = media.Id,
                                FilePath = media.FileName,
                                Type = (MediaService.MediaType) media.Type,
                                Duration = Math.Round(media.Duration, 2)
                            }).ToList(),
                            Barcode = item.Barcode,
                            Volume = item.Volume
                        }).ToList(),
                        Name = dbCollection.Name,
                        Notes = dbCollection.Note,
                        Collaborators =
                            dbCollection.Collaborators.Select(collaborator => new UsersService.UserCollaborator
                            {
                                Id = collaborator.Id,
                                UserId = collaborator.UserId,
                                Name = collaborator.Name,
                                Email = collaborator.Email,
                                CollectionId = dbCollection.Id
                            }).ToList(),
                        Id = dbCollection.Id,
                        CreateAt = dbCollection.CreateAt,
                        HomeName = dbCollection.Home.Name,
                        City = dbCollection.Room.City,
                        HomeLatitude = dbCollection.Home.Latitude,
                        HomeLongitude = dbCollection.Home.Longitude,
                        RoomId = dbCollection.RoomId,
                        RoomName = dbCollection.RoomId != null ? dbCollection.Room.Name : string.Empty,
                        RoomPartId = dbCollection.RoomPartId,
                        RoomPartName = dbCollection.RoomPartId != null ? dbCollection.RoomPart.Name : string.Empty,
                        Barcode = dbCollection.Barcode,
                        Volume = dbCollection.Volume
                    }).ToList().Distinct();
                foreach (var collection in result)
                {
                    collection.Address = LocationService.getCollectionAddress(collection);
                }
                return result.ToList();
            }
        }

        /*public IEnumerable<Collection> GetCollectionsByLocation(Guid locationId)
        {
            return collectionsRepo.GetBy(x => x.LocationId == locationId).Select(x => new Collection
            {
                Id = x.Id,
                Name = x.Name,
            }).Distinct().ToList();*/

            /*return itemRepository.GetBy(x => x.LocationId == locationId && x.Collection != null).Select(x => new Collection
            {
                Id = x.Collection.Id,
                Name = x.Collection.Name
            }).Distinct().ToList();*/
        /*}*/

        public ICollection<Collection> GetAllCollections()
        {
            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                IEnumerable<Collection> result = collectionsRepo.GetAll().Select(dbCollection => new Collection
                {
                    Items = dbCollection.Items.Select(item => new CollectionItem
                    {
                        Id = item.Id,
                        Name = item.Name,
                        Media = item.Media.Select(media => new MediaService.MediaModel()
                        {
                            Id = media.Id,
                            FilePath = media.FileName,
                            Type = (MediaService.MediaType) media.Type,
                            Duration = Math.Round(media.Duration, 2),
                        }).ToList(),
                        Barcode = item.Barcode,
                        Volume = item.Volume
                    }).ToList(),
                    Name = dbCollection.Name,
                    Notes = dbCollection.Note,
                    Collaborators = dbCollection.Collaborators.Select(collaborator => new UsersService.UserCollaborator
                    {
                        Id = collaborator.Id,
                        UserId = collaborator.UserId,
                        Name = collaborator.Name,
                        Email = collaborator.Email,
                    }).ToList(),
                    Id = dbCollection.Id,
                    CreateAt = dbCollection.CreateAt,
                    City = dbCollection.Room.City,
                    HomeLatitude = dbCollection.Home.Latitude,
                    HomeLongitude = dbCollection.Home.Longitude,
                    RoomId = dbCollection.RoomId,
                    RoomName = dbCollection.RoomId != null ? dbCollection.Room.Name : string.Empty,
                    RoomPartId = dbCollection.RoomPartId,
                    RoomPartName = dbCollection.RoomPartId != null ? dbCollection.RoomPart.Name : string.Empty,
                    Barcode = dbCollection.Barcode,
                    Volume = dbCollection.Volume
                });
                foreach (var collection in result)
                {
                    collection.Address = LocationService.getCollectionAddress(collection);
                }
                return result.ToList();
            }
        }

        public Collection UpdateCollection(string userId, Guid collectionId, string newName, Guid homeId, Guid? roomId, Guid? roomPartId, string note, string barcode, decimal? volume, string role, string storageLocation, string binNumber)
        {
            if (collectionId == Guid.Empty)
                throw new ArgumentException("Collection id can't be empty");
            if (roomPartId == Guid.Empty)
                throw new ArgumentException("Room part id can't be empty");

            var canChangeLocationInExistingCollectionCOND5 = Permissions.UserLevel.CanCreateLocation(role);
            if (!canChangeLocationInExistingCollectionCOND5)
            {
                using (var locationRepo = new BaseRepository<Location>())
                {
                    var userLocationsCount = locationRepo.GetBy(h => h.OwnerId == userId && h.ParentId == null).Count();
                    canChangeLocationInExistingCollectionCOND5 = userLocationsCount > 1;
                }
            }

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var collection = collectionsRepo.GetById(collectionId);
                if (collection == null)
                    throw new Exception("Collection not found");

                string oldName = collection.Name;

                var isShedCollection = IsShedCollection(collection);
                var isCollaborator = collection.UserId != userId;

                if ((collection.HomeId != homeId || collection.RoomId != roomId || collection.RoomPartId != roomPartId)
                    && !Permissions.CollectionLevel.CanChangeLocationInExistingCollection(role, isCollaborator, isShedCollection)
                    && canChangeLocationInExistingCollectionCOND5)
                {
                    throw new Exception("A user doesn't have permission to change Location, Room or Room part.");
                }
                collection.HomeId = homeId;
                collection.RoomId = roomId;
                collection.RoomPartId = roomPartId;
                collection.Note = note;
                                
                if (collection.Name != newName && !Permissions.CollectionLevel.CanEditCollectionName(role, isCollaborator, isShedCollection))
                {
                    throw new Exception("A user doesn't have permission to edit collection name.");
                }
                collection.Name = newName;
                
                if ((collection.Barcode != barcode || collection.Volume != volume) && !Permissions.CollectionLevel.CanEditBarcodeVolumeUnit(role, isCollaborator, isShedCollection))
                {
                    throw new Exception("A user doesn't have permission to edit collection barcode and volume.");
                }
                collection.Barcode = barcode;
                collection.IsLoaded = false;
                collection.Volume = volume;

                if ((collection.StorageLocation != storageLocation || collection.BinNumber != binNumber) && !Permissions.CollectionLevel.CanEditBarcodeVolumeUnit(role, isCollaborator, isShedCollection))
                {
                    throw new Exception("A user doesn't have permission to edit collection storage location and bin number.");
                }
                collection.StorageLocation = storageLocation;
                collection.BinNumber = binNumber;
                
                collectionsRepo.Update(collection);

                if (collection.Collaborators != null && collection.Collaborators.Any())
                {
                    if (!oldName.Equals(newName))
                    {
                        new NotificationsService().NotifyCollectionRenaimed(userId, collection.UserId, collection.Collaborators.ToList(), collectionId, oldName, newName);

                        //var actor = new UsersService().GetUserById(userId);

                        //foreach (var collaborator in collection.Collaborators)
                        //{
                        //    new NotificationsService().AddNotification(collaborator.UserId,
                        //        string.Format("<b>{0}</b> renamed collection <b>{1}</b> to <b>{2}</b>", actor.DisplayName, oldName, newName), collectionId, NotificationsService.ACTION);
                        //}
                    }
                }

                return GetCollection(userId, role, collectionId);
            }
        }

        public ICollection<Collection> Search(string userId, string searchText, string role)
        {
            if (string.IsNullOrEmpty(userId))
                throw new ArgumentException("UserId can't be null or empty");

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var collections = collectionsRepo.GetBy(x => (x.UserId == userId || x.Collaborators.Any(c => c.UserId == userId))
                                && x.Items.Any() 
                                && (x.Name.Contains(searchText)
                                    || x.Collaborators.Any(i => i.UserId != userId 
                                                            && ((i.User != null && (i.User.FirstName.Contains(searchText) || i.User.LastName.Contains(searchText)) || i.User.Email.Contains(searchText))
                                                                || i.Name.Contains(searchText)
                                                                || i.Email.Contains(searchText))
                                                           )
                                    || x.Items.Any(i => i.Name.Contains(searchText))
                                    || x.Items.Any(i => i.Media.Any(m => m.VideoChapters.Any(v => v.Name.Contains(searchText))))
                                    || (x.Home != null && x.Home.Name.Contains(searchText)) 
                                    || (x.Room != null && x.Room.Name.Contains(searchText))
                                    || (x.RoomPart != null && x.RoomPart.Name.Contains(searchText))
                                    || (!string.IsNullOrEmpty(x.Barcode) && x.Barcode.Contains(searchText))
                                    || (!string.IsNullOrEmpty(x.StorageLocation) && x.StorageLocation.Contains(searchText))
                                    || (!string.IsNullOrEmpty(x.BinNumber) && x.BinNumber.Contains(searchText))
                                    || (x.Items.Any(item => item.Barcode.Contains(searchText)))
                                    || (x.Items.Any(item => item.Media.Any(m => m.VideoChapters.Any(v => v.Barcode.Contains(searchText))))))
                                )
                                .ToList();

                var list = new List<Collection>();
                using (var jobCollectionRepo = new BaseRepository<DAL.Models.JobCollection>())
                {
                    foreach (var c in collections)
                    {
                        var jobs = jobCollectionRepo.GetBy(jc => jc.CollectionId == c.Id.ToString(), true).ToList();
                        if (jobs != null && jobs.Any(j => j.Job.Status == (int)JobStatus.InProgress))
                        { continue; }

                        var collection = GetCollection(userId, role, c);
                        if (Permissions.CollectionLevel.CanSeeCollection(role, collection.UserId != userId, collection.IsShedCollection))
                        {
                            list.Add(collection);
                        }
                    }
                }

                return list.OrderByDescending(x => x.CreateAt).ToList();
            }
        }

        public ICollection<Home> GetUserHomesWithItemsCount(string userId, string role)
        {
            if (string.IsNullOrEmpty(userId))
                throw new ArgumentException("UserId can't be null or empty");

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var list = new List<DAL.Models.Collection>();
                var collections = collectionsRepo.GetBy(x => x.UserId == userId || x.Collaborators.Any(c => c.UserId == userId)).ToList();

                foreach (var collection in collections)
                {
                    if (Permissions.CollectionLevel.CanSeeCollection(role, collection.UserId != userId, IsShedCollection(collection)))
                    {
                        list.Add(collection);
                    }
                }

                return list.GroupBy(x => x.Home)
                           .Select(x => new Home
                           {
                               Id = x.Key.Id,
                               Latitude = x.Key.Latitude,
                               Longitude = x.Key.Longitude,
                               Name = x.Key.Name,
                               ItemsCount = x.Sum(s => s.Items.Count)
                                          + x.Sum(s => s.Items.Any(i => i.Media.Any(m => m.Type == (int)MediaService.MediaType.VIDEO && m.VideoChapters.Any()))
                                                     ? s.Items.Sum(i => i.Media.Any(m => m.Type == (int)MediaService.MediaType.VIDEO && m.VideoChapters.Any())
                                                                      ? i.Media.Where(m => m.VideoChapters.Any()).Sum(m => m.VideoChapters.Count) : 0)
                                                       : 0)
                           })
                           .ToList();
            }
        }

        public bool ExistBarcode(string barcode)
        {
            if (string.IsNullOrWhiteSpace(barcode)) return false;

            barcode = barcode.Trim();
            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var collections = collectionsRepo.GetBy(x => x.Barcode == barcode
                                                          || x.Items.Any(i => i.Barcode == barcode
                                                                           || i.Media.Any(m => m.VideoChapters.Any(c => c.Barcode == barcode)))
                                                       ).ToList();

                return collections.Any();
            }
        }

        public void Load(string userId, List<Guid> collectionIds, List<Guid> itemIds)
        {
            using (var context = new DAL.AuthContext())
            {
                using (var transaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        if (itemIds != null && itemIds.Any())
                        {
                            foreach (var itemId in itemIds)
                            {
                                var item = context.Items.FirstOrDefault(x => x.Id == itemId);
                                if (item != null) //throw new Exception($"The item {itemId} no longer exists.");
                                {
                                    item.IsLoaded = true;
                                    context.SaveChanges();
                                }
                            }
                        }

                        if (collectionIds != null && collectionIds.Any())
                        {
                            foreach (var collectionId in collectionIds)
                            {
                                var collection = context.Collections.FirstOrDefault(x => x.Id == collectionId);
                                if (collection != null) //throw new Exception($"The collection {collectionId} no longer exists.");
                                {
                                    collection.IsLoaded = true;
                                    context.SaveChanges();
                                }
                            }
                        }

                        var startedUserJob = context.UserJobs.FirstOrDefault(uj => uj.UserId == userId && uj.Status == (int)JobStatus.InProgress);

                        if (startedUserJob != null)
                        {
                            var currentDateTime = DateTime.Now;
                            foreach (var userJob in startedUserJob.Job.UserJobs)
                            {
                                userJob.DateMovingActualFinish = currentDateTime;
                                context.SaveChanges();
                            }
                        }

                        transaction.Commit();
                    }
                    catch (Exception)
                    {
                        transaction.Rollback();
                    }
                }
            }
        }

        private bool EnsureUserCanAddCollection(string userId, string userRole)
        {
            if (ShedRoleConfig.SHEDUSER_ROLE != userRole)
            {
                return true;
            }

            using (var userJobsRepo = new BaseRepository<DAL.Models.UserJob>())
            {
                var userJobs = userJobsRepo.GetBy(uj => uj.UserId == userId && uj.Status == (int)JobStatus.InProgress).Any();

                if (!userJobs)
                {
                    throw new Exception("You must start a job to create collections.");
                }

                return userJobs;
            }
        }

        private void AttachCollaboratorsToTargetUser(IEnumerable<Guid> collaboratorIds, string targetUserId)
        {
            using (var usersRepository = new UsersRepository())
            {
                foreach (var collaboratorId in collaboratorIds)
                {
                    var userModel = usersRepository.GetById(targetUserId);
                    if (!userModel.CreatedCollaborators.Any(x => x.Id == collaboratorId))
                    {
                        usersRepository.Context.Database.ExecuteSqlCommand(string.Format("insert into CollaboratorsUsers(Id, CreatedBy) values('{0}', '{1}')", collaboratorId, targetUserId));
                    }
                }
            }
        }

        private void AttachCollaboratorToCollection(Guid collaboratorId, Guid collectionId)
        {
            Collaborator collaborator;
            using (var collaboratorRepo = new BaseRepository<Collaborator>())
            {
                collaborator = collaboratorRepo.GetById(collaboratorId);
                if (collaborator == null)
                    throw new Exception("Collaborator not found");
            }

            using (var collectionsRepo = new BaseRepository<DAL.Models.Collection>())
            {
                var collection = collectionsRepo.GetById(collectionId);
                if (collection == null)
                    throw new Exception("Collaborator not found");

                if (!collection.Collaborators.Any(x => x.Id == collaboratorId))
                {
                    collectionsRepo.Context.Database.ExecuteSqlCommand(string.Format("insert into CollectionCollaborators values('{0}', '{1}')", collaboratorId, collectionId));
                }
            }
        }
    }
}