﻿using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.Item.Models
{
    public class CollectionTransferResultModel
    {
        public CollectionTransferResultModel()
        {
            CollectionNames = new List<string>();
        }

        public bool Success { get; set; }
        public string ShedUserName { get; set; }
        public string CollaboratorName { get; set; }
        public string CollaboratorEmail { get; set; }
        public List<string> CollectionNames { get; set; }
    }
}