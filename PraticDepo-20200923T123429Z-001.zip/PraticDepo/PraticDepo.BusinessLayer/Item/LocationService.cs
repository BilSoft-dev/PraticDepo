﻿using PraticDepo.BusinessLayer.Permissions;
using PraticDepo.DAL.Configs;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Repository;
using System;
using System.Collections.Generic;
using System.Device.Location;
using System.Linq;
using System.Text;

namespace PraticDepo.BusinessLayer.Item
{
    public class LocationService : Base.BaseService
    {
        public class UserHome
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public string OwnerId { get; set; }
            public double Latitude { get; set; }
            public double Longitude { get; set; }
            public DateTime CreateAt { get; set; }
            public string City { get; set; }
            public bool IsShedLocation { get; set; }
            public int Permissions { get; set; }

            public List<UserRoom> Rooms { get; set; }
        }

        public class UserRoom
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public DateTime CreateAt { get; set; }

            public List<UserRoomPart> RoomParts { get; set; }
        }

        public class UserRoomPart
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public DateTime CreateAt { get; set; }
        }

        public Guid AddNewHome(GeoCoordinate coords, string name, string userId, string city, string role)
        {
            if (!UserLevel.CanCreateLocation(role))
            {
                throw new Exception("A user doesn't permissions to create a new Location.");
            }

            using (var locationRepo = new BaseRepository<Location>())
            {
                bool isHomeWithSameNameAlreadyExist = locationRepo
                    .GetBy(x => x.ParentId == null && x.OwnerId == userId && x.Name == name)
                    .Any();

                if (isHomeWithSameNameAlreadyExist)
                    throw new Exception("You already has home with same name. Please type another home name.");

                return locationRepo.Add(new Location
                {
                    Id = Guid.NewGuid(),
                    Latitude = coords.Latitude,
                    Longitude = coords.Longitude,
                    Name = name,
                    OwnerId = userId,
                    City = city,
                    CreateAt = DateTime.Now
                });
            }
        }

        public Guid AddRoom(Guid homeId, string name, string userId, string role)
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                var isRoomAlreadyExistAtHome = locationRepo
                    .GetBy(x => x.ParentId == homeId && x.Name == name)
                    .Any();

                if (isRoomAlreadyExistAtHome)
                    throw new Exception("Room with same name already exist at this home. Please type another name");

                var home = locationRepo.GetById(homeId);
                if (home == null)
                {
                    throw new Exception("Home not found");
                }

                var isCollaborator = home.OwnerId == userId ? false : IsLocationCollaborator(userId, home);

                if (!LocationLevel.CanAddRoomsRoomparts(role, home.OwnerId == userId, false, IsShedLocation(homeId)))
                {
                    throw new Exception("A user doesn't have permission to add a Room.");
                }

                return locationRepo.Add(new Location
                {
                    CreateAt = DateTime.Now,
                    Id = Guid.NewGuid(),
                    ParentId = homeId,
                    Name = name,
                    OwnerId = home.OwnerId
                });
            }
        }

        public Guid AddRoomPart(Guid roomId, string name, string userId, string role)
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                var isRoomPartAlreadyExistAtRoom = locationRepo
                    .GetBy(x => x.ParentId == roomId && x.Name == name)
                    .Any();

                if (isRoomPartAlreadyExistAtRoom)
                    throw new Exception("Room part with same name already exist at this room. Please type another name");

                var ownerId = string.Empty;
                var room = locationRepo.GetById(roomId);
                if (room != null && room.Parent != null)
                    ownerId = room.Parent.OwnerId;

                var isCollaborator = ownerId == userId ? false : IsLocationCollaborator(userId, room);

                if (!LocationLevel.CanAddRoomsRoomparts(role, ownerId == userId, false, IsShedLocation(room.ParentId.Value)))
                {
                    throw new Exception("A user doesn't have permission to add a Room.");
                }

                return locationRepo.Add(new Location
                {
                    CreateAt = DateTime.Now,
                    Id = Guid.NewGuid(),
                    Name = name,
                    ParentId = roomId,
                    OwnerId = ownerId
                });
            }
        }

        public List<UserHome> GetHomes(string userId, string role)
        {
            return FilterLocations(userId, role, GetLocations());
        }

        public List<UserRoom> GetRooms(Guid parentId, string userId, string role)
        {
            var rooms = new List<UserRoom>();
            using (var locationRepo = new BaseRepository<Location>())
            {
                var dbRooms = locationRepo.GetBy(r => r.ParentId == parentId).ToList();
                foreach (var dbRoom in dbRooms)
                {
                    var isLocationOwner = GetRootOwnerId(dbRoom) == userId;
                    var isCollaborator = isLocationOwner ? false : IsLocationCollaborator(userId, dbRoom);

                    if (LocationLevel.CanChooseRoomsRoompartsForCollection(role, isLocationOwner, isCollaborator, IsShedLocation(GetRootId(dbRoom))))
                    {
                        rooms.Add(new UserRoom
                        {
                            Id = dbRoom.Id,
                            CreateAt = dbRoom.CreateAt,
                            Name = dbRoom.Name
                        });
                    }
                }

                return rooms;
            }
        }
        
        public ICollection<UserHome> GetUserHomes(string userId, string role)
        {
            var homes = FilterLocations(userId, role, GetLocations(), true);

            using (var locationRepo = new BaseRepository<Location>())
            {
                foreach (var home in homes)
                {
                    var rooms = new List<UserRoom>();
                    var dbRooms = locationRepo.GetBy(r => r.ParentId == home.Id).ToList();
                    foreach (var dbRoom in dbRooms)
                    {
                        var isOwner = home.OwnerId == userId;
                        var isCollaborator = isOwner ? false : IsLocationCollaborator(userId, dbRoom);

                        if (LocationLevel.CanSeeRoomsRoomPartsOnSettings(role, isOwner, isCollaborator, home.IsShedLocation))
                        {
                            var roomParts = new List<UserRoomPart>();
                            var dbRoomParts = locationRepo.GetBy(rp => rp.ParentId == dbRoom.Id).ToList();
                            foreach (var dbRoomPart in dbRoomParts)
                            {
                                isCollaborator = isOwner ? false : IsLocationCollaborator(userId, dbRoomPart);
                                if (LocationLevel.CanSeeRoomsRoomPartsOnSettings(role, isOwner, isCollaborator, home.IsShedLocation))
                                {
                                    roomParts.Add(new UserRoomPart
                                    {
                                        CreateAt = dbRoomPart.CreateAt,
                                        Id = dbRoomPart.Id,
                                        Name = dbRoomPart.Name
                                    });
                                }
                            }

                            rooms.Add(new UserRoom
                            {
                                CreateAt = dbRoom.CreateAt,
                                Id = dbRoom.Id,
                                Name = dbRoom.Name,
                                RoomParts = roomParts
                            });
                        }
                    }

                    home.Rooms = rooms;
                }
            }

            return homes;
        }

        private List<UserHome> FilterLocations(string userId, string role, List<UserHome> homes, bool filterByCollaborator = false)
        {
            var result = new List<UserHome>();
            foreach (var home in homes)
            {
                var isCollaborator = filterByCollaborator ? IsLocationCollaborator(userId, role, home) : false;
                home.Permissions = LocationLevel.GetLocationLevelMask(role, home.OwnerId == userId, isCollaborator, home.IsShedLocation);

                if (filterByCollaborator)
                {
                    if (LocationLevel.CanSeeLocationOnSettings(home.Permissions)) result.Add(home);
                }
                else
                {
                    if (LocationLevel.CanChooseForCollection(home.Permissions)) result.Add(home);
                }
            }

            return result;
        }

        #region IsLocationCollaborator functionality

        private bool IsLocationCollaborator(string userId, string role, UserHome home)
        {
            if (home.OwnerId == userId) return false;
            if (home.IsShedLocation && ShedRoleConfig.SHEDUSER_ROLE == role) return false;

            using (var collectionsRepo = new BaseRepository<Collection>())
            {
                return collectionsRepo.GetBy(x => x.HomeId == home.Id && x.Collaborators.Any(c => c.UserId == userId)).Any();
            }
        }

        private bool IsLocationCollaborator(string userId, Location location)
        {
            using (var collectionsRepo = new BaseRepository<Collection>())
            {
                switch (location.Type)
                {
                    case Location.LocationType.HOME: return collectionsRepo.GetBy(x => x.HomeId == location.Id && x.Collaborators.Any(c => c.UserId == userId)).Any();
                    case Location.LocationType.ROOM: return collectionsRepo.GetBy(x => x.RoomId == location.Id && x.Collaborators.Any(c => c.UserId == userId)).Any();
                    case Location.LocationType.ROOMPART: return collectionsRepo.GetBy(x => x.RoomPartId == location.Id && x.Collaborators.Any(c => c.UserId == userId)).Any();
                    default: return false;
                }
            }
        }

        #endregion

        public int GetLocationPermissionsMaskForHome(string userId, string role, Location location)
        {
            return LocationLevel.GetLocationLevelMask(role, location.OwnerId == userId, IsLocationCollaborator(userId, location), location.OwnerId == AdminConfig.Id);
        }

        public List<UserHome> GetLocationsByUserId(string userId)
        {
            using (var collectionRepo = new BaseRepository<Collection>())
            {
                return collectionRepo.GetBy(x => x.UserId == userId)
                                     .GroupBy(x => x.HomeId)
                                     .ToList()
                                     .Select(x => new UserHome
                                     {
                                         Id = x.Key,
                                         CreateAt = x.First().Home.CreateAt,
                                         Name = x.First().Home.Name,
                                         OwnerId = x.First().Home.OwnerId,
                                         Latitude = x.First().Home.Latitude,
                                         Longitude = x.First().Home.Longitude,
                                         City = x.First().Home.City,
                                         IsShedLocation = x.First().Home.OwnerId == AdminConfig.Id
                                     })
                                     .ToList();
            }
        }

        private Location GetLocation(Guid homeId)
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                return locationRepo.GetById(homeId);
            }
        }

        private List<UserHome> GetLocations()
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                return locationRepo.GetBy(h => h.ParentId == null)
                                   .OrderByDescending(x => x.CreateAt)
                                   .Select(h => new UserHome
                                   {
                                       Id = h.Id,
                                       CreateAt = h.CreateAt,
                                       Name = h.Name,
                                       OwnerId = h.OwnerId,
                                       Latitude = h.Latitude,
                                       Longitude = h.Longitude,
                                       City = h.City,
                                       IsShedLocation = h.OwnerId == AdminConfig.Id
                                   })
                                   .ToList();
            }
        }

        public void DeleteRoomPart(Guid roomPartId, string userId, string role)
        {
            using (IBaseRepository<Collection> collectionsRepo = new BaseRepository<Collection>())
            {
                if (collectionsRepo.GetBy(x => x.RoomPartId != null && x.RoomPartId == roomPartId).Any())
                {
                    throw new Exception("You can't delete a room part with collections in it. Please delete collection(s) in this room part first.");
                }
            }
            using (var locationRepo = new BaseRepository<Location>())
            {
                var location = locationRepo.GetById(roomPartId);
                var rootOwnerId = GetRootOwnerId(location);
                var isCollaborator = rootOwnerId == userId ? false : IsLocationCollaborator(userId, location);

                if (!LocationLevel.CanRemoveRoomsRoomparts(role, rootOwnerId == userId, isCollaborator, IsShedLocation(GetRootId(location))))
                {
                    throw new Exception("You can't delete a room part where you are a collaborator.");
                }

                locationRepo.Delete(roomPartId);
            }

            //var itemsRepo = new BaseRepository<DAL.Models.Item>();
            //var notesRepo = new BaseRepository<DAL.Models.Note>();
            //var collaboratorsRepo = new BaseRepository<DAL.Models.Collaborator>();

            //var roomPart = roomPartRepo.GetById(roomPartId);

            // delete all related items
            /*foreach (var item in roomPart.Items)
                itemsRepo.Delete(item);*/
            //delete all related notes
            //foreach (var note in roomPart.Notes)
            //    notesRepo.Delete(note);

            //roomPartRepo.Delete(roomPart);
        }

        public void DeleteRoom(Guid roomId, string userId, string role)
        {
            using (IBaseRepository<Collection> collectionsRepo = new BaseRepository<Collection>())
            {
                if (collectionsRepo.GetBy(x => x.RoomId != null && x.RoomId == roomId).Any())
                {
                    throw new Exception("You can't delete a room with collections in it. Please delete the collection(s) in this room first.");
                }
            }
            using (var repo = new BaseRepository<Location>())
            {
                var location = repo.GetById(roomId);
                var rootOwnerId = GetRootOwnerId(location);
                var isCollaborator = rootOwnerId == userId ? false : IsLocationCollaborator(userId, location);

                if (!LocationLevel.CanRemoveRoomsRoomparts(role, rootOwnerId == userId, isCollaborator, IsShedLocation(GetRootId(location))))
                {
                    throw new Exception("You can't delete a room where you are a collaborator.");
                }

                var roomParts = repo.GetBy(r => r.ParentId == roomId).ToList();
                foreach (var part in roomParts)
                    repo.Delete(part.Id);
            }

            using (var repo = new BaseRepository<Location>())
            {
                repo.Delete(roomId);
            }

            //var room = roomRepo.GetById(roomId);
            /*foreach (var roomPart in room.RoomParts)
                DeleteRoomPart(roomPart.Id);*/

            //roomRepo.Delete(room);
        }

        public void DeleteHome(Guid homeId, string userId, string role)
        {
            using (IBaseRepository<Collection> collectionsRepo = new BaseRepository<Collection>())
            {
                if (collectionsRepo.GetBy(x => x.HomeId != null && x.HomeId == homeId).Any())
                {
                    throw new Exception("Cannot delete due to this home has assigned collection");
                }
            }
            using (var repo = new BaseRepository<Location>())
            {
                var location = repo.GetById(homeId);
                var isCollaborator = location.OwnerId == userId ? false : IsLocationCollaborator(userId, location);
                if (!LocationLevel.CanRemove(role, location.OwnerId == userId, isCollaborator, IsShedLocation(homeId)))
                {
                    throw new Exception("A user doesn't have permission to remove a home.");
                }

                var rooms = repo.GetBy(r => r.ParentId == homeId).ToList();
                var roomParts = new List<Location>();
                foreach (var room in rooms)
                    roomParts.AddRange(repo.GetBy(rp => rp.ParentId == room.Id).ToList());

                foreach (var roomPart in roomParts)
                    repo.Delete(roomPart);
                foreach (var room in rooms)
                    DeleteRoom(room.Id, userId, role);
            }
            using (var repo = new BaseRepository<Location>())
            {
                try
                {
                    repo.Delete(homeId);
                }
                catch (ArgumentNullException ex)
                {

                }
            }

            //var home = homeRepo.GetById(homeId);
            /*foreach (var room in home.Rooms)
                DeleteRoom(room.Id);*/

            //homeRepo.Delete(home);
        }
        
        public void RenameHome(Guid homeId, string newName, string userId, string role)
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                var home = locationRepo.GetById(homeId);
                if (home != null)
                {
                    var isCollaborator = home.OwnerId == userId ? false : IsLocationCollaborator(userId, home);

                    if (!LocationLevel.CanChangeNameAddressCoordinates(role, home.OwnerId == userId, false, IsShedLocation(homeId)))
                    {
                        throw new Exception("A user doesn't have permission to rename home.");
                    }

                    home.Name = newName;
                    locationRepo.Update(home);
                }
            }
        }

        public void ChangeHomeLocation(Guid homeId, double latitude, double longitude, string city)
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                var home = locationRepo.GetById(homeId);
                if (home != null)
                {
                    home.Latitude = latitude;
                    home.Longitude = longitude;
                    if (!string.IsNullOrEmpty(city) && city != home.City)
                        home.City = city;

                    locationRepo.Update(home);
                }
            }
        }

        public void RenameRoom(Guid roomId, string newName, string userId, string role)
        {
            using (var locationRepo = new BaseRepository<Location>())
            {
                var room = locationRepo.GetById(roomId);
                if (room != null)
                {
                    var rootOwnerId = GetRootOwnerId(room);
                    var isCollaborator = rootOwnerId == userId ? false : IsLocationCollaborator(userId, room);

                    if (!LocationLevel.CanChangeNamesOfRooms(role, rootOwnerId == userId, false, IsShedLocation(GetRootId(room))))
                    {
                        throw new Exception("A user doesn't have permission to rename room / roompart.");
                    }

                    room.Name = newName;
                    locationRepo.Update(room);
                }
            }
        }

        private Guid GetRootId(Location location)
        {
            if (location.Type == Location.LocationType.ROOMPART && location.Parent != null && location.Parent.ParentId.HasValue) return location.Parent.ParentId.Value;
            if (location.Type == Location.LocationType.ROOM && location.ParentId.HasValue) return location.ParentId.Value;

            return location.Id;
        }

        private string GetRootOwnerId(Location location)
        {
            if (location.Type == Location.LocationType.ROOMPART && location.Parent != null && location.Parent.Parent != null) return location.Parent.Parent.OwnerId;
            if (location.Type == Location.LocationType.ROOM && location.Parent != null) return location.Parent.OwnerId;

            return location.OwnerId;
        }

        /* public string GetAddress(Guid roomPartId)
         {
             var roomPart = locationRepo.GetById(roomPartId);
             if (roomPart == null)
                 throw new Exception("Room part not found");

             return roomPart.Address;*/

        /*var roomPartName = roomPart.Name;
        var roomName = roomPart.Room != null ? roomPart.Room.Name : string.Empty;
        string homeName = string.Empty;
        string cityName = string.Empty;
        if (roomPart.Room != null && roomPart.Room.Home != null)
        {
            homeName = roomPart.Room.Home.Name;
            cityName = roomPart.Room.Home.City;
        }

        return string.Format("{0} > {1} > {2} > {3}", cityName, homeName, roomName, roomPartName);*/
        /*}*/

        /*public string GetAddress(CollectionItem item)
        {
            if (item.RoomPartId.HasValue)
                return GetAddress(item.RoomPartId.Value);
            if(item.RoomId.HasValue)
                return GetAddress(item.RoomId.Value);

            return GetAddress(item.LocationId.Value);
        }*/

        public static string getCollectionAddress(ItemsService.Collection collection)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(collection.City);
            builder.Append(" > ");
            builder.Append(collection.HomeName);
            if (collection.RoomId != null)
            {
                builder.Append(" > ");
                builder.Append(collection.RoomName);
            }
            if (collection.RoomPartId != null)
            {
                builder.Append(" > ");
                builder.Append(collection.RoomPartName);
            }
            return builder.ToString();
        }

        public static string getCollectionAddress(Collection collection)
        {
            StringBuilder builder = new StringBuilder();

            if (collection.Home != null)
            {
                builder.Append(collection.Home.City);
                builder.Append(" > ");
                builder.Append(collection.Home.Name);
            }

            if (collection.RoomId.HasValue && collection.Room != null)
            {
                builder.Append(" > ");
                builder.Append(collection.Room.Name);
            }

            if (collection.RoomPartId.HasValue && collection.RoomPart != null)
            {
                builder.Append(" > ");
                builder.Append(collection.RoomPart.Name);
            }

            return builder.ToString();
        }
    }
}