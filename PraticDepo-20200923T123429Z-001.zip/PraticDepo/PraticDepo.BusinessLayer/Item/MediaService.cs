﻿using System;
using System.Collections.Generic;
using System.Linq;
using PraticDepo.DAL.Repository;
using PraticDepo.DAL.Models;
using System.IO;
using ImageProcessor;
using System.Drawing;

namespace PraticDepo.BusinessLayer.Item
{
    public class MediaService : Base.BaseService
    {
        public class MediaModel
        {
            public Guid Id { get; set; }
            public string FilePath {get;set;}
            public MediaType Type {get;set;}
            public double Duration { get; set; }
            public List<Chapter> Chapters { get; set; }

            public string PreviewFilePath
            {
                get; set;
                //{
                //    int dotIndex = FilePath.LastIndexOf('.');
                //    string extension;
                //    string path;
                //    if(dotIndex > 0)
                //    {
                //        extension = FilePath.Substring(dotIndex);
                //        path = FilePath.Substring(0, dotIndex);
                //    } else
                //    {
                //        extension = "";
                //        path = FilePath;
                //    }
                //    var previewFilePath = string.Format("{0}_preview{1}", path, extension);
                //    return previewFilePath;
                //}
            }
        }

        public class Chapter
        {
            public Guid Id { get; set; }
            public string Name { get; set; }
            public double Time { get; set; }
            public string Cover { get; set; }
            public string CoverPreview { get; set; }
            public string Barcode { get; set; }
            public decimal? Volume { get; set; }
            public int Status { get; set; }
        }

        public enum MediaType
        {
            PHOTO = 0,
            VIDEO
        }

        private ItemsService.Collection GetCollection(string userId, string role, Guid itemId)
        {
            var itemsService = new ItemsService();
            var item = itemsService.GetItem(itemId);

            if (item != null && item.CollectionId.HasValue)
            {
                return itemsService.GetCollection(userId, role, item.CollectionId.Value);
            }

            return null;
        }

        public Chapter GetChapter(Guid chapterId)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                var chapterEntity = chaptersRepo.GetById(chapterId);

                if (chapterEntity == null)
                    throw new Exception("The chapter no longer exists");

                return new Chapter() {
                    Cover = chapterEntity.Cover.FileName,
                    Id = chapterId,
                    Time = chapterEntity.Time,
                    Name = chapterEntity.Name,
                    Barcode = chapterEntity.Barcode,
                    Volume = chapterEntity.Volume,
                    Status = new ItemsService().GetDeliveryStatus(chapterEntity.Status)
                };
            }
        }

        public Guid AddVideo(string filePath, double duration)
        {
            using (var mediaRepo = new BaseRepository<Media>())
            {
                return mediaRepo.Add(new Media
                {
                    Type = (int)MediaType.VIDEO,
                    Id = Guid.NewGuid(),
                    FileName = filePath,
                    Duration = Math.Abs(duration),
                    CreateDate = DateTime.Now
                });
            }
        }
        
        public Guid AddPhoto(string filePath)
        {
            using (var mediaRepo = new BaseRepository<Media>())
            {
                return mediaRepo.Add(new Media
                {
                    Type = (int)MediaType.PHOTO,
                    Id = Guid.NewGuid(),
                    FileName = filePath,
                    CreateDate = DateTime.Now
                });
            }
        }
        
        public ICollection<MediaModel> GetItemMedia(Guid itemId)
        {
            using (var mediaRepo = new BaseRepository<Media>())
            {
                return mediaRepo.GetBy(m => m.ItemId == itemId).OrderBy(x => x.CreateDate).Select(media => new MediaModel
                {
                    Id = media.Id,
                    FilePath = media.FileName,
                    Type = (MediaType)media.Type,
                    Duration = Math.Round(media.Duration, 2),
                }).ToList();
            }
        }

        public MediaModel GetMedia(Guid mediaId)
        {
            using (var mediaRepo = new BaseRepository<Media>())
            {
                var media = mediaRepo.GetById(mediaId, true);
                return new MediaModel
                {
                    Id = media.Id,
                    FilePath = media.FileName,
                    Type = (MediaType)media.Type,
                    Duration = Math.Round(media.Duration, 2)
                };
            }
        }

        public Guid AddChapter(Guid videoId, Guid coverId, string name, double time, string barcode, decimal? volume)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                return chaptersRepo.Add(new VideoChapter
                {
                    CoverId = coverId,
                    Id = Guid.NewGuid(),
                    Name = name,
                    Time = Math.Abs(time),
                    VideoId = videoId,
                    Barcode = barcode,
                    Volume = volume
                });
            }
        }

        public ICollection<Chapter> GetVideoChapters(Guid videoId)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                return chaptersRepo.GetBy(x => x.VideoId == videoId).Select(c => new Chapter
                {
                    Cover = c.Cover.FileName,
                    Id = c.Id,
                    Name = c.Name,
                    Time = c.Time,
                    Barcode = c.Barcode,
                    Volume = c.Volume
                }).ToList();
            }
        }

        public bool IsMediaItemExsist(Guid id)
        {
            using (var mediaRepo = new BaseRepository<Media>())
            {
                return mediaRepo.GetById(id) != null;
            }
        }

        public void DeleteItem(Guid mediaId)
        {
            using (var mediaRepo = new BaseRepository<Media>())
            {
                var media = mediaRepo.GetById(mediaId);
                if (media != null)
                {
                    if (media.Type == (int)MediaType.VIDEO)
                    {
                        using (var chaptersRepo = new BaseRepository<VideoChapter>())
                        {
                            var chapters = chaptersRepo.GetBy(ch => ch.VideoId == mediaId).ToList();
                            if (chapters != null && chapters.Any())
                            {
                                foreach (var chaprer in chapters)
                                {
                                    chaptersRepo.Delete(chaprer);
                                    mediaRepo.Delete(chaprer.CoverId);
                                }
                            }
                        }
                    }
                    mediaRepo.Delete(mediaId);
                }
            }
        }

        public void ChangeChapterTime(Guid id, double time)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                var chapter = chaptersRepo.GetById(id);
                if (chapter == null)
                    throw new Exception("The chapter no longer exists");

                chapter.Time = Math.Abs(time);
                chaptersRepo.Update(chapter);
            }
        }

        public void RenameChapter(Guid id, string newName, string userId, string role, ItemsService.Collection collection = null)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                var chapter = chaptersRepo.GetById(id);
                if (chapter == null)
                    throw new Exception("The chapter no longer exists");

                if (collection == null)
                {
                    collection = GetCollection(userId, role, chapter.Video.ItemId.HasValue ? chapter.Video.ItemId.Value : (chapter.Cover.ItemId.HasValue ? chapter.Cover.ItemId.Value : new Guid()));
                }

                if (collection != null && !Permissions.CollectionLevel.CanEditItemNames(role, collection.UserId != userId, collection.IsShedCollection))
                {
                    throw new Exception("A user doesn't have permission to rename chapter.");
                }
                
                chapter.Name = newName;
                chaptersRepo.Update(chapter);
            }
        }

        public void ChangeChapterBarcode(Guid id, string barcode)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                var chapter = chaptersRepo.GetById(id);
                if (chapter == null)
                    throw new Exception("The chapter no longer exists");

                chapter.Barcode = barcode;
                chaptersRepo.Update(chapter);
            }
        }

        public void ChangeChapterVolume(Guid id, decimal? volume)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                var chapter = chaptersRepo.GetById(id);
                if (chapter == null)
                    throw new Exception("The chapter no longer exists");

                chapter.Volume = volume;
                chaptersRepo.Update(chapter);
            }
        }

        public void EditChapter(Guid id, string name, double time, string barcode, decimal? volume, string userId, string role)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                var chapter = chaptersRepo.GetById(id);
                if (chapter == null)
                    throw new Exception("The chapter no longer exists");

                var collection = GetCollection(userId, role, chapter.Video.ItemId.HasValue ? chapter.Video.ItemId.Value : (chapter.Cover.ItemId.HasValue ? chapter.Cover.ItemId.Value : new Guid()));

                if (!string.IsNullOrEmpty(name) && name != chapter.Name)
                {
                    RenameChapter(id, name, userId, role, collection);
                }
                if (Math.Abs(time) != Math.Abs(chapter.Time)) ChangeChapterTime(id, time);

                if (barcode != chapter.Barcode)
                {
                    if (collection != null && !Permissions.CollectionLevel.CanEditBarcodeVolumeUnit(role, collection.UserId != userId, collection.IsShedCollection))
                    {
                        throw new Exception("A user doesn't have permission to edit chapter barcode.");
                    }

                    ChangeChapterBarcode(id, barcode);
                }

                if (volume != chapter.Volume)
                {
                    if (collection != null && !Permissions.CollectionLevel.CanEditBarcodeVolumeUnit(role, collection.UserId != userId, collection.IsShedCollection))
                    {
                        throw new Exception("A user doesn't have permission to edit chapter volume.");
                    }

                    ChangeChapterVolume(id, volume);
                }
            }
        }

        public void RemoveChapter(Guid id, string userId, string role)
        {
            using (var chaptersRepo = new BaseRepository<VideoChapter>())
            {
                var chapter = chaptersRepo.GetById(id);

                if (chapter == null)
                    throw new Exception("The chapter no longer exists");

                var collection = GetCollection(userId, role, chapter.Video.ItemId.HasValue ? chapter.Video.ItemId.Value : (chapter.Cover.ItemId.HasValue ? chapter.Cover.ItemId.Value : new Guid()));
                if (collection != null && !Permissions.CollectionLevel.CanDeleteItem(role, collection.UserId != userId, collection.IsShedCollection))
                {
                    throw new Exception("A user doesn't have permission to remove chapter.");
                }

                chaptersRepo.Delete(chapter);
                using (var mediaRepo = new BaseRepository<Media>())
                {
                    mediaRepo.Delete(chapter.CoverId);
                }
            }
        }
        
        public static void CreatePhotoPreview(Stream originalPhoto, Stream result)
        {
            // resize and save image
            Size size = new Size(768, 340);

            using (ImageFactory imageFactory = new ImageFactory())
            {
                imageFactory.Load(originalPhoto)
                    .AutoRotate()
                    .Resize(new ImageProcessor.Imaging.ResizeLayer(size, ImageProcessor.Imaging.ResizeMode.Max))
                    .Save(result);
            }
        }
    }
}
