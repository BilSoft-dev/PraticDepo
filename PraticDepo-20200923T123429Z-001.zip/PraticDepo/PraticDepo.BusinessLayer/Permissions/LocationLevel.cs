﻿using System;
using PraticDepo.DAL.Configs;

namespace PraticDepo.BusinessLayer.Permissions
{
    public static class LocationLevel
    {
        #region Permissions

        private const int CAN_SEE_LOCATION_ON_SETTINGS = 1;
        private const int CAN_SEE_ROOMS_ROOMPARTS_ON_SETTINGS = 1 << 1;
        private const int CAN_CHOOSE_FOR_COLLECTION = 1 << 2;
        private const int CAN_REMOVE = 1 << 3;
        private const int CAN_CHANGE_NAME_ADDRESS_COORDINATES = 1 << 4;
        private const int CAN_ADD_ROOMS_ROOMPARTS = 1 << 5;
        private const int CAN_REMOVE_ROOMS_ROOMPARTS = 1 << 6;
        private const int CAN_CHANGE_NAMES_OF_ROOMS = 1 << 7;
        private const int CAN_CHOOSE_ROOMS_ROOMPARTS_FOR_COLLECTION = 1 << 8;

        #endregion

        #region Masks

        private const int SHED_USER_IN_SHED_LOCATION_MASK = CAN_SEE_LOCATION_ON_SETTINGS | CAN_SEE_ROOMS_ROOMPARTS_ON_SETTINGS | CAN_CHOOSE_FOR_COLLECTION
                                                          | CAN_ADD_ROOMS_ROOMPARTS | CAN_REMOVE_ROOMS_ROOMPARTS | CAN_CHANGE_NAMES_OF_ROOMS | CAN_CHOOSE_ROOMS_ROOMPARTS_FOR_COLLECTION;

        private const int REGULAR_USER_IN_REGULAR_LOCATION__MASK = CAN_SEE_LOCATION_ON_SETTINGS | CAN_SEE_ROOMS_ROOMPARTS_ON_SETTINGS | CAN_CHOOSE_FOR_COLLECTION
                                                                | CAN_REMOVE | CAN_CHANGE_NAME_ADDRESS_COORDINATES | CAN_ADD_ROOMS_ROOMPARTS | CAN_REMOVE_ROOMS_ROOMPARTS
                                                                | CAN_CHANGE_NAMES_OF_ROOMS | CAN_CHOOSE_ROOMS_ROOMPARTS_FOR_COLLECTION;

        private const int REGULAR_COLLABORATOR_IN_SHED_LOCATION_MASK = CAN_SEE_LOCATION_ON_SETTINGS;

        private const int REGULAR_COLLABORATOR_IN_REGULAR_LOCATION_MASK = CAN_SEE_LOCATION_ON_SETTINGS | CAN_SEE_ROOMS_ROOMPARTS_ON_SETTINGS;

        #endregion

        public static int GetLocationLevelMask(string role, bool isOwner, bool isCollaborator, bool isShedLocation)
        {
            if (isShedLocation)
            {
                switch (role)
                {
                    case ShedRoleConfig.SHEDUSER_ROLE: return SHED_USER_IN_SHED_LOCATION_MASK;
                    case ShedRoleConfig.REGULARUSER_ROLE:
                        {
                            if (isCollaborator) return REGULAR_COLLABORATOR_IN_SHED_LOCATION_MASK;
                            return 0;
                        }
                    default: return 0;
                }
            }
            else
            {
                switch (role)
                {
                    case ShedRoleConfig.REGULARUSER_ROLE:
                        {
                            if (isOwner) return REGULAR_USER_IN_REGULAR_LOCATION__MASK;
                            if (isCollaborator) return REGULAR_COLLABORATOR_IN_REGULAR_LOCATION_MASK;

                            return 0;
                        }
                    default: return 0;
                }
            }
        }

        public static bool CanSeeLocationOnSettings(int mask)
        {
            return (mask & CAN_SEE_LOCATION_ON_SETTINGS) > 0;
        }

        public static bool CanSeeRoomsRoomPartsOnSettings(string role, bool isOwner, bool isCollaborator, bool isShedLocation)
        {
            return (GetLocationLevelMask(role, isOwner, isCollaborator, isShedLocation) & CAN_SEE_ROOMS_ROOMPARTS_ON_SETTINGS) > 0;
        }

        public static bool CanChooseForCollection(int mask)
        {
            return (mask & CAN_CHOOSE_FOR_COLLECTION) > 0;
        }

        public static bool CanRemove(string role, bool isOwner, bool isCollaborator, bool isShedLocation)
        {
            return (GetLocationLevelMask(role, isOwner, isCollaborator, isShedLocation) & CAN_REMOVE) > 0;
        }

        public static bool CanChangeNameAddressCoordinates(string role, bool isOwner, bool isCollaborator, bool isShedLocation)
        {
            return (GetLocationLevelMask(role, isOwner, isCollaborator, isShedLocation) & CAN_CHANGE_NAME_ADDRESS_COORDINATES) > 0;
        }

        public static bool CanAddRoomsRoomparts(string role, bool isOwner, bool isCollaborator, bool isShedLocation)
        {
            return (GetLocationLevelMask(role, isOwner, isCollaborator, isShedLocation) & CAN_ADD_ROOMS_ROOMPARTS) > 0;
        }

        public static bool CanRemoveRoomsRoomparts(string role, bool isOwner, bool isCollaborator, bool isShedLocation)
        {
            return (GetLocationLevelMask(role, isOwner, isCollaborator, isShedLocation) & CAN_REMOVE_ROOMS_ROOMPARTS) > 0;
        }
        
        public static bool CanChangeNamesOfRooms(string role, bool isOwner, bool isCollaborator, bool isShedLocation)
        {
            return (GetLocationLevelMask(role, isOwner, isCollaborator, isShedLocation) & CAN_CHANGE_NAMES_OF_ROOMS) > 0;
        }

        public static bool CanChooseRoomsRoompartsForCollection(string role, bool isOwner, bool isCollaborator, bool isShedLocation)
        {
            return (GetLocationLevelMask(role, isOwner, isCollaborator, isShedLocation) & CAN_CHOOSE_ROOMS_ROOMPARTS_FOR_COLLECTION) > 0;
        }
    }
}