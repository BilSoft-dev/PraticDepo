﻿using System;
using PraticDepo.DAL.Configs;

namespace PraticDepo.BusinessLayer.Permissions
{
    public static class UserLevel
    {
        #region Permissions

        private const int CAN_CREATE_LOCATION = 1;
        private const int CAN_CREATE_WITH_BARCODE_VOLUME = 1 << 3;
        private const int CAN_REQUEST_DELIVERY = 1 << 5;
        private const int CAN_EDIT_EMAIL = 1 << 6;
        private const int CAN_CHANGE_PASSWORD = 1 << 7;
        private const int CAN_HAVE_FIRST_LOCATION_ON_COLLECTION_CREATIONEDIT_PREFILLED = 1 << 8;

        #endregion

        private const int SHED_USER_MASK = CAN_CREATE_WITH_BARCODE_VOLUME | CAN_CHANGE_PASSWORD | CAN_HAVE_FIRST_LOCATION_ON_COLLECTION_CREATIONEDIT_PREFILLED;
        private const int REGULAR_USER_MASK = CAN_CREATE_LOCATION | CAN_REQUEST_DELIVERY | CAN_EDIT_EMAIL | CAN_CHANGE_PASSWORD;

        public static int GetUserLevelMask(string role)
        {
            switch (role)
            {
                case ShedRoleConfig.SHEDUSER_ROLE: return SHED_USER_MASK;
                case ShedRoleConfig.REGULARUSER_ROLE: return REGULAR_USER_MASK;
                default: return 0;
            }
        }

        public static bool CanCreateLocation(string role)
        {
            return (GetUserLevelMask(role) & CAN_CREATE_LOCATION) > 0;
        }
                
        public static bool CanCreateWithBarcodeVolume(string role)
        {
            return (GetUserLevelMask(role) & CAN_CREATE_WITH_BARCODE_VOLUME) > 0;
        }
        
        public static bool CanEditEmail(string role)
        {
            return (GetUserLevelMask(role) & CAN_EDIT_EMAIL) > 0;
        }

        public static bool CanChangePassword(string role)
        {
            return (GetUserLevelMask(role) & CAN_CHANGE_PASSWORD) > 0;
        }
    }
}