﻿using System;
using System.Collections.Generic;

namespace PraticDepo.BusinessLayer.Users.Models
{
    public class UsersList
    {
        public List<UsersService.User> Users { get; set; }
        public int TotalCount { get; set; }
    }
}