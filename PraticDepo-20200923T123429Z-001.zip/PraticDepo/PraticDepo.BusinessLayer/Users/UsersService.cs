﻿using PraticDepo.BusinessLayer.Item;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Repository;
using PraticDepo.DAL.Configs;
using System;
using System.Collections.Generic;
using System.Linq;
using PraticDepo.BusinessLayer.Notifications;

namespace PraticDepo.BusinessLayer.Users
{
    public class UsersService : Base.BaseService
    {
        public class UserCollaborator
        {
            public Guid Id { get; set; }
            public string UserId { get; set; }
            public string Name { get; set; }
            public string Email { get; set; }
            public bool IsRegistered => !string.IsNullOrEmpty(UserId);
            public Guid CollectionId { get; set; }
        }

        public class User
        {
            public string Id { get; set; }
            public string Name
            {
                get
                {
                    return string.Format("{0} {1}", FirstName, LastName).Trim();
                }
            }
            public string Email { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public string PhoneNumber { get; set; }
            public bool IsLocked { get; set; }
            public DateTime CreatedAtUtc { get; set; }
            public string Role { get; set; }
            public bool CanTransferCollections { get; set; }

            public string DisplayName
            {
                get
                {
                    if (string.IsNullOrEmpty(Name))
                    {
                        return Email;
                    }
                    return Name;
                }
            }
        }

        public void EnsureCanEditEmail(string role)
        {
            if (!Permissions.UserLevel.CanEditEmail(role))
            {
                throw new Exception("A user doesn't have permissions to edit email.");
            }
        }

        public void EnsureCanChangePassword(string role)
        {
            if (!Permissions.UserLevel.CanChangePassword(role))
            {
                throw new Exception("A user doesn't have permissions to change password.");
            }
        }

        public void EnsureCanManageCollaborators(string userId, string role, Item.ItemsService.Collection collection = null)
        {
            var isCollaborator = false;
            var isShedCollection = role == ShedRoleConfig.SHEDUSER_ROLE;

            if (collection != null)
            {
                isCollaborator = collection.UserId != userId;
                isShedCollection = collection.IsShedCollection;
            }

            if (!Permissions.CollectionLevel.CanManageCollaborators(role, isCollaborator, isShedCollection))
            {
                throw new Exception("A user doesn't have permissions to manage collaborators.");
            }
        }

        public void EnsureCanAddCollaborator(string userId, string role, Item.ItemsService.Collection collection, string invitedUserId)
        {
            if (!string.IsNullOrEmpty(invitedUserId) && ContainsShedUserRole(invitedUserId))
            {
                if (!Permissions.CollectionLevel.CanInviteShedUserToCollaborators(role, collection.UserId != userId, collection.IsShedCollection))
                {
                    throw new Exception("A user doesn't have permissions to add Shed users as Collaborator");
                }
            }

            if (string.IsNullOrEmpty(invitedUserId) || ContainsRegularUserRole(invitedUserId))
            {
                if (!Permissions.CollectionLevel.CanInviteRegularUserToCollaborators(role, collection.UserId != userId, collection.IsShedCollection))
                {
                    throw new Exception("A user doesn't have permissions to add Regular users as Collaborator");
                }
            }
        }

        public Guid AddCollaborator(string identityUserId, Guid collaboratorId, Guid collectionId)
        {
            using (var collaboratorRepo = new BaseRepository<Collaborator>())
            {

                var collaborator = collaboratorRepo.GetById(collaboratorId);
                if (collaborator == null)
                    throw new Exception("Collaborator not found");

                /*collaborator.Collections.Add(collectionsRepo.GetById(collectionId));
                collaboratorRepo.Update(collaborator);*/
            }
            if (collectionId != null && collectionId != Guid.Empty)
            {
                AttachCollaboratorToCollection(identityUserId, collaboratorId, collectionId);
            }
            AttachCollaboratorToUser(identityUserId, collaboratorId);
            return collaboratorId;
        }

        public Guid AddCollaborator(string identityUserId, string userId, Guid collectionId, bool shouldSendNotification = true)
        {
            Guid collaboratorId;
            using (var collaboratorRepo = new BaseRepository<Collaborator>())
            {
                var collaborator = collaboratorRepo.GetSingleBy(x => x.UserId == userId);
                if (collaborator == null)
                {
                    using (var usersRepo = new UsersRepository())
                    {
                        var user = usersRepo.GetById(userId);
                        if (user != null)
                        {
                            collaboratorId = collaboratorRepo.Add(new Collaborator
                            {
                                Id = Guid.NewGuid(),
                                UserId = userId,
                                Email = user.Email,
                                Name = string.Format("{0} {1}", user.FirstName, user.LastName).Trim()
                            });
                        }
                        else
                        {
                            throw new Exception("User not found");
                        }
                    }
                }
                else
                {
                    collaboratorId = collaborator.Id;
                }
            }
            if (collectionId != null && collectionId != Guid.Empty)
            {
                AttachCollaboratorToCollection(identityUserId, collaboratorId, collectionId, shouldSendNotification);
            }
            AttachCollaboratorToUser(identityUserId, collaboratorId);

            return collaboratorId;
        }

        public Guid AddCollaborator(string identityUserId, string email, string name, Guid collectionId)
        {
            Guid collaboratorId;
            using (var collaboratorRepo = new BaseRepository<Collaborator>())
            {
                collaboratorId = collaboratorRepo.Add(new Collaborator
                {
                    Id = Guid.NewGuid(),
                    UserId = null,
                    Email = email,
                    Name = name
                });
            }

            if (collectionId != null && collectionId != Guid.Empty)
            {
                AttachCollaboratorToCollection(identityUserId, collaboratorId, collectionId);
            }
            AttachCollaboratorToUser(identityUserId, collaboratorId);

            return collaboratorId;
        }

        public void DeleteCollaborator(string identityUserId, string role, Guid collaboratorId, Guid collectionId)
        {
            using (var collectionsRepo = new BaseRepository<Collection>())
            {
                var collection = collectionsRepo.GetById(collectionId);
                if (collection == null)
                {
                    throw new Exception("Collection not found");
                }

                if (!Permissions.CollectionLevel.CanManageCollaborators(role, collection.UserId != identityUserId, IsShedCollection(collection)))
                {
                    throw new Exception("A user doesn't have permissions to manage collaborators.");
                }

                if (!Permissions.CollectionLevel.CanRemoveCollaborators(role, collection.UserId != identityUserId, IsShedCollection(collection)))
                {
                    throw new Exception("A user doesn't have enough permissions to remove collaborators.");
                }

                var collaborator = collection.Collaborators.FirstOrDefault(x => x.Id == collaboratorId);
                if (collaborator == null)
                {
                    throw new Exception("Collaborator not found in collection");
                }
                collection.Collaborators.Remove(collaborator);
                collectionsRepo.Context.SaveChanges();
                var user = GetUserById(identityUserId);
                new NotificationsService().AddNotification(collaborator.UserId, string.Format("<b>{0}</b> has removed you from the collection <b>{1}</b>", user.DisplayName, collection.Name), collectionId, NotificationsService.NO_ACTION);
            }
        }

        public void DeleteCollaboratorUser(string identityUserId, Guid collaboratorId)
        {
            using (var collaboratorsRepo = new BaseRepository<Collaborator>())
            {
                if (!collaboratorsRepo.GetById(collaboratorId).Collections.Any(x => x.UserId == identityUserId))
                {
                    collaboratorsRepo.Context.Database.ExecuteSqlCommand(string.Format("delete from CollaboratorsUsers where Id='{0}' and CreatedBy='{1}'", collaboratorId, identityUserId));
                }
            }
        }

        private void AttachCollaboratorToCollection(string userId, Guid collaboratorId, Guid collectionId, bool shouldSendNotification = true)
        {
            Collaborator collaborator;
            using (var collaboratorRepo = new BaseRepository<Collaborator>())
            {
                collaborator = collaboratorRepo.GetById(collaboratorId);
                if (collaborator == null)
                    throw new Exception("Collaborator not found");
            }

            using (var collectionsRepo = new BaseRepository<Collection>())
            {
                var collection = collectionsRepo.GetById(collectionId);
                if (collection == null)
                    throw new Exception("Collaborator not found");

                if (!collection.Collaborators.Any(x => x.Id == collaboratorId))
                {
                    collectionsRepo.Context.Database.ExecuteSqlCommand(string.Format("insert into CollectionCollaborators values('{0}', '{1}')", collaboratorId, collectionId));

                    if (shouldSendNotification)
                    {
                        var actor = GetUserById(userId);
                        new NotificationsService().AddNotification(collaborator.UserId, string.Format("<b>{0}</b> invited you to be a collaborator on <b>{1}</b>", actor.DisplayName, collection.Name), collectionId, NotificationsService.ACTION);
                    }
                }
            }
        }

        private void AttachCollaboratorToUser(string identityUserId, Guid collaboratorId)
        {
            using (var usersRepository = new UsersRepository())
            {
                var userModel = usersRepository.GetById(identityUserId);
                if (!userModel.CreatedCollaborators.Any(x => x.Id == collaboratorId))
                {
                    usersRepository.Context.Database.ExecuteSqlCommand(string.Format("insert into CollaboratorsUsers(Id, CreatedBy) values('{0}', '{1}')", collaboratorId, identityUserId));
                }
            }
        }

        public List<Guid> GetCollectionsByCollaboratorIdAndUserId(string identityUserId, Guid collaboratorId)
        {
            using (var collaboratorsRepo = new BaseRepository<Collaborator>())
            {
                return collaboratorsRepo.GetById(collaboratorId).Collections.Where(x => x.UserId == identityUserId).Select(x => x.Id).ToList();
            }
        }

        public ICollection<UserCollaborator> GetCollectionCollaborators(Guid collectionId)
        {
            using (var collectionsRepo = new BaseRepository<Collection>())
            {
                var collection = collectionsRepo.GetById(collectionId);
                if (collection == null || collection.Collaborators == null)
                    return new List<UserCollaborator>();
                return collection.Collaborators.Select(collaborator => new UserCollaborator
                {
                    Id = collaborator.Id,
                    UserId = collaborator.UserId,
                    Name = collaborator.Name,
                    Email = collaborator.Email,
                    CollectionId = collectionId
                }).ToList();
            }
        }

        public ICollection<UserCollaborator> GetUserCollectionsCollaborators(string userId, string role)
        {
            var collections = new ItemsService().GetUserCollections(userId, role);
            var collaborators = new List<UserCollaborator>();
            foreach (var collection in collections)
            {
                foreach (var collaborator in collection.Collaborators)
                {
                    collaborator.CollectionId = collection.Id;
                }
                collaborators.AddRange(collection.Collaborators);
            }

            return collaborators;
        }

        public ICollection<UserCollaborator> GetUserCollaborators(string identityUserId)
        {
            var collaborators = new List<UserCollaborator>();
            using (var usersRepository = new UsersRepository())
            {
                foreach (var collaborator in usersRepository.GetById(identityUserId).CreatedCollaborators)
                {
                    if (collaborator.Collections.Any())
                    {
                        foreach (var collection in collaborator.Collections)
                        {
                            var userCollaborator = new UserCollaborator()
                            {
                                CollectionId = collection.Id,
                                Email = collaborator.Email,
                                Id = collaborator.Id,
                                Name = collaborator.Name,
                                UserId = collaborator.UserId
                            };
                            collaborators.Add(userCollaborator);
                        }
                    }
                    else
                    {
                        var userCollaborator = new UserCollaborator()
                        {
                            CollectionId = Guid.Empty,
                            Email = collaborator.Email,
                            Id = collaborator.Id,
                            Name = collaborator.Name,
                            UserId = collaborator.UserId
                        };
                        collaborators.Add(userCollaborator);
                    }
                }

            }
            return collaborators;
        }

        public User GetUserById(string userId)
        {
            using (var usersRepo = new UsersRepository())
            {
                var user = usersRepo.GetById(userId);
                if (user != null)
                {
                    return MapToUser(user);
                }
                else
                {
                    return new User();
                }
            }
        }

        public User GetUserByEmail(string email)
        {
            using (var usersRepo = new UsersRepository())
            {
                var user = usersRepo.GetAll().FirstOrDefault(u => u.Email == email);
                if (user != null)
                {
                    return MapToUser(user);
                }

                return null;
            }
        }

        public Models.UsersList GetUsers(int number, int size)
        {
            using (var usersRepo = new UsersRepository())
            {
                var result = new Models.UsersList();
                var query = usersRepo.GetAll();

                result.TotalCount = query.Count();
                result.Users = query.OrderByDescending(x => x.CreatedAtUtc)
                                    .Skip((number - 1) * size)
                                    .Take(size)
                                    .Select(x => MapToUser(x))
                                    .ToList();

                return result;
            }
        }

        public Dictionary<string, string> GetShedUsers()
        {
            using (var usersRepo = new UsersRepository())
            {
                var shedUserDBId = ShedRoleConfig.GetRoleInfo(ShedRoleConfig.SHEDUSER_ROLE).DbId;

                var users = usersRepo.GetAll().ToList();
                return users.Where(x => x.Roles.Any(r => r.RoleId == shedUserDBId)).ToDictionary(d => d.Id, d => $"{d.FirstName} {d.LastName} {d.Email}");
            }
        }

        private User MapToUser(ApplicationUser applicationUser)
        {
            var role = ShedRoleConfig.GetRoleKey(applicationUser.Roles.Select(x => x.RoleId).ToList());
            return new User
            {
                Id = applicationUser.Id,
                Email = applicationUser.Email,
                FirstName = applicationUser.FirstName,
                LastName = applicationUser.LastName,
                PhoneNumber = applicationUser.PhoneNumber,
                IsLocked = applicationUser.IsLocked,
                CreatedAtUtc = applicationUser.CreatedAtUtc,
                Role = role,
                CanTransferCollections = role == ShedRoleConfig.REGULARUSER_ROLE
            };
        }

        public byte[] GetUserDataCsvById(string userId, string itemUrlTemplate)
        {
            var result = new byte[0];

            var user = GetUserById(userId);
            if (user != null)
            {
                result = new UserDataCsvGenerator(user, itemUrlTemplate).GetUserDataCsv();
            }

            return result;
        }

        public User GetCollaboratorInfo(Guid collaboratorId)
        {
            Collaborator collaborator;
            using (var collaboratorRepo = new BaseRepository<Collaborator>())
            {
                collaborator = collaboratorRepo.GetById(collaboratorId);
                if (collaborator == null)
                    throw new Exception("Collaborator not found");
            }
            if (string.IsNullOrEmpty(collaborator.UserId))
                throw new Exception("Unknow collaborator user");

            using (var usersRepo = new UsersRepository())
            {
                var user = usersRepo.GetById(collaborator.UserId);
                if (user == null)
                    throw new Exception("User not found");

                return new User
                {
                    Email = user.Email,
                    Id = collaborator.UserId,
                    FirstName = user.FirstName,
                    LastName = user.LastName
                };
            }
        }

        public void AddPushToken(string userId, string token)
        {
            if (string.IsNullOrEmpty(token))
                throw new ArgumentException("Push token can't be null or empty");
            using (var usersRepo = new UsersRepository())
            {
                var user = usersRepo.GetById(userId);
                if (user == null)
                    throw new Exception("User not found");

                user.PushToken = token;

                usersRepo.UpdateUser(user);
            }
        }

        public void SetUserIsLocked(string userId, bool isLocked)
        {
            using (var usersRepo = new UsersRepository())
            {
                var user = usersRepo.GetById(userId);
                if (user == null)
                {
                    throw new Exception("User not found");
                }

                user.IsLocked = isLocked;

                usersRepo.UpdateUser(user);
            }
        }

        public int GetShedRoleId(string role)
        {
            return ShedRoleConfig.GetRoleInfo(role).Id;
        }

        public Dictionary<string, string> GetAllRoles()
        {
            return ShedRoleConfig.GetAllRoles();
        }
    }
}