﻿using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using Microsoft.AspNet.Identity.EntityFramework;
using PraticDepo.DAL;
using PraticDepo.DAL.Configs;
using PraticDepo.DAL.Models;
using PraticDepo.DataLayer.Repo.ApplicationManagers;
using PraticDepo.DataLayer.Repo.Repositories;

namespace PraticDepo.DataLayer.Repo
{
    public class Storage : IDisposable, IStorage
    {
        private AuthContext _context;
        private UserRepository _userRepository;
        private TokenRepository _tokenRepository;
        private ApplicationUserManager _userManager;
        private CollectionRepository _collectionRepository;
        private LocationRepository _locationRepository;
        private CollaboratorRepository _collaboratorRepository;
        private ItemRepository _itemRepository;
        private MediaRepository _mediaRepository;
        private NotificationRepository _notificationRepository;
        private VideoChapterRepository _videoChapterRepository;
        private DeliveryRequestRepository _deliveryRequestRepository;
        private DeliveryRequestCollectionRepository _deliveryRequestCollectionRepository;
        private DeliveryRequestCollectionItemRepository _deliveryRequestCollectionItemRepository;
        private DeliveryRequestNoteRepository _deliveryRequestNoteRepository;
        private CollectionPhotoRepository _collectionPhotoRepository;
        private JobRepository _jobRepository;
        private UserJobRepository _userJobsRepository;
        private JobCollectionRepository _jobCollectionRepository;

        public Storage()
        {
            _context = _context ?? AuthContext.Create();
            _userManager = _userManager ?? new ApplicationUserManager(new UserStore<ApplicationUser>(_context));
        }

        public Storage(string connectionString)
        {
            _context = _context ?? new AuthContext(connectionString);
            _userManager = _userManager ?? new ApplicationUserManager(new UserStore<ApplicationUser>(_context));
        }

        #region Initialize

        public static void Initialize(string connectionString)
        {
            using (var context = new AuthContext(connectionString))
            {
                /*
                Guid userId = Guid.NewGuid();
                context.Users.AddOrUpdate(u => u.Email,
                                          new ApplicationUser { Id = userId.ToString(), Email = AdminConfig.EMAIL, PasswordHash = AdminConfig.PASSWORD_HASH, FirstName = "Admin", LastName = "Admin",
                                                                SecurityStamp = Guid.NewGuid().ToString(), EmailConfirmed = true, PhoneNumberConfirmed = false, TwoFactorEnabled = false, LockoutEnabled = false,
                                                                UserName = AdminConfig.NAME }
                                         );
                */

                foreach (var roleKey in ShedRoleConfig.GetRoleKeys())
                {
                    var roleInfo = ShedRoleConfig.GetRoleInfo(roleKey);
                    context.Roles.AddOrUpdate(r => r.Name, new ApplicationRole { Name = roleKey, Description = roleInfo.Description });
                }

                var adminUser = context.Users.SingleOrDefault(u => u.Email == AdminConfig.EMAIL);
                var adminRole = context.Roles.SingleOrDefault(r => r.Name == ShedRoleConfig.ADMIN_ROLE);
                if (adminUser != null && adminRole != null)
                {
                    context.Set<IdentityUserRole>().AddOrUpdate(r => r.UserId, new IdentityUserRole { RoleId = adminRole.Id, UserId = adminUser.Id });
                    context.SaveChanges();
                }

                foreach (var roleKey in ShedRoleConfig.GetRoleKeys())
                {
                    var role = context.Roles.SingleOrDefault(r => r.Name == roleKey);
                    ShedRoleConfig.SetDbId(roleKey, role.Id);
                }

                context.Locations.AddOrUpdate(l => new { l.Name, l.OwnerId }, new Location
                {
                    Id = Guid.NewGuid(),
                    ParentId = null,
                    OwnerId = adminUser.Id,
                    Name = ShedStorageConfig.NAME,
                    Latitude = ShedStorageConfig.LATITUDE,
                    Longitude = ShedStorageConfig.LONGITUDE,
                    City = ShedStorageConfig.CITY,
                    CreateAt = DateTime.Now
                });
                context.SaveChanges();

                var adminRoleDbId = ShedRoleConfig.GetRoleInfo(ShedRoleConfig.ADMIN_ROLE).DbId;
                var usersWithoutRoles = context.Users.Where(x => x.Id != adminUser.Id && x.Roles.Count(r => r.RoleId != adminRoleDbId) == 0);

                if (usersWithoutRoles.Any())
                {
                    var regularRoleDbId = ShedRoleConfig.GetRoleInfo(ShedRoleConfig.REGULARUSER_ROLE).DbId;

                    foreach (var user in usersWithoutRoles)
                    {
                        context.Set<IdentityUserRole>().Add(new IdentityUserRole { RoleId = regularRoleDbId, UserId = user.Id });
                    }
                    context.SaveChanges();
                }

                AdminConfig.Id = adminUser.Id;
            }
        }

        #endregion
        
        public DbContextTransaction StartTransaction(IsolationLevel isolationLevel = IsolationLevel.Unspecified)
        {
            return _context.Database.BeginTransaction(isolationLevel);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }

        public int ExecuteSqlCommand(string query, params object[] parameters)
        {
            return _context.Database.ExecuteSqlCommand(query, parameters);
        }

        public UserRepository Users
        {
            get
            {
                _userRepository = _userRepository ?? new UserRepository(_context, _userManager);
                return _userRepository;
            }
        }

        public TokenRepository Tokens
        {
            get
            {
                _tokenRepository = _tokenRepository ?? new TokenRepository(_context);
                return _tokenRepository;
            }
        }

        public CollectionRepository Collections
        {
            get
            {
                _collectionRepository = _collectionRepository ?? new CollectionRepository(_context);
                return _collectionRepository;
            }
        }

        public LocationRepository Locations
        {
            get
            {
                _locationRepository = _locationRepository ?? new LocationRepository(_context);
                return _locationRepository;
            }
        }

        public CollaboratorRepository Collaborators
        {
            get
            {
                _collaboratorRepository = _collaboratorRepository ?? new CollaboratorRepository(_context);
                return _collaboratorRepository;
            }
        }

        public ItemRepository Items
        {
            get
            {
                _itemRepository = _itemRepository ?? new ItemRepository(_context);
                return _itemRepository;
            }
        }

        public MediaRepository Media
        {
            get
            {
                _mediaRepository = _mediaRepository ?? new MediaRepository(_context);
                return _mediaRepository;
            }
        }

        public NotificationRepository Notifications
        {
            get
            {
                _notificationRepository = _notificationRepository ?? new NotificationRepository(_context);
                return _notificationRepository;
            }
        }

        public VideoChapterRepository VideoChapters
        {
            get
            {
                _videoChapterRepository = _videoChapterRepository ?? new VideoChapterRepository(_context);
                return _videoChapterRepository;
            }
        }

        public DeliveryRequestRepository DeliveryRequests
        {
            get
            {
                _deliveryRequestRepository = _deliveryRequestRepository ?? new DeliveryRequestRepository(_context);
                return _deliveryRequestRepository;
            }
        }

        public DeliveryRequestCollectionRepository DeliveryRequestCollections
        {
            get
            {
                _deliveryRequestCollectionRepository = _deliveryRequestCollectionRepository ?? new DeliveryRequestCollectionRepository(_context);
                return _deliveryRequestCollectionRepository;
            }
        }

        public DeliveryRequestCollectionItemRepository DeliveryRequestCollectionItems
        {
            get
            {
                _deliveryRequestCollectionItemRepository = _deliveryRequestCollectionItemRepository ?? new DeliveryRequestCollectionItemRepository(_context);
                return _deliveryRequestCollectionItemRepository;
            }
        }

        public DeliveryRequestNoteRepository DeliveryRequestNotes
        {
            get
            {
                _deliveryRequestNoteRepository = _deliveryRequestNoteRepository ?? new DeliveryRequestNoteRepository(_context);
                return _deliveryRequestNoteRepository;
            }
        }

        public CollectionPhotoRepository CollectionPhotos
        {
            get
            {
                _collectionPhotoRepository = _collectionPhotoRepository ?? new CollectionPhotoRepository(_context);
                return _collectionPhotoRepository;
            }
        }

        public JobRepository Jobs
        {
            get
            {
                _jobRepository = _jobRepository ?? new JobRepository(_context);
                return _jobRepository;
            }
        }

        public UserJobRepository UserJobs
        {
            get
            {
                _userJobsRepository = _userJobsRepository ?? new UserJobRepository(_context);
                return _userJobsRepository;
            }
        }

        public JobCollectionRepository JobCollections
        {
            get
            {
                _jobCollectionRepository = _jobCollectionRepository ?? new JobCollectionRepository(_context);
                return _jobCollectionRepository;
            }
        }

        #region IDisposable Support

        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    if (_context != null)
                    {
                        _userManager.Dispose();
                        _context.Dispose();
                    }
                }

                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }

        #endregion
    }
}