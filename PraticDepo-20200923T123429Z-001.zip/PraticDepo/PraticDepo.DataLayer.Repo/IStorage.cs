﻿using PraticDepo.DataLayer.Repo.Repositories;

namespace PraticDepo.DataLayer.Repo
{
    public interface IStorage
    {
        TokenRepository Tokens { get; }
        UserRepository Users { get; }
        JobRepository Jobs { get; }

        void Dispose();
    }
}