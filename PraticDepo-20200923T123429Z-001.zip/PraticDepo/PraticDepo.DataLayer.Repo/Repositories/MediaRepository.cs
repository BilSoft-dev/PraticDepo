﻿using PraticDepo.DAL;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Repository;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class MediaRepository : BaseRepository<Media>
    {
        public MediaRepository(AuthContext authContext) : base(authContext) { }
    }
}
