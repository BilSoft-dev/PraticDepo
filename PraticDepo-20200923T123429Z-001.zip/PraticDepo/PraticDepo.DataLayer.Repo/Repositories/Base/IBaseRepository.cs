﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo.Repositories.Base
{
    public interface IBaseRepository<T> where T : class, IEntity
    {
        Guid Add(T entity);
        void Delete(Guid id);
        void Delete(T entity);
        void DeleteRange(IEnumerable<T> entities);
        IQueryable<T> GetAll(bool asNoTracking = false);
        T GetById(Guid id, bool asNoTracking = false);
        IQueryable<T> GetBy(Expression<Func<T, bool>> expression, bool asNoTracking = false);
        T GetSingleBy(Expression<Func<T, bool>> expression, bool asNoTracking = false);
        void Update(T entity);
    }
}