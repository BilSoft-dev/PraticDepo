﻿using PraticDepo.DAL;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class CollectionPhotoRepository : Base.BaseRepository<CollectionPhoto>
    {
        public CollectionPhotoRepository(AuthContext authContext) : base(authContext) { }
    }
}
