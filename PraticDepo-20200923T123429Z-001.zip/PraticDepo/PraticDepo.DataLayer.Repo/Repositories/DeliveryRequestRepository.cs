﻿using System;
using PraticDepo.DAL;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class DeliveryRequestRepository : Base.BaseRepository<DeliveryRequest>
    {
        public DeliveryRequestRepository(AuthContext context) : base(context) { }
    }
}
