﻿using System;
using PraticDepo.DAL;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class DeliveryRequestNoteRepository : Base.BaseRepository<DeliveryRequestNote>
    {
        public DeliveryRequestNoteRepository(AuthContext context) : base(context) { }
    }
}