﻿using PraticDepo.DAL;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Repository;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class VideoChapterRepository : BaseRepository<VideoChapter>
    {
        public VideoChapterRepository(AuthContext authContext) : base(authContext) { }
    }
}
