﻿using System;
using PraticDepo.DAL;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class JobRepository : Base.BaseRepository<Job>
    {
        public JobRepository(AuthContext context) : base(context) { }
    }
}