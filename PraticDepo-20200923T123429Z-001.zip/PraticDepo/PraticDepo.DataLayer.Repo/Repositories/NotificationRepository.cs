﻿using PraticDepo.DAL;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class NotificationRepository : Base.BaseRepository<Notification>
    {
        public NotificationRepository(AuthContext authContext) : base(authContext) { }
    }
}
