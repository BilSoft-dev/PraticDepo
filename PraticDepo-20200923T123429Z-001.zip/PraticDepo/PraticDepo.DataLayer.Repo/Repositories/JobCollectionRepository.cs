﻿using PraticDepo.DAL;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo
{
    public class JobCollectionRepository : Repositories.Base.BaseRepository<JobCollection>
    {
        public JobCollectionRepository(AuthContext context) : base(context) { }
    }
}
