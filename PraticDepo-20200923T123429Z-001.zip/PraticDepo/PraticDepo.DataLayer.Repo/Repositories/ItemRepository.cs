﻿using PraticDepo.DAL;
using PraticDepo.DAL.Models;
using PraticDepo.DAL.Models.CustomModels;
using PraticDepo.DAL.Repository;
using System.Linq;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class ItemRepository : BaseRepository<Item>
    {
        public ItemRepository(AuthContext authContext) : base(authContext) { }

        public IQueryable<ItemMedia> GetAllItemMedia()
        {
            return from items in Context.Items
                   join medias in Context.Medias on items.Id equals medias.ItemId
                   join videoChapters in Context.VideoChapters on medias.Id equals videoChapters.VideoId into gj
                   from result in gj.DefaultIfEmpty()
                   select new ItemMedia
                   {
                       VideoChapter = result,
                       Item = items,
                       Collection = items.Collection,
                       ItemCreator = Context.Users.FirstOrDefault(u => u.Id == items.UserId),
                       ItemOwners = items.Collection.Collaborators.Select(colab => colab.User)
                   };
        }
    }
}
