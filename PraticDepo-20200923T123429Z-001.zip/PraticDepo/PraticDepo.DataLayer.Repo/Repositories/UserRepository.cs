﻿using System.Linq;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using PraticDepo.DAL;
using PraticDepo.DAL.Models;
using Microsoft.AspNet.Identity;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class UserRepository
    {
        private readonly AuthContext _context;
        private readonly DbSqlQuery<ApplicationUser> _set;
        private readonly UserManager<ApplicationUser> _userManager;

        public UserRepository(AuthContext context, UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
            _context = context;
            _set = _context.Set<ApplicationUser>().SqlQuery("select * from AspNetUsers");
        }

        public async Task<ApplicationUser> GetUserByEmail(string userEmail)
        {
            return await _userManager.FindByEmailAsync(userEmail);
        }

        public async Task<bool> CheckUserAndPasswordAsync(ApplicationUser userToVerify, string userPassword)
        {
            var passwordCheckResult = await _userManager.CheckPasswordAsync(userToVerify, userPassword);
            return passwordCheckResult;
        }

        public async Task<List<string>> GetUserRoles(ApplicationUser user)
        {
            var roles = await _userManager.GetRolesAsync(user.Id);
            return roles.ToList();
        }

        public IQueryable<ApplicationUser> GetAll()
        {
            return _set.AsQueryable();
        }

        public ApplicationUser GetById(string userId)
        {
            return _set.SingleOrDefault(x => x.Id == userId);
        }

        public ApplicationUser GetUser(Func<ApplicationUser, bool> searchPredicate)
        {
            return _set.FirstOrDefault(searchPredicate);
        }

        public int GetCountOfUsers(Func<ApplicationUser, bool> searchPredicate)
        {
            return _set.Where(searchPredicate).Count();
        }

        public string GetUserName(string userId)
        {
            var user = GetById(userId);
            return string.Format("{0} {1}", user.FirstName, user.LastName).Trim();
        }

        public string GetUserEmail(string userId)
        {
            var user = GetById(userId);
            return user.Email;
        }

        public void UpdateUser(ApplicationUser user)
        {
            _context.Entry(user).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public void SendUserEmailAsync(string userId, string subject, string body)
        {
            _userManager.SendEmail(userId, subject, body);
        }

        public IdentityResult CreateUser(ApplicationUser user, string password, out string userId)
        {
            var result = _userManager.Create(user, password);
            userId = user.Id;

            return result;
        }

        public bool AddUserToRole(string userId, string userRole)
        {
            return _userManager.AddToRole(userId, userRole).Succeeded;
        }

        public IList<string> GetUserRoles(string userId)
        {
            return _userManager.GetRoles(userId);
        }

        public bool RemoveUserFromRoles(string userId, string[] userRoles, out IEnumerable<string> errors)
        {
            var removeResult = _userManager.RemoveFromRoles(userId, userRoles.ToArray());
            errors = removeResult.Errors;

            return removeResult.Succeeded;
        }

        public string GetPasswordResetToken(string userId)
        {
            return _userManager.GeneratePasswordResetToken(userId);
        }

        public IdentityResult ResetPassword(string userId, string token, string newPassword)
        {
            return _userManager.ResetPassword(userId, token, newPassword);
        }

        public bool IsPasswordValid(string userName, string password)
        {
            return _userManager.Find(userName, password) != null;
        }

        public IdentityResult Delete(ApplicationUser user)
        {
            return _userManager.Delete(user);
        }

        public IEnumerable<ApplicationUser> GetUsersByRole(string roleId)
        {
            return _set.ToList().Where(u => u.Roles.Any(r => r.RoleId == roleId)).ToList();
        }
    }
}