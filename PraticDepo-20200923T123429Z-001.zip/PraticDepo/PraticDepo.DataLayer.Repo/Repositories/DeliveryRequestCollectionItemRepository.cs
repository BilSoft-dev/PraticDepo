﻿using System;
using PraticDepo.DAL;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class DeliveryRequestCollectionItemRepository : Base.BaseRepository<DeliveryRequestCollectionItem>
    {
        public DeliveryRequestCollectionItemRepository(AuthContext context) : base(context) { }
    }
}