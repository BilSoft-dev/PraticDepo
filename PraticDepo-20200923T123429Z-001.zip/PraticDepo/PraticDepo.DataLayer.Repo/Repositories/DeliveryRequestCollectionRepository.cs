﻿using System;
using PraticDepo.DAL;
using PraticDepo.DAL.Models;

namespace PraticDepo.DataLayer.Repo.Repositories
{
    public class DeliveryRequestCollectionRepository : Base.BaseRepository<DeliveryRequestCollection>
    {
        public DeliveryRequestCollectionRepository(AuthContext context) : base(context) { }
    }
}
