﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace PraticDepo.Common.V2.Tokens.Providers
{
    public interface IJwtTokensProvider
    {
        ClaimsIdentity GenerateClaimsIdentity(string userEmail, string id, string userRole);
        ClaimsIdentity GenerateClaimsIdentity(string userEmail, string id, IEnumerable<string> userRoles);
        string GenerateJwt(ClaimsIdentity identity, string userEmail, JsonSerializerSettings serializerSettings);
    }
}
