﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using PraticDepo.Common.V2.Constants;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;

namespace PraticDepo.Common.V2.Tokens.Providers
{
    public class JwtTokensProvider : IJwtTokensProvider
    {
        private readonly JwtIssuerOptions _jwtOptions;

        public JwtTokensProvider(JwtIssuerOptions jwtOptions)
        {
            _jwtOptions = jwtOptions;
        }

        public string GenerateJwt(ClaimsIdentity identity, string userEmail, JsonSerializerSettings serializerSettings)
        {
            var response = new
            {
                id = identity.Claims.Single(c => c.Type == "id").Value,
                auth_token = this.GenerateEncodedToken(userEmail, userEmail, identity),
                expires_in = (int)_jwtOptions.ValidFor.TotalSeconds,
                refresh_token = "STUB_TOKEN" //TODO DIMA: Need to implement refresh token generation
            };

            return JsonConvert.SerializeObject(response, serializerSettings);
        }

        public ClaimsIdentity GenerateClaimsIdentity(string userEmail, string id, string userRole)
        {
            return new ClaimsIdentity(new GenericIdentity(userEmail, "Token"), new[]
            {
                new Claim(Jwt.ClaimIdentifiers.Id, id),
                new Claim(Jwt.ClaimIdentifiers.Rol, userRole)
            });
        }

        public ClaimsIdentity GenerateClaimsIdentity(string userEmail, string id, IEnumerable<string> userRoles)
        {
            var claimsIdentity = new ClaimsIdentity(new GenericIdentity(userEmail, "Token"), new[]
            {
                new Claim(Jwt.ClaimIdentifiers.Id, id),
            });

            claimsIdentity.AddClaims(userRoles.Select(role => new Claim(Jwt.ClaimIdentifiers.Rol, role)));
            claimsIdentity.AddClaims(userRoles.Select(role => new Claim(ClaimTypes.Role, role)));

            return claimsIdentity;
        }

        #region Private methods

        private static long ToUnixEpochDate(DateTime date)
          => (long)Math.Round((date.ToUniversalTime() -
                               new DateTimeOffset(1970, 1, 1, 0, 0, 0, TimeSpan.Zero))
                              .TotalSeconds);

        private string GenerateEncodedToken(string userName, string userEmail, ClaimsIdentity identity)
        {
            var handler = new JwtSecurityTokenHandler();

            var token = handler.CreateToken(new SecurityTokenDescriptor
            {
                Issuer = _jwtOptions.Issuer,
                Audience = _jwtOptions.Audience,
                SigningCredentials = _jwtOptions.SigningCredentials,
                Subject = identity,
                Expires = _jwtOptions.Expiration,
                NotBefore = _jwtOptions.NotBefore,
            });

            var encodedJwt = handler.WriteToken(token);

            return encodedJwt;
        }
        
        #endregion
    }
}
