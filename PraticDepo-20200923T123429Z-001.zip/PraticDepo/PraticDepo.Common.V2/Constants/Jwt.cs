﻿namespace PraticDepo.Common.V2.Constants
{
    public static class Jwt
    {
        public const string SecretKey = "iNiCDZHLpUA223sqsfhqGbMRdQj1PVkH";

        public static class ClaimIdentifiers
        {
            public const string Rol = "rol";
            public const string Id = "id";
        }

        public static class Claims
        {
            public const string Admin = "Admin";
        }
    }
}
