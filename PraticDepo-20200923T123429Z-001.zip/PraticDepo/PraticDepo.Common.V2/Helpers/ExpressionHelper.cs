﻿using System;
using System.Linq.Expressions;

namespace PraticDepo.Common.V2.Helpers
{
    public static class ExpressionHelper
    {
        public static Expression<Func<T, bool>> AndAlso<T>(Expression<Func<T, bool>> x, Expression<Func<T, bool>> y)
        {
            return Expression.Lambda<Func<T, bool>>(Expression.AndAlso(x.Body, Expression.Invoke(y, x.Parameters)), x.Parameters);
        }
    }
}
